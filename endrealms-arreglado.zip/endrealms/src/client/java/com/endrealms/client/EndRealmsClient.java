package com.endrealms.client;

import com.endrealms.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;

public class EndRealmsClient implements ClientModInitializer {
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void reg(EntityType<?> type, net.minecraft.client.renderer.entity.EntityRendererProvider provider) {
        EntityRenderers.register((EntityType) type, provider);
    }

    @Override
    public void onInitializeClient() {
        // Cada mob tiene su propio modelo y textura (ver tools/gen_models.py).
        for (ModEntities.MobDef d : ModEntities.DEFS) {
            reg(ModEntities.TYPES.get(d.id()), ctx -> new SpecRenderer(ctx, d.id()));
        }
        reg(ModEntities.VIOLET_WARDEN, ctx -> new SpecRenderer(ctx, "violet_warden"));
        reg(ModEntities.CRYSTAL_QUEEN, ctx -> new SpecRenderer(ctx, "crystal_queen"));
    }
}
