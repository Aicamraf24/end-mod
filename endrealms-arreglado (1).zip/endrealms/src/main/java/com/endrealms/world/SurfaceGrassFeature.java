package com.endrealms.world;

import com.endrealms.EndRealms;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Cubre de pasto la superficie de piedra del End en los biomas de End Realms (etiqueta endrealms:has_end_grass).
 * El pasto usa el color de pasto de cada bioma (campo grass_color del bioma), como los distintos biomas del Nether.
 */
public class SurfaceGrassFeature extends Feature<NoneFeatureConfiguration> {
    private static final TagKey<Biome> GRASS_BIOMES = TagKey.create(Registries.BIOME, EndRealms.id("has_end_grass"));

    public SurfaceGrassFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        boolean placed = false;
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;
                int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
                pos.set(x, y, z);
                if (!level.getBlockState(pos).is(Blocks.END_STONE) || !level.getBiome(pos).is(GRASS_BIOMES)) continue;
                level.setBlock(pos, Blocks.GRASS_BLOCK.defaultBlockState(), 2);
                for (int k = 1; k <= 2; k++) {                       // dos capas de tierra bajo el pasto
                    pos.set(x, y - k, z);
                    if (level.getBlockState(pos).is(Blocks.END_STONE)) level.setBlock(pos, Blocks.DIRT.defaultBlockState(), 2);
                }
                placed = true;
            }
        }
        return placed;
    }
}
