"""Formas (piezas) y estilos (pintura) de cada mob de End Realms. Lo usa gen_models.main()."""
import math
from gen_models import *

def _t(**k): return {n: rgb(v) for n, v in k.items()}
THEMES = {
    'violet':  _t(fur=0x9a6bd0, fur2=0x4a2a78, light=0xd9c0f2, spot=0xff9bf5, glow=0xff4cff, dark=0x1c0a30, hoof=0x2a1444,
                  skin=0x5a3488, skin_dark=0x1c0a30, cloth=0x24103c, claw=0xd8b8f8, alga=0x7a3aa8),
    'ember':   _t(fur=0x8a3c1a, fur2=0x2a0e06, light=0xe09a58, spot=0xffa030, glow=0xff7020, dark=0x120604, hoof=0x1e0a04,
                  skin=0x5a2a1c, skin_dark=0x1a0a06, cloth=0x2a1410, claw=0xffb040, alga=0x8a3010),
    'azure':   _t(fur=0x2f86a8, fur2=0x0e3550, light=0xbfeaf0, spot=0x9ae8ee, glow=0x50fff0, dark=0x0a2a3a, hoof=0x1a4a64,
                  skin=0x2f7a86, skin_dark=0x103840, cloth=0x1e4f4a, claw=0x9ae8e0, alga=0x2f8a4a),
    'pale':    _t(fur=0xcdb88a, fur2=0x6a5030, light=0xf4ecd8, spot=0xfff8e8, glow=0xf6f6a0, dark=0x3a3830, hoof=0x3a2c1c,
                  skin=0xd8d0b8, skin_dark=0x6a6656, cloth=0x4a463c, claw=0xf8f4e4, alga=0x9aa070),
    'crystal': _t(fur=0x5aa0bc, fur2=0x2c4a60, light=0xd8f6ff, spot=0xff9bf5, glow=0xff6ee6, dark=0x13303f, hoof=0x24394c,
                  skin=0x3a7a96, skin_dark=0x13303f, cloth=0x24506a, claw=0xd8f6ff, alga=0xff9bf5),
}

# ----------------------------------------------------------------- ayudas de geometria
def hang(w, h, d): return (-w / 2, 0, -d / 2)       # la caja cuelga hacia abajo desde el pivote
def rise(w, h, d): return (-w / 2, -h, -d / 2)      # la caja sube desde el pivote
def cen(w, h, d): return (-w / 2, -h / 2, -d / 2)

def legs4(P, bw, bl, lh, t, kind='leg', xs=None, fz=None, hz=None):
    xs = bw / 2 - t / 2 if xs is None else xs
    fz = -bl / 2 + t / 2 + 0.5 if fz is None else fz
    hz = bl / 2 - t / 2 - 0.5 if hz is None else hz
    for nm, x, z, ph in (('legFR', xs, fz, PI), ('legFL', -xs, fz, 0), ('legBR', xs, hz, 0), ('legBL', -xs, hz, PI)):
        P.append(Part(nm, (t, lh, t), hang(t, lh, t), (x, 24 - lh, z), kind=kind, anim=LEG, phase=ph))

def side(s): return 'R' if s > 0 else 'L'

def frontness(face, lx, ly, fw, fh):
    if face == 'right': return lx / max(1, fw - 1)
    if face == 'left': return 1 - lx / max(1, fw - 1)
    if face == 'top': return ly / max(1, fh - 1)
    return 0.5

# ================================================================= CUADRUPEDOS
def sp_ox(bl=18, horns=True, hump=True):
    P = []; bw, bh, lh, t = 10, 10, 8, 4; by = 24 - lh - bh
    P.append(Part('body', (bw, bh, bl), hang(bw, bh, bl), (0, by, 0)))
    if hump: P.append(Part('hump', (6, 3, 7), (-3, -3, -bl / 2 + 1), (0, by, 0)))
    legs4(P, bw, bl, lh, t)
    P.append(Part('head', (8, 8, 7), (-4, -3, -7), (0, by + 2, -bl / 2 + 1), kind='head', anim=HEAD))
    P.append(Part('snout', (6, 4, 3), (-3, 1, -3), (0, 0, -7), 'head', kind='snout'))
    for s in (1, -1):
        P.append(Part('ear' + side(s), (3, 2, 1), (0 if s > 0 else -3, -1, -0.5), (s * 4, -2, -2), 'head', rot=(0, 0, s * 0.25), kind='ear'))
        if horns: P.append(Part('horn' + side(s), (1, 5, 1), (-0.5, -5, -0.5), (s * 3.5, -3, -3), 'head', rot=(0, 0, s * 0.55), kind='horn'))
    P.append(Part('tail', (1, 10, 1), (-0.5, 0, -0.5), (0, by + 1, bl / 2), rot=(0.12, 0, 0), kind='tail', anim=TAIL))
    P.append(Part('tuft', (2, 3, 2), (-1, 0, -1), (0, 10, 0), 'tail', kind='crest'))
    return P

def sp_tapir():
    P = []; bw, bh, bl, lh, t = 9, 9, 17, 7, 3; by = 24 - lh - bh
    P.append(Part('body', (bw, bh, bl), hang(bw, bh, bl), (0, by, 0)))
    legs4(P, bw, bl, lh, t, xs=2.8)
    P.append(Part('head', (6, 6, 7), (-3, -2, -7), (0, by + 1, -bl / 2 + 1), kind='head', anim=HEAD))
    P.append(Part('trunk', (4, 3, 5), (-2, 0, -5), (0, 0, -7), 'head', rot=(0.4, 0, 0), kind='snout'))
    P.append(Part('trunktip', (3, 2, 3), (-1.5, 0, -3), (0, 3, -5), 'trunk', rot=(0.3, 0, 0), kind='snout'))
    for s in (1, -1):
        P.append(Part('ear' + side(s), (3, 3, 1), (-1.5, -3, -0.5), (s * 3, -2, -2), 'head', rot=(0, 0, s * 0.3), kind='ear'))
    P.append(Part('tail', (2, 3, 2), (-1, 0, -1), (0, by + 1, bl / 2), rot=(0.4, 0, 0), kind='tail', anim=TAIL))
    return P

def sp_deer(tines=2, alen=7, neck=9, lh=11, wide=False):
    P = []; bw, bh, bl, t = 7, 8, 15, 2; by = 24 - lh - bh
    P.append(Part('body', (bw, bh, bl), hang(bw, bh, bl), (0, by, 0)))
    P.append(Part('rump', (6, 3, 5), (-3, -3, 2), (0, by + 1, 0)))
    legs4(P, bw, bl, lh, t, xs=2.2)
    ang = 0.55
    nz, ny = -bl / 2 + 1.5, by + 2
    P.append(Part('neck', (4, neck, 4), (-2, -neck, -2), (0, ny, nz), rot=(ang, 0, 0), kind='neck'))
    hy, hz = ny - neck * math.cos(ang), nz - neck * math.sin(ang)
    P.append(Part('head', (4, 4, 6), (-2, -3, -5), (0, hy, hz), kind='head', anim=HEAD, rot=(-0.15, 0, 0)))
    P.append(Part('snout', (3, 2, 3), (-1.5, -1, -3), (0, 0, -5), 'head', kind='snout'))
    for s in (1, -1):
        P.append(Part('ear' + side(s), (3, 2, 1), (0 if s > 0 else -3, -1, -0.5), (s * 2, -2, -1), 'head', rot=(0, 0, s * 0.6), kind='ear'))
        P.append(Part('antler' + side(s), (1, alen, 1), (-0.5, -alen, -0.5), (s * 1.3, -3, -1), 'head', rot=(-0.25, 0, s * 0.35), kind='antler'))
        for i in range(tines):
            P.append(Part(f'tine{side(s)}{i}', (1, 3, 1), (-0.5, -3, -0.5), (0, -(2.2 + i * 2.3), 0), 'antler' + side(s),
                          rot=(-0.45 if i % 2 == 0 else 0.1, 0, s * 0.7), kind='antler'))
    P.append(Part('tail', (2, 3, 1), (-1, -3, -0.5), (0, by + 1, bl / 2), rot=(-0.5, 0, 0), kind='tail', anim=TAIL))
    return P

def sp_boar(bl=15, mane=4, tusk=3, shaggy=False):
    P = []; bw, bh, lh, t = 11, 10, 6, 3; by = 24 - lh - bh
    P.append(Part('body', (bw, bh, bl), hang(bw, bh, bl), (0, by, 0)))
    P.append(Part('shoulder', (9, 3, 7), (-4.5, -3, -bl / 2 + 1), (0, by, 0)))
    legs4(P, bw, bl, lh, t, xs=3.5)
    P.append(Part('head', (8, 8, 7), (-4, -4, -7), (0, by + 3, -bl / 2 + 1), kind='head', anim=HEAD))
    P.append(Part('snout', (5, 4, 4), (-2.5, 0, -4), (0, 0, -7), 'head', kind='snout'))
    for s in (1, -1):
        P.append(Part('tusk' + side(s), (1, tusk, 1), (-0.5, -tusk, -0.5), (s * 2.6, 3.6, -9), 'head', rot=(-0.1, 0, s * 0.3), kind='tusk'))
        P.append(Part('ear' + side(s), (3, 3, 1), (-1.5, -3, -0.5), (s * 3.5, -4, -1), 'head', rot=(0, 0, s * 0.35), kind='ear'))
    for i in range(mane):
        P.append(Part(f'mane{i}', (2, 3, 3), (-1, -3, -1.5), (0, by, -bl / 2 + 4 + i * 3.2), kind='crest'))
    P.append(Part('tail', (1, 3, 1), (-0.5, -3, -0.5), (0, by + 1, bl / 2), rot=(-0.6, 0, 0), kind='tail', anim=TAIL))
    if shaggy:
        P.append(Part('skirt', (13, 4, bl - 2), (-6.5, 0, -(bl - 2) / 2), (0, by + bh - 3, 0), kind='fur'))
        P.append(Part('ruff', (9, 4, 4), (-4.5, -2, -2), (0, by + 4, -bl / 2 - 1), kind='fur'))
    return P

def sp_sheep(ram=False, crystals=False):
    P = []; bw, bh, bl, lh, t = 12, 10, 14, 9, 3; by = 24 - lh - bh
    P.append(Part('body', (bw, bh, bl), hang(bw, bh, bl), (0, by, 0), kind='wool'))
    legs4(P, bw, bl, lh, t, xs=3.5)
    P.append(Part('head', (5, 6, 6), (-2.5, -3, -6), (0, by + 3, -bl / 2), kind='head', anim=HEAD))
    P.append(Part('forelock', (6, 3, 4), (-3, -4, -3), (0, 0, -2), 'head', kind='wool'))
    for s in (1, -1):
        P.append(Part('ear' + side(s), (4, 2, 1), (0 if s > 0 else -4, -1, -0.5), (s * 2.5, -1, -2), 'head', rot=(0, 0, s * 0.45), kind='ear'))
        if ram:
            P.append(Part('hornA' + side(s), (3, 2, 2), (0 if s > 0 else -3, -1, -1), (s * 2.5, -1, -2), 'head', kind='horn'))
            P.append(Part('hornB' + side(s), (2, 3, 2), (-1, 0, -1), (s * 3, 0, 0), 'hornA' + side(s), kind='horn'))
            P.append(Part('hornC' + side(s), (3, 2, 2), (0 if s > 0 else -3, 0, -1), (0, 3, 0), 'hornB' + side(s), kind='horn'))
    P.append(Part('tail', (3, 3, 3), (-1.5, 0, 0), (0, by + 1, bl / 2 - 1), kind='wool', anim=TAIL))
    if crystals:
        for i, (x, z, r) in enumerate(((-3, -4, -0.25), (2.5, -1, 0.3), (-2, 3, -0.15), (3, 5, 0.2), (0, -6, 0.0))):
            h = 5 + (i % 2) * 2
            P.append(Part(f'crys{i}', (2, h, 2), (-1, -h, -1), (x, by + 0.5, z), rot=(0, 0, r), kind='crystal'))
    return P

def sp_wolf(flame=False, ruff=True):
    P = []; bw, bh, bl, lh, t = 7, 6, 12, 10, 3; by = 24 - lh - bh
    P.append(Part('body', (bw, bh, bl), hang(bw, bh, bl), (0, by, 0)))
    P.append(Part('chest', (7, 8, 5), (-3.5, 0, -bl / 2), (0, by - 1, 0)))
    legs4(P, bw, bl, lh, t, xs=2.2, fz=-bl / 2 + 2, hz=bl / 2 - 2)
    if ruff: P.append(Part('ruff', (8, 8, 4), (-4, -3, -4), (0, by + 1, -bl / 2 - 1), kind='fur'))
    P.append(Part('head', (5, 5, 5), (-2.5, -3, -5), (0, by + 1, -bl / 2 - 3), kind='head', anim=HEAD))
    P.append(Part('snout', (3, 2, 5), (-1.5, 0, -5), (0, 0, -5), 'head', kind='snout'))
    P.append(Part('lowerjaw', (3, 1, 4), (-1.5, 0, -4), (0, 2, -5), 'head', kind='jaw', anim=JAW))
    for s in (1, -1):
        P.append(Part('ear' + side(s), (2, 3, 1), (-1, -3, -0.5), (s * 1.8, -3, -1), 'head', rot=(0, 0, s * 0.15), kind='ear'))
        P.append(Part('fang' + side(s), (1, 2, 1), (-0.5, 0, -0.5), (s * 1, 2, -5), 'head', kind='tooth'))
    P.append(Part('tail', (3, 3, 9), (-1.5, -1.5, 0), (0, by + 1, bl / 2), rot=(-0.8, 0, 0), kind='tail', anim=TAIL))
    if flame:
        for i in range(5):
            P.append(Part(f'flame{i}', (2, 4 - (i % 2), 3), (-1, -4, -1.5), (0, by, -bl / 2 + 2 + i * 2.6), kind='flame'))
    return P

def sp_croc():
    P = []; lh = 4; bh = 5; by = 24 - lh - bh
    P.append(Part('body', (8, bh, 14), hang(8, bh, 14), (0, by, 0)))
    for i in range(5):
        P.append(Part(f'ridge{i}', (1, 2, 2), (-0.5, -2, -1), (0, by, -5 + i * 3), kind='crest'))
    for nm, x, z, ph in (('legFR', 5, -5, PI), ('legFL', -5, -5, 0), ('legBR', 5, 5, 0), ('legBL', -5, 5, PI)):
        P.append(Part(nm, (3, lh, 3), hang(3, lh, 3), (x, 24 - lh, z), kind='leg', anim=LEG, phase=ph))
        P.append(Part(nm + 'u', (3, 3, 3), (-1.5, -3, -1.5), (x * 0.82, by + 3, z), kind='body'))
    P.append(Part('tail1', (6, 4, 8), (-3, 0, 0), (0, by + 0.5, 7), kind='tail', anim=TAIL, phase=0.0))
    P.append(Part('tail2', (4, 3, 8), (-2, 0.5, 0), (0, 0, 8), 'tail1', kind='tail', anim=TAIL, phase=0.8))
    P.append(Part('tail3', (2, 2, 8), (-1, 0.5, 0), (0, 0, 8), 'tail2', kind='tail', anim=TAIL, phase=1.6))
    P.append(Part('head', (6, 3, 9), (-3, 0, -9), (0, by, -7), kind='head', anim=HEAD))
    P.append(Part('snoutknob', (4, 1, 2), (-2, -1, -9), (0, 0, 0), 'head', kind='snout'))
    for s in (1, -1):
        P.append(Part('eye' + side(s), (2, 2, 2), (-1, -2, -1), (s * 2.3, 0, -2), 'head', kind='head'))
        P.append(Part('tooth' + side(s), (1, 1, 6), (-0.5, 0, -6), (s * 2.5, 3, -2.5), 'head', kind='tooth'))
    P.append(Part('jaw', (5, 2, 8), (-2.5, 0, -8), (0, 3, -0.5), 'head', kind='jaw', anim=JAW))
    return P

# ================================================================= AVES
def sp_bird(lh=11, neck=9, body=(6, 6, 10), beak=7, bw_=1, crest=True):
    P = []; bw, bh, bl = body; by = 24 - lh - bh
    P.append(Part('body', (bw, bh, bl), hang(bw, bh, bl), (0, by, 0)))
    for s in (1, -1):
        P.append(Part('leg' + side(s), (1, lh, 1), hang(1, lh, 1), (s * 1.6, 24 - lh, 0.5), kind='leg', anim=LEG, phase=0 if s > 0 else PI))
        P.append(Part('foot' + side(s), (3, 1, 4), (-1.5, -1, -3), (0, lh, 0), 'leg' + side(s), kind='foot'))
        P.append(Part('wing' + side(s), (1, bh - 1, bl - 2), (0 if s > 0 else -1, 0, -(bl - 2) / 2), (s * bw / 2, by + 1, 0.5), rot=(0, 0, s * 0.08), kind='wing', anim=FLAP, phase=s))
    ang = 0.4
    nz, ny = -bl / 2 + 1.5, by + 1.5
    P.append(Part('neck', (2, neck, 2), (-1, -neck, -1), (0, ny, nz), rot=(ang, 0, 0), kind='neck'))
    hy, hz = ny - neck * math.cos(ang), nz - neck * math.sin(ang)
    hw = 3 if bw_ == 1 else 4
    P.append(Part('head', (hw, 3, 4), (-hw / 2, -2, -3), (0, hy, hz), kind='head', anim=HEAD))
    P.append(Part('beak', (bw_, 1 if bw_ == 1 else 2, beak), (-bw_ / 2, 0, -beak), (0, 0.5, -3), 'head', kind='beak'))
    if crest:
        for i, r in enumerate((0.5, 0.15, -0.2)):
            P.append(Part(f'crest{i}', (1, 3, 1), (-0.5, -3, -0.5), (0, -2, 0.5 + i * 0.8), 'head', rot=(r + 0.3, 0, 0), kind='crest'))
    P.append(Part('tail', (4, 1, 5), (-2, 0, 0), (0, by + 1, bl / 2 - 1), rot=(-0.25, 0, 0), kind='wing'))
    return P

# ================================================================= ARTROPODOS
def spider_legs(P, n_pairs, attach_y, zs, angs, la, lb, tilt=0.55, bend=1.9, kind='leg', t=2):
    for s in (1, -1):
        for i in range(n_pairs):
            g = f'sg{side(s)}{i}'
            P.append(grp(g, (s * 3.0, attach_y, zs[i]), rot=(0, s * angs[i], 0), anim=SLEG, phase=(i % 2) * PI + (0 if s > 0 else PI * 0.5)))
            P.append(Part(g + 'a', (la, t, t), (0 if s > 0 else -la, -t / 2, -t / 2), (0, 0, 0), g, rot=(0, 0, -s * tilt), kind=kind))
            P.append(Part(g + 'b', (lb, t, t), (0 if s > 0 else -lb, -t / 2, -t / 2), (s * la, 0, 0), g + 'a', rot=(0, 0, s * bend), kind='leg2'))

def sp_spider(crown=False, legs=(7, 11), fat=False):
    P = []
    P.append(Part('thorax', (7, 5, 7), (-3.5, 0, -3.5), (0, 12.5, -1), kind='body'))
    P.append(Part('head', (6, 5, 5), (-3, 0, -5), (0, 12.8, -4), kind='head', anim=HEAD))
    P.append(Part('abdomen', (9, 8 if not fat else 9, 11), (-4.5, 0, 0), (0, 11.5, 2), kind='abdomen'))
    P.append(Part('chelL', (1, 2, 3), (-0.5, 0, -3), (-1.5, 4, -5), 'head', rot=(0, -0.2, 0), kind='tooth'))
    P.append(Part('chelR', (1, 2, 3), (-0.5, 0, -3), (1.5, 4, -5), 'head', rot=(0, 0.2, 0), kind='tooth'))
    spider_legs(P, 4, 15.5, (-3.0, -1.0, 1.0, 3.0), (0.8, 0.3, -0.3, -0.8), legs[0], legs[1])
    if crown:
        for i, x in enumerate((-2.2, -0.7, 0.8, 2.3)):
            h = 4 + (i % 2) * 2
            P.append(Part(f'crown{i}', (1, h, 1), (-0.5, -h, -0.5), (x, 0, -1.5), 'head', rot=(-0.2, 0, x * 0.12), kind='crystal'))
        for i, z in enumerate((3, 6, 9)):
            P.append(Part(f'dorsal{i}', (2, 5, 2), (-1, -5, -1), (0, 0, z), 'abdomen', kind='crystal'))
    return P

def sp_scorpion():
    P = []
    P.append(Part('body', (8, 4, 10), (-4, 0, -5), (0, 16, 0), kind='body'))
    P.append(Part('head', (6, 3, 3), (-3, 0, -3), (0, 16.5, -5), kind='head', anim=HEAD))
    # patas
    spider_legs(P, 3, 17.5, (-2.5, 0.0, 2.5), (0.5, 0.0, -0.5), 4, 8, tilt=0.5, bend=1.7)
    # pinzas
    for s in (1, -1):
        g = 'arm' + side(s)
        P.append(grp(g, (s * 3.5, 17, -5), rot=(0, -s * 0.35, 0), anim=ARM, phase=PI if s > 0 else 0))
        P.append(Part(g + 'a', (2, 2, 6), (-1, -1, -6), (0, 0, 0), g, kind='claw'))
        P.append(Part(g + 'b', (4, 3, 4), (-2, -1.5, -4), (0, 0, -6), g + 'a', rot=(0, -s * 0.2, 0), kind='claw'))
        P.append(Part(g + 'c', (1, 2, 3), (-0.5, -1, -3), (s * 1.5, 0, -4), g + 'b', rot=(0, s * 0.5, 0), kind='claw'))
    # cola curvada
    prev = None; ang = 0.42
    for i in range(5):
        nm = f'tail{i}'
        size = (4 - (i // 3), 4 - (i // 3), 5)
        P.append(Part(nm, size, (-size[0] / 2, -size[1] / 2, 0), (0, 16.5, 5) if prev is None else (0, 0, 5), prev, rot=(ang, 0, 0), kind='tail', anim=TAIL, phase=i * 0.5))
        prev = nm
    P.append(Part('sting', (2, 2, 3), (-1, -1, 0), (0, 0, 5), prev, rot=(0.3, 0, 0), kind='sting'))
    return P

def sp_beetle():
    P = []
    P.append(Part('shell', (10, 6, 12), (-5, 0, -6), (0, 13, 0), kind='shell'))
    P.append(Part('under', (8, 3, 10), (-4, 0, -5), (0, 19, 0), kind='body'))
    for i, (x, z) in enumerate(((-2.5, -3), (2.5, -1), (-2, 3), (2.5, 4))):
        h = 4 + (i % 2)
        P.append(Part(f'crys{i}', (2, h, 2), (-1, -h, -1), (x, 13, z), rot=(0, 0, x * 0.06), kind='crystal'))
    P.append(Part('head', (6, 4, 4), (-3, 0, -4), (0, 15, -6), kind='head', anim=HEAD))
    for s in (1, -1):
        P.append(Part('mand' + side(s), (1, 1, 5), (-0.5, -0.5, -5), (s * 1.8, 3, -4), 'head', rot=(0, -s * 0.45, 0), kind='jaw', anim=JAW))
        P.append(Part('ant' + side(s), (1, 1, 4), (-0.5, -0.5, -4), (s * 1.2, 0.5, -3.5), 'head', rot=(-0.6, s * 0.3, 0), kind='tooth'))
    spider_legs(P, 3, 18.5, (-3.0, 0.0, 3.0), (0.45, 0.0, -0.45), 5, 8, tilt=0.5, bend=1.8)
    return P

# ================================================================= HUMANOIDES
def sp_human(leg=(3, 15), torso=(6, 12, 3), arm=(2, 9, 9), head=(5, 5, 5), hunch=0.3, neck=2, claw=3, extras=None, arm_swing=True,
             fins=0, jaw=False, horns=False, crown=0, shoulders=False):
    P = []
    lt, lh = leg; tw, th, td = torso; at, ul, fl = arm; hw, hh, hd = head
    hip = 24 - lh
    for s in (1, -1):
        P.append(Part('leg' + side(s), (lt, lh, lt), hang(lt, lh, lt), (s * (tw / 4 + lt / 2 - 0.5), hip, 0), kind='leg', anim=LEG, phase=0 if s > 0 else PI))
    P.append(Part('torso', (tw, th, td), (-tw / 2, -th, -td / 2), (0, hip, 0), rot=(hunch, 0, 0), kind='torso'))
    P.append(Part('neck', (2, neck, 2), (-1, -neck, -1), (0, -th + 1, 0), 'torso', rot=(-hunch * 0.7, 0, 0), kind='neck'))
    P.append(Part('head', (hw, hh, hd), (-hw / 2, -hh, -hd / 2 - 0.5), (0, -neck + 1, 0), 'neck', rot=(-hunch * 0.3, 0, 0), kind='head', anim=HEAD))
    if jaw:
        P.append(Part('jaw', (hw - 1, 2, hd - 1), (-(hw - 1) / 2, 0, -(hd - 1) - 0.5), (0, 0, 0.5), 'head', kind='jaw', anim=JAW))
    for s in (1, -1):
        a = 'arm' + side(s)
        P.append(Part(a, (at, ul, at), hang(at, ul, at), (s * (tw / 2 + at / 2), -th + 2, 0), 'torso', kind='arm', anim=ARM, phase=PI if s > 0 else 0))
        P.append(Part('fore' + side(s), (at, fl, at), hang(at, fl, at), (0, ul, 0), a, rot=(-0.55, 0, 0), kind='forearm'))
        P.append(Part('claw' + side(s), (at + 1, claw, at + 1), hang(at + 1, claw, at + 1), (0, fl, 0), 'fore' + side(s), kind='claw'))
        if shoulders:
            P.append(Part('shoulder' + side(s), (at + 2, 4, at + 2), (-(at + 2) / 2, -2, -(at + 2) / 2), (0, 0, 0), a, kind='shoulder'))
    for i in range(fins):
        P.append(Part(f'fin{i}', (1, 5 - i % 2, 3), (-0.5, -5, -1.5), (0, -th + 1 + i * (th - 2) / max(1, fins), td / 2), 'torso', rot=(0.25, 0, 0), kind='fin'))
    if horns:
        for s in (1, -1):
            P.append(Part('horn' + side(s), (2, 5, 2), (-1, -5, -1), (s * hw / 2, -hh + 1, 0), 'head', rot=(0, 0, s * 0.45), kind='horn'))
    for i in range(crown):
        h = 3 + (i % 2) * 2
        x = (i - (crown - 1) / 2) * 1.8
        P.append(Part(f'crown{i}', (1, h, 1), (-0.5, -h, -0.5), (x, -hh, 0), 'head', rot=(0, 0, x * 0.15), kind='crystal'))
    return P

# ================================================================= ESTILOS (pintura)
def M(base, **kw):
    d = {'base': base}; d.update(kw); return d

def fauna(th, pattern=None, fur=None, belly=None, eye=None, eye_white='light', muzzle=None, horn=None, inner=None,
          lower=None, tail=None, crest=None, tusk=None, noise=0.18, head_pat=None, extra=None):
    f = fur or th['fur']; b = belly if belly is not None else th['light']
    ew = th['light'] if eye_white == 'light' else eye_white
    s = {
        'body': M(f, belly=b, belly_from=0.5, pattern=pattern, noise=noise),
        'neck': M(f, belly=b, belly_from=0.7, belly_amt=0.6, pattern=pattern, noise=noise),
        'head': M(f, belly=b, belly_from=0.7, belly_amt=0.35, pattern=head_pat, eye=eye or th['dark'], eye_white=ew,
                  brow=mix(f, th['fur2'], 0.55), noise=noise),
        'snout': M(muzzle or mix(th['light'], f, 0.4), nostril=th['dark'], noise=noise),
        'ear': M(f, inner=inner or mix(th['spot'], th['light'], 0.5), noise=noise),
        'horn': M(horn or th['light'], ring=mix(horn or th['light'], th['fur2'], 0.5), noise=0.1),
        'antler': M(horn or th['light'], ring=mix(horn or th['light'], th['fur2'], 0.45), noise=0.1),
        'tusk': M(tusk or rgb(0xf0e8cc), tip=rgb(0xc8bfa0), noise=0.08),
        'tail': M(tail or th['fur2'], noise=noise),
        'crest': M(crest or th['fur2'], noise=noise),
        'fur': M(mix(f, th['light'], 0.25), pattern=pat_fur_tufts(mix(f, th['fur2'], 0.35), 5), noise=noise),
        'leg': M(f, grad=th['fur2'], grad_from=0.25, grad_amt=0.7, lower=lower or th['hoof'], lower_rows=3, noise=noise),
        'wool': M(mix(th['light'], f, 0.3), noise=0.16),
        'jaw': M(mix(f, th['fur2'], 0.3), noise=noise),
        'tooth': M(rgb(0xf4f0e0), tip=rgb(0xc8c0a8), noise=0.05),
        'flame': M(th['glow'], noise=0.2),
        'crystal': M(mix(th['spot'], th['light'], 0.3), pattern=pat_facets((255, 255, 255), th['fur2'], 3), noise=0.06),
    }
    if extra: s.update(extra)
    return s

def style_ox(th):
    return fauna(th, pattern=pat_first(pat_patches(th['fur2'], 0.57, 3.4, 1), pat_dots(th['spot'], 0.035, 2)),
                 head_pat=pat_patches(th['fur2'], 0.64, 2.6, 3, skip=('bottom', 'front')), tail=th['fur2'], crest=th['fur2'])

def style_tapir(th):
    def pat(face, lx, ly, fw, fh, p, gx, gy):
        if face == 'bottom': return None
        fr = frontness(face, lx, ly, fw, fh)
        if face in ('left', 'right', 'top') and fr < 0.42 and p.kind == 'body':
            return mix(th['light'], th['fur'], 0.15 + 0.2 * hsh(gx, gy, 5))
        return None
    return fauna(th, pattern=pat, fur=th['fur2'] and mix(th['fur'], th['fur2'], 0.4), belly=mix(th['fur'], th['light'], 0.4),
                 muzzle=mix(th['fur'], th['fur2'], 0.2), inner=th['light'], tail=th['light'])

def style_deer(th, pale=False):
    return fauna(th, pattern=pat_first(pat_dots(th['spot'], 0.07, 8), pat_spine(th['fur2'], ('top',))),
                 horn=th['light'] if pale else mix(th['light'], th['spot'], 0.45), tail=th['light'], inner=th['light'],
                 lower=th['hoof'], muzzle=mix(th['light'], th['fur'], 0.3))

def style_boar(th, pale=False):
    spine = pat_first(pat_spine(th['fur2'], ('top',), 3), pat_stripes(mix(th['fur'], th['fur2'], 0.5), 3, 1, True, 4))
    return fauna(th, pattern=spine, fur=mix(th['fur'], th['fur2'], 0.4 if pale else 0.1), belly=th['light'],
                 crest=th['fur2'], eye=th['dark'], eye_white=th['glow'], tail=th['fur2'])

def style_sheep(th, ram=False):
    wool = mix(th['light'], th['fur'], 0.28)
    s = fauna(th, fur=th['fur2'], belly=None, eye=th['light'], eye_white=None, horn=mix(th['light'], th['fur'], 0.2),
              inner=th['fur'], lower=th['hoof'], muzzle=mix(th['fur2'], th['light'], 0.15))
    s['wool'] = M(wool, pattern=pat_first(pat_dots(th['spot'], 0.045, 9, skip=()), pat_patches(mix(wool, th['fur'], 0.35), 0.62, 2.4, 11, skip=())), noise=0.2)
    s['body'] = dict(s['wool'])
    s['leg'] = M(th['fur2'], lower=th['hoof'], lower_rows=2, noise=0.14)
    return s

def style_wolf(th, flame=False):
    grey = rgb(0x8f8c80)
    f = mix(th['fur'], grey, 0.55)
    return fauna(th, fur=f, belly=mix(th['light'], (240, 238, 230), 0.4),
                 pattern=pat_first(pat_spine(th['fur2'], ('top',), 3), pat_fur_tufts(mix(f, th['fur2'], 0.4), 3)),
                 eye=th['glow'], eye_white=None, muzzle=mix(f, th['light'], 0.45), tail=mix(f, th['fur2'], 0.45),
                 inner=th['fur2'], crest=th['fur2'], lower=mix(th['fur2'], grey, 0.3),
                 extra={'head': M(f, eye=th['glow'], glow_halo=th['glow'], brow=th['fur2'], belly=mix(th['light'], f, 0.3), belly_from=0.7)})

def style_croc(th):
    return fauna(th, fur=mix(th['fur'], th['fur2'], 0.45), belly=th['light'], pattern=pat_first(pat_scales(mix(th['fur'], th['fur2'], 0.75)), pat_dots(th['spot'], 0.03, 3)),
                 eye=th['glow'], eye_white=None, muzzle=mix(th['fur'], th['fur2'], 0.35), crest=th['fur2'],
                 extra={'head': M(mix(th['fur'], th['fur2'], 0.4), eye=th['glow'], glow_halo=th['glow'], pattern=pat_scales(th['fur2'])),
                        'tail': M(mix(th['fur'], th['fur2'], 0.45), belly=th['light'], pattern=pat_scales(th['fur2']))})

def style_bird(th, duck=False):
    f = th['fur']
    return {
        'body': M(f, belly=th['light'], belly_from=0.55, pattern=pat_fur_tufts(mix(f, th['fur2'], 0.35), 7), noise=0.16),
        'neck': M(mix(th['light'], f, 0.35), pattern=pat_stripes(f, 3, 1, False, 2), noise=0.12),
        'head': M(mix(th['light'], f, 0.3), eye=rgb(0x181008), eye_white=rgb(0xffe060), brow=f, noise=0.12),
        'beak': M(th['spot'] if duck else rgb(0xe4b84a), noise=0.1),
        'wing': M(th['fur2'], pattern=pat_rows(th['light'], (0, 1, 2)), noise=0.14),
        'crest': M(th['fur2'], noise=0.1),
        'leg': M(mix(th['fur2'], th['hoof'], 0.3), noise=0.1),
        'foot': M(mix(th['fur2'], th['hoof'], 0.3), noise=0.1),
    }

# ---- artropodos
def style_spider(th, crack=True, queen=False):
    base = mix(th['dark'], th['fur2'], 0.55)
    def abd(face, lx, ly, fw, fh, p, gx, gy):
        if queen and face == 'top':
            dx, dy = abs(lx - (fw - 1) / 2) / max(1, fw / 2), abs(ly - (fh - 1) / 2) / max(1, fh / 2)
            d = dx + dy
            if d < 0.45: return th['light']
            if d < 0.75: return th['glow']
            if d < 0.95: return mix(th['glow'], th['fur2'], 0.6)
        if crack:
            v = vnoise(gx, gy, 2.4, 7)
            if abs(v - 0.5) < 0.05: return th['glow'] if hsh(gx, gy, 2) > 0.3 else th['spot']
        return None
    return {
        'body': M(base, pattern=abd, noise=0.2),
        'abdomen': M(base, pattern=abd, belly=mix(base, th['fur2'], 0.5), belly_from=0.7, noise=0.2),
        'head': M(base, eye=th['glow'], glow_halo=th['glow'], brow=th['dark'], noise=0.2),
        'leg': M(mix(th['dark'], th['fur2'], 0.4), pattern=pat_stripes(th['glow'] if crack else th['light'], 7, 1, True, 3), noise=0.16),
        'leg2': M(mix(th['dark'], th['fur2'], 0.2), pattern=pat_stripes(th['spot'], 9, 1, True, 5), noise=0.16),
        'tooth': M(th['light'], noise=0.08),
        'crystal': M(mix(th['spot'], th['light'], 0.3), pattern=pat_facets((255, 255, 255), th['fur2'], 3), noise=0.06),
    }

def style_scorpion(th):
    s = style_spider(th, True)
    base = mix(th['dark'], th['fur2'], 0.7)
    s['tail'] = M(base, pattern=pat_first(pat_rows(th['glow'], (0,)), pat_dots(th['spot'], 0.05, 4)), noise=0.2)
    s['sting'] = M(th['glow'], noise=0.1)
    s['claw'] = M(mix(th['dark'], th['fur2'], 0.5), pattern=pat_stripes(th['glow'], 5, 1, False, 6), noise=0.2)
    return s

def style_beetle(th):
    s = style_spider(th, False)
    shell = mix(th['fur'], th['fur2'], 0.45)
    s['shell'] = M(shell, pattern=pat_first(pat_spine(th['dark'], ('top',), 1), pat_facets(th['light'], th['fur2'], 11, 4)), belly=th['fur2'], belly_from=0.6, noise=0.1)
    s['jaw'] = M(th['light'], noise=0.06)
    s['body'] = M(th['fur2'], noise=0.16)
    s['head'] = M(shell, eye=th['glow'], glow_halo=th['glow'], noise=0.12)
    return s

# ---- humanoides
def style_human(th, mode='stalker'):
    skin, dark, cloth = th['skin'], th['skin_dark'], th['cloth']
    def rags(face, lx, ly, fw, fh, p, gx, gy):
        if face in ('front', 'back') and ly >= fh - 3 and hsh(gx, gy, 4) > 0.5: return sh(cloth, 0.6)
        if (lx + ly * 2) % 7 == 0 and hsh(gx, gy, 3) > 0.3: return sh(cloth, 0.75)
        if face == 'front' and abs(lx - (fw - 1) / 2) < 0.6 and 1 <= ly <= fh - 4 and ly % 3 != 0: return mix(th['glow'], th['fur'], 0.45)
        return None
    def scales(face, lx, ly, fw, fh, p, gx, gy):
        if (lx + (ly % 2) * 2) % 4 == 0: return sh(skin, 1.25)
        if hsh(gx, gy, 6) > 0.94: return th['alga']
        return None
    s = {
        'head': M(skin, eye=th['glow'], glow_halo=th['glow'], mouth=sh(dark, 0.4), brow=dark, noise=0.14),
        'neck': M(mix(skin, dark, 0.3), noise=0.14),
        'jaw': M(mix(skin, dark, 0.35), pattern=pat_dots((235, 232, 220), 0.12, 9, skip=('top', 'bottom', 'left', 'right')), noise=0.14),
        'torso': M(cloth, pattern=rags, belly=mix(cloth, dark, 0.5), belly_from=0.6, noise=0.18),
        'arm': M(skin, pattern=pat_stripes(dark, 3, 1, False, 3), noise=0.14),
        'forearm': M(mix(skin, dark, 0.2), pattern=pat_stripes(dark, 3, 1, False, 4), noise=0.14),
        'claw': M(th['claw'], grad=mix(th['claw'], dark, 0.4), grad_from=0.3, noise=0.1),
        'leg': M(mix(cloth, dark, 0.35), lower=mix(dark, cloth, 0.2), lower_rows=3, noise=0.16),
        'fin': M(mix(th['alga'], th['fur'], 0.4), pattern=pat_stripes(th['light'], 2, 1, False, 4), noise=0.12),
        'horn': M(th['light'], ring=mix(th['light'], dark, 0.5), noise=0.1),
        'crystal': M(mix(th['spot'], th['light'], 0.3), pattern=pat_facets((255, 255, 255), th['fur2'], 3), noise=0.06),
        'shoulder': M(th['fur'], pattern=pat_facets(th['light'], th['fur2'], 2, 3), noise=0.1),
    }
    if mode == 'lurker':
        s['head'] = M(skin, eye=th['glow'], glow_halo=th['glow'], mouth=sh(dark, 0.4), brow=dark, pattern=scales, noise=0.14)
        s['torso'] = M(mix(skin, th['cloth'], 0.4), pattern=scales, belly=th['light'], belly_from=0.5, belly_amt=0.7, noise=0.16)
        s['arm'] = M(skin, pattern=scales, noise=0.14)
        s['forearm'] = M(mix(skin, dark, 0.2), pattern=scales, noise=0.14)
        s['leg'] = M(mix(skin, dark, 0.3), pattern=scales, lower=dark, lower_rows=3, noise=0.14)
    if mode == 'golem':
        stone = mix(th['fur2'], th['cloth'], 0.4)
        facet = pat_facets(th['light'], th['dark'], 5, 4)
        for k in ('torso', 'arm', 'forearm', 'leg', 'neck'): s[k] = M(stone, pattern=facet, noise=0.12)
        s['claw'] = M(mix(th['fur'], th['light'], 0.3), pattern=facet, noise=0.1)
        s['head'] = M(mix(stone, th['fur'], 0.3), pattern=facet, eye=th['glow'], glow_halo=th['glow'], mouth=th['dark'], noise=0.12)
    return s

def style_warden(th):
    stone = mix(th['fur2'], th['cloth'], 0.5)
    def stones(face, lx, ly, fw, fh, p, gx, gy):
        if (gx % 4 == 0 or gy % 5 == 0) and hsh(gx, gy, 3) > 0.45: return sh(stone, 0.78)
        return None
    def runes(face, lx, ly, fw, fh, p, gx, gy):
        if face in ('front', 'back') and abs(lx - (fw - 1) / 2) < 0.6 and 1 <= ly <= fh - 3: return th['glow'] if ly % 2 == 1 else sh(th['glow'], 0.6)
        if face in ('front', 'back') and abs(lx - (fw - 1) / 2) in (2.0, 2.5) and ly in (2, 6): return sh(th['glow'], 0.8)
        return stones(face, lx, ly, fw, fh, p, gx, gy)
    s = style_human(th, 'golem')
    for k in ('arm', 'forearm', 'leg', 'neck'): s[k] = M(stone, pattern=stones, noise=0.14, lower=sh(stone, 0.6) if k == 'leg' else None)
    s['leg'] = M(stone, pattern=stones, lower=sh(stone, 0.55), lower_rows=3, noise=0.14)
    s['torso'] = M(stone, pattern=runes, noise=0.14)
    s['head'] = M(mix(stone, th['fur'], 0.2), pattern=stones, eye=th['glow'], glow_halo=th['glow'], mouth=th['dark'], brow=th['dark'], noise=0.14)
    s['claw'] = M(sh(stone, 0.7), pattern=stones, noise=0.14)
    s['horn'] = M(mix(th['light'], th['fur'], 0.4), ring=th['fur2'], noise=0.1)
    s['shoulder'] = M(mix(stone, th['fur'], 0.35), pattern=pat_facets(th['light'], th['dark'], 3, 3), noise=0.12)
    return s

# ================================================================= TABLA DE MOBS
V, E, A, PL, C = (THEMES[k] for k in ('violet', 'ember', 'azure', 'pale', 'crystal'))
MOBS = {
    # id: (piezas, estilo, escala visual)
    'violet_grazer':  (lambda: sp_ox(18, True, True), lambda: style_ox(V), 1.0),
    'violet_deer':    (lambda: sp_deer(2, 7, 9, 11), lambda: style_deer(V), 1.0),
    'ember_hog':      (lambda: sp_boar(15, 4, 3), lambda: style_boar(E), 1.0),
    'ember_sheep':    (lambda: sp_sheep(ram=True), lambda: style_sheep(E, True), 1.0),
    'azure_wader':    (lambda: sp_bird(11, 9, (6, 6, 10), 7, 1, True), lambda: style_bird(A), 1.0),
    'azure_grazer':   (lambda: sp_tapir(), lambda: style_tapir(A), 1.0),
    'pale_deer':      (lambda: sp_deer(3, 9, 10, 12), lambda: style_deer(PL, True), 1.1),
    'pale_hog':       (lambda: sp_boar(17, 6, 4, True), lambda: style_boar(PL, True), 1.1),
    'crystal_sheep':  (lambda: sp_sheep(crystals=True), lambda: style_sheep(C), 1.0),
    'crystal_wader':  (lambda: sp_bird(5, 5, (8, 7, 10), 4, 3, True), lambda: style_bird(C, True), 1.0),
    'violet_stalker': (lambda: sp_human((2, 16), (5, 12, 3), (2, 9, 9), (4, 5, 4), 0.35, 3, 4, jaw=True), lambda: style_human(V), 1.0),
    'pale_stalker':   (lambda: sp_human((2, 17), (5, 11, 3), (2, 10, 9), (4, 5, 4), 0.3, 3, 5, jaw=True), lambda: style_human(PL), 1.05),
    'violet_crawler': (lambda: sp_spider(), lambda: style_spider(V, True), 1.0),
    'ember_crawler':  (lambda: sp_scorpion(), lambda: style_scorpion(E), 1.0),
    'ember_howler':   (lambda: sp_wolf(flame=True), lambda: style_wolf(E), 1.0),
    'pale_howler':    (lambda: sp_wolf(), lambda: style_wolf(PL), 1.1),
    'azure_lurker':   (lambda: sp_human((3, 8), (8, 8, 5), (3, 8, 9), (8, 4, 6), 0.65, 1, 4, fins=3, jaw=True), lambda: style_human(A, 'lurker'), 1.0),
    'crystal_lurker': (lambda: sp_human((4, 9), (10, 11, 6), (4, 7, 8), (5, 5, 5), 0.12, 1, 4, crown=3, shoulders=True), lambda: style_human(C, 'golem'), 1.0),
    'azure_biter':    (lambda: sp_croc(), lambda: style_croc(A), 1.0),
    'crystal_biter':  (lambda: sp_beetle(), lambda: style_beetle(C), 1.0),
    # bosses
    'violet_warden':  (lambda: sp_human((5, 13), (12, 14, 7), (5, 9, 10), (8, 8, 8), 0.1, 1, 4, horns=True, shoulders=True), lambda: style_warden(V), 1.9),
    'crystal_queen':  (lambda: sp_spider(crown=True, legs=(8, 12), fat=True), lambda: style_spider(C, False, True), 2.4),
}

def main():
    import gen_models
    out = {}
    prev = []
    for i, (mid, (build, style, scale)) in enumerate(MOBS.items()):
        parts = build()
        tw, th = pack(parts)
        tex = paint_mob(parts, style(), tw, th, 100 + i * 13)
        tex.save(os.path.join(ROOT, 'entity', mid + '.png'))
        lo, hi = bounds(parts)
        w = max(2 * max(abs(lo[0]), abs(hi[0])), 0.55 * (hi[2] - lo[2])) / 16 * scale
        h = (24 - lo[1]) / 16 * scale
        out[mid] = dict(parts=parts, tw=tw, th=th, scale=scale, w=round(min(max(w, 0.5), 3.0), 2), h=round(max(h, 0.5), 2))
        prev.append((mid, parts, tex))
    emit_java(out)
    gen_models._PREVIEW = prev
    for mid, m in out.items():
        print(f"{mid:15s} tex {m['tw']}x{m['th']}  hitbox {m['w']}x{m['h']}")
    return out
