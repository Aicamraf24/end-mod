package com.endrealms.client;

import com.endrealms.EndRealms;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

/** Cuerpo humanoide con textura y escala propias (Guardián violeta). */
public class ScaledHumanoidRenderer extends MobRenderer<Mob, HumanoidRenderState, HumanoidModel<HumanoidRenderState>> {
    private final Identifier texture;
    private final float scale;

    public ScaledHumanoidRenderer(EntityRendererProvider.Context ctx, String name, float scale) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5F * scale);
        this.texture = EndRealms.id("textures/entity/" + name + ".png");
        this.scale = scale;
    }

    @Override
    public HumanoidRenderState createRenderState() {
        return new HumanoidRenderState();
    }

    @Override
    public Identifier getTextureLocation(HumanoidRenderState state) {
        return texture;
    }

    @Override
    protected void scale(HumanoidRenderState state, PoseStack poseStack) {
        poseStack.scale(scale, scale, scale);
    }
}
