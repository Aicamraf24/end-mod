package com.endrealms.mixin;

import com.endrealms.EndRealms;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.biome.OverworldBiomeBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Cambia 1 de cada {@code SHARE_DENOMINATOR} zonas climaticas de planicie por uno de los 5 biomas nuevos
 * cuando el juego construye la tabla de biomas del Overworld.
 * Usa la misma tecnica que Reptilia (envolver el consumidor de addBiomes, solo toca PLAINS; Reptilia solo
 * toca SWAMP), asi que los dos mods se pueden usar juntos sin pisarse.
 */
@Mixin(OverworldBiomeBuilder.class)
public abstract class OverworldBiomeBuilderMixin {
    private static final int SHARE_DENOMINATOR = 4;

    private static final List<ResourceKey<Biome>> NEW_BIOMES = List.of(
            ResourceKey.create(Registries.BIOME, EndRealms.id("violet_forest")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("ember_thicket")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("azure_marsh")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("pale_grove")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("crystal_gardens")));

    @ModifyVariable(method = "addBiomes", at = @At("HEAD"), argsOnly = true, index = 1, require = 0)
    private Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> endrealms$replacePlains(
            Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> original) {
        return pair -> {
            if (Biomes.PLAINS.equals(pair.getSecond())) {
                int h = pair.getFirst().toString().hashCode();
                if (Math.floorMod(h, SHARE_DENOMINATOR) == 0) {
                    int idx = Math.floorMod(h / SHARE_DENOMINATOR, NEW_BIOMES.size());
                    original.accept(Pair.of(pair.getFirst(), NEW_BIOMES.get(idx)));
                    return;
                }
            }
            original.accept(pair);
        };
    }
}
