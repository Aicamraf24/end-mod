# End Realms (Fabric, Minecraft Java 26.1.2)

Mod que añade 5 biomas al Overworld (cada uno con un peso de aparición de 0.25, un cuarto de un bioma normal como la planicie), cada uno con su madera completa, sapling, flor, un mob pacífico y uno hostil;
más 2 estructuras con un miniboss cada una. Todo está en la pestaña creativa **End Realms**.

## Compilar
1. JDK 25 y Gradle (o copia `gradlew`, `gradlew.bat` y `gradle/wrapper/` del Fabric Example Mod para 26.1).
2. `./gradlew build` -> el jar queda en `build/libs/`.
3. Prueba: `./gradlew runClient`.

## Contenido
| Bioma (zona del End) | Madera | Pacífico | Hostil |
|---|---|---|---|
| Bosque violeta (clima templado) | violet | Rumiante violeta | Acechador violeta |
| Arboleda de marfil (clima frío) | pale | Ciervo marfil | Aullador marfil |
| Matorral de brasa (clima seco) | ember | Jabalí de brasa | Reptante de brasa |
| Pantano azur (clima templado) | azure | Vadeador azur | Merodeador azur |
| Jardines de cristal (clima nevado) | crystal | Oveja de cristal | Mordedor de cristal |

Cada madera: tronco, tronco descortezado, madera, madera descortezada, tablones, escaleras, losa, valla, puerta de valla,
puerta, trampilla, botón, placa de presión, hojas, brote y flor. Recetas incluidas.

Estructuras (clic derecho al altar central invoca al miniboss):
- **Santuario violeta** -> Guardián violeta (humanoide, hitbox 1.32 x 4.29, 240 HP, onda de choque).
- **Colmena de cristal** -> Reina de cristal (araña, hitbox 4.48 x 2.88, 200 HP, levitación y veneno).
Ambos usan barra de jefe y sueltan diamantes, perlas y caparazones de shulker.

## Personalizar
- Tamaños y hitbox: `ModEntities.java` (`scale` por mob, `WARDEN_SCALE`, `QUEEN_SCALE`).
- Texturas: sustituye los PNG de `assets/endrealms/textures/` (las actuales son placeholders generados).
  Los mobs usan los modelos vanilla del cerdo, la araña y el zombi, así que sus PNG deben respetar esos UV.
- Todo el JSON/texturas/NBT se regenera con `python3 tools/gen_resources.py` (edita ahí nombres, colores y estructuras).

## Notas
- Los saplings crecen sobre tierra/hierba como cualquier sapling.
- No se incluyen carteles ni barcos.
