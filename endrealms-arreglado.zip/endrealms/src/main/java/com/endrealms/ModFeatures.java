package com.endrealms;

import com.endrealms.world.SurfaceGrassFeature;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;

public final class ModFeatures {
    public static void init() {
        Registry.register(BuiltInRegistries.FEATURE, EndRealms.id("surface_grass"), new SurfaceGrassFeature());
    }
}
