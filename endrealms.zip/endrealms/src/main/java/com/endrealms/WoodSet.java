package com.endrealms;

import net.fabricmc.fabric.api.object.builder.v1.block.type.BlockSetTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.block.type.WoodTypeBuilder;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.grower.TreeGrower;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.effect.MobEffects;

import java.util.Optional;

/** Una madera completa: tronco, tablones, escaleras, losas, valla, puerta, trampilla, botón, placa, hojas, brote y flor. */
public final class WoodSet {
    public final String name;
    public final BlockSetType setType;
    public final WoodType woodType;
    public final ResourceKey<ConfiguredFeature<?, ?>> treeKey;
    public final Block log, strippedLog, wood, strippedWood, planks, stairs, slab, fence, gate,
            door, trapdoor, button, plate, leaves, sapling, bloom;

    public WoodSet(String n) {
        this.name = n;
        this.setType = BlockSetTypeBuilder.copyOf(BlockSetType.OAK).register(EndRealms.id(n));
        this.woodType = WoodTypeBuilder.copyOf(WoodType.OAK).register(EndRealms.id(n), setType);
        this.treeKey = ResourceKey.create(Registries.CONFIGURED_FEATURE, EndRealms.id(n + "_tree"));

        log = ModBlocks.reg(n + "_log", RotatedPillarBlock::new, Blocks.OAK_LOG);
        strippedLog = ModBlocks.reg("stripped_" + n + "_log", RotatedPillarBlock::new, Blocks.STRIPPED_OAK_LOG);
        wood = ModBlocks.reg(n + "_wood", RotatedPillarBlock::new, Blocks.OAK_WOOD);
        strippedWood = ModBlocks.reg("stripped_" + n + "_wood", RotatedPillarBlock::new, Blocks.STRIPPED_OAK_WOOD);
        planks = ModBlocks.reg(n + "_planks", Block::new, Blocks.OAK_PLANKS);
        stairs = ModBlocks.reg(n + "_stairs", p -> new StairBlock(planks.defaultBlockState(), p), Blocks.OAK_STAIRS);
        slab = ModBlocks.reg(n + "_slab", SlabBlock::new, Blocks.OAK_SLAB);
        fence = ModBlocks.reg(n + "_fence", FenceBlock::new, Blocks.OAK_FENCE);
        gate = ModBlocks.reg(n + "_fence_gate", p -> new FenceGateBlock(woodType, p), Blocks.OAK_FENCE_GATE);
        door = ModBlocks.reg(n + "_door", p -> new DoorBlock(setType, p), Blocks.OAK_DOOR);
        trapdoor = ModBlocks.reg(n + "_trapdoor", p -> new TrapDoorBlock(setType, p), Blocks.OAK_TRAPDOOR);
        button = ModBlocks.reg(n + "_button", p -> new ButtonBlock(setType, 30, p), Blocks.OAK_BUTTON);
        plate = ModBlocks.reg(n + "_pressure_plate", p -> new PressurePlateBlock(setType, p), Blocks.OAK_PRESSURE_PLATE);
        leaves = ModBlocks.reg(n + "_leaves", p -> new TintedParticleLeavesBlock(0.01F, p), Blocks.OAK_LEAVES);
        TreeGrower grower = new TreeGrower(n, Optional.empty(), Optional.of(treeKey), Optional.empty());
        sapling = ModBlocks.reg(n + "_sapling", p -> new SaplingBlock(grower, p), Blocks.OAK_SAPLING);
        bloom = ModBlocks.reg(n + "_bloom", p -> new FlowerBlock(MobEffects.GLOWING, 6.0F, p), Blocks.DANDELION);

        StrippableBlockRegistry.register(log, strippedLog);
        StrippableBlockRegistry.register(wood, strippedWood);
    }
}
