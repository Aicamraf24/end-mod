package com.endrealms.client;

import com.endrealms.EndRealms;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.animal.pig.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

/** Cuerpo de cuadrúpedo con textura propia y escala propia (mobs pacíficos). */
public class ScaledQuadrupedRenderer extends MobRenderer<Mob, LivingEntityRenderState, PigModel> {
    private final Identifier texture;
    private final float scale;

    public ScaledQuadrupedRenderer(EntityRendererProvider.Context ctx, String name, float scale) {
        super(ctx, new PigModel(ctx.bakeLayer(ModelLayers.PIG)), 0.5F * scale);
        this.texture = EndRealms.id("textures/entity/" + name + ".png");
        this.scale = scale;
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return texture;
    }

    @Override
    protected void scale(LivingEntityRenderState state, PoseStack poseStack) {
        poseStack.scale(scale, scale, scale);
    }
}
