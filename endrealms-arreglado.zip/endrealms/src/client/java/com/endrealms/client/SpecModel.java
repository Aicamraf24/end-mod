package com.endrealms.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

import java.util.HashMap;
import java.util.Map;

/**
 * Modelo generico de cajas: lee las piezas que genera tools/gen_models.py (ver MobParts) y las anima.
 * Cada pieza lleva un codigo de animacion: 1 cabeza, 2 pata, 3 brazo, 4 cola, 5 pata de arana, 6 mandibula, 7 ala/oreja.
 */
public class SpecModel extends EntityModel<LivingEntityRenderState> {
    private static final float DEG = (float) (Math.PI / 180.0);

    private final ModelPart[] parts;
    private final int[] anim;
    private final float[] phase;

    /** Crea el modelo ya horneado para un mob (usa el id del mob, p. ej. "violet_deer"). */
    public static SpecModel create(String id) {
        String[] data = MobParts.get(id);
        return new SpecModel(createLayer(data).bakeRoot(), data);
    }

    /** Escala visual del mob (los bosses se dibujan mas grandes). */
    public static float scaleOf(String id) {
        String[] data = MobParts.get(id);
        return data == null ? 1.0F : Float.parseFloat(data[0].split(",")[2]);
    }

    public static LayerDefinition createLayer(String[] data) {
        String[] head = data[0].split(",");
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        Map<String, PartDefinition> map = new HashMap<>();
        for (int i = 1; i < data.length; i++) {
            String[] a = data[i].split("\\|");
            PartDefinition parent = a[1].equals("-") ? root : map.get(a[1]);
            CubeListBuilder cb = CubeListBuilder.create().texOffs(Integer.parseInt(a[2]), Integer.parseInt(a[3]));
            int w = Integer.parseInt(a[7]), h = Integer.parseInt(a[8]), d = Integer.parseInt(a[9]);
            if (w > 0 && h > 0 && d > 0) {
                cb = cb.addBox(Float.parseFloat(a[4]), Float.parseFloat(a[5]), Float.parseFloat(a[6]), w, h, d);
            }
            PartPose pose = PartPose.offsetAndRotation(Float.parseFloat(a[10]), Float.parseFloat(a[11]), Float.parseFloat(a[12]),
                    Float.parseFloat(a[13]), Float.parseFloat(a[14]), Float.parseFloat(a[15]));
            map.put(a[0], parent.addOrReplaceChild(a[0], cb, pose));
        }
        return LayerDefinition.create(mesh, Integer.parseInt(head[0]), Integer.parseInt(head[1]));
    }

    private SpecModel(ModelPart root, String[] data) {
        super(root);
        int n = data.length - 1;
        parts = new ModelPart[n];
        anim = new int[n];
        phase = new float[n];
        Map<String, ModelPart> map = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String[] a = data[i + 1].split("\\|");
            ModelPart parent = a[1].equals("-") ? root : map.get(a[1]);
            ModelPart part = parent.getChild(a[0]);
            map.put(a[0], part);
            parts[i] = part;
            anim[i] = Integer.parseInt(a[16]);
            phase[i] = Float.parseFloat(a[17]);
        }
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        super.setupAnim(state);
        float pos = state.walkAnimationPos;
        float spd = Math.min(state.walkAnimationSpeed, 1.0F);
        float age = state.ageInTicks;
        float yaw = clamp(state.yRot * DEG, -0.9F, 0.9F);
        float pitch = clamp(state.xRot * DEG, -0.6F, 0.6F);
        for (int i = 0; i < parts.length; i++) {
            ModelPart m = parts[i];
            float ph = phase[i];
            switch (anim[i]) {
                case 1 -> { m.yRot += yaw; m.xRot += pitch; }
                case 2 -> m.xRot += (float) Math.cos(pos * 0.6662F + ph) * 1.2F * spd;
                case 3 -> {
                    m.xRot += (float) Math.cos(pos * 0.6662F + ph) * 0.9F * spd;
                    m.zRot += (float) Math.sin(age * 0.067F + ph) * 0.04F;
                }
                case 4 -> m.yRot += (float) Math.sin(age * 0.12F + ph) * 0.12F + (float) Math.cos(pos * 0.6662F + ph) * 0.35F * spd;
                case 5 -> m.yRot += (float) Math.sin(pos * 1.3F + ph) * 0.45F * spd;
                case 6 -> m.xRot += ((float) Math.sin(age * 0.15F) * 0.5F + 0.5F) * 0.12F;
                case 7 -> m.zRot += (float) Math.sin(age * 0.2F + ph) * 0.03F;
                default -> { }
            }
        }
    }
}
