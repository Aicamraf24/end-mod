package com.endrealms.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import java.util.function.Supplier;

/**
 * Altar en el centro de cada estructura. Se activa con clic derecho sobre el bloque, mirandolo,
 * llevando una Estrella del Nether en la mano: consume la estrella e invoca al miniboss (una sola vez).
 */
public class BossAltarBlock extends Block {
    private final Supplier<? extends EntityType<? extends Mob>> boss;

    public BossAltarBlock(Supplier<? extends EntityType<? extends Mob>> boss, Properties props) {
        super(props);
        this.boss = boss;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        // Se llama con clic derecho (con cualquier objeto que no use el bloque): se busca la estrella en ambas manos.
        InteractionHand hand = null;
        if (player.getMainHandItem().is(Items.NETHER_STAR)) hand = InteractionHand.MAIN_HAND;
        else if (player.getOffhandItem().is(Items.NETHER_STAR)) hand = InteractionHand.OFF_HAND;

        if (hand == null) {
            if (level instanceof ServerLevel) {
                player.displayClientMessage(Component.translatable("message.endrealms.altar_needs_star"), true);
            }
            return InteractionResult.SUCCESS;
        }
        if (level instanceof ServerLevel server) {
            if (!player.isCreative()) {
                ItemStack star = player.getItemInHand(hand);
                star.shrink(1);
            }
            server.removeBlock(pos, false);
            boss.get().spawn(server, pos, EntitySpawnReason.TRIGGERED);
        }
        return InteractionResult.SUCCESS;
    }
}
