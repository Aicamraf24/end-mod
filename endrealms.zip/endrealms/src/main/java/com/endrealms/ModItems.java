package com.endrealms;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

import java.util.Map;

public final class ModItems {
    public static void init() {
        for (Map.Entry<String, EntityType<? extends net.minecraft.world.entity.Mob>> e : ModEntities.TYPES.entrySet()) {
            ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, EndRealms.id(e.getKey() + "_spawn_egg"));
            SpawnEggItem egg = new SpawnEggItem(new Item.Properties().setId(key).spawnEgg(e.getValue()));
            Registry.register(BuiltInRegistries.ITEM, key, egg);
            ModBlocks.TAB_ITEMS.add(egg);
        }
    }
}
