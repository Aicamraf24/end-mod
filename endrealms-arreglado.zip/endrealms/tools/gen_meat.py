"""Iconos 16x16 de la carne de cada mob (cruda y cocinada). Cada mob tiene su forma y el color de su bioma."""
import os, math
from gen_textures import rgb, sh, mix, hsh, vnoise, Tex, ROOT

# mob -> (forma, bioma, alimento crudo vanilla, alimento cocinado vanilla). Los alimentos los usa ModItems.java.
MEATS = {
    'violet_grazer': ('steak', 'violet'), 'violet_deer': ('leg', 'violet'), 'violet_stalker': ('chunk', 'violet'), 'violet_crawler': ('chunk', 'violet'),
    'ember_hog': ('chop', 'ember'), 'ember_sheep': ('leg', 'ember'), 'ember_crawler': ('chunk', 'ember'), 'ember_howler': ('steak', 'ember'),
    'azure_wader': ('drumstick', 'azure'), 'azure_grazer': ('steak', 'azure'), 'azure_lurker': ('chop', 'azure'), 'azure_biter': ('chunk', 'azure'),
    'pale_deer': ('leg', 'pale'), 'pale_hog': ('chop', 'pale'), 'pale_howler': ('steak', 'pale'), 'pale_stalker': ('chop', 'pale'),
    'crystal_sheep': ('leg', 'crystal'), 'crystal_wader': ('drumstick', 'crystal'), 'crystal_biter': ('chunk', 'crystal'), 'crystal_lurker': ('chunk', 'crystal'),
}
RAW = {  # (carne, grasa)
    'violet': (rgb(0xb0489a), rgb(0xf4d4f4)), 'ember': (rgb(0xc8381c), rgb(0xf6cca4)),
    'azure': (rgb(0x3a8fa8), rgb(0xd8f4f0)), 'pale': (rgb(0xe0a098), rgb(0xfff2ea)),
    'crystal': (rgb(0x86cce6), rgb(0xfae4ff)),
}
BONE = rgb(0xf0ead8)

def ell(x, y, cx, cy, rx, ry, rot=0.0):
    dx, dy = x - cx, y - cy
    c, s = math.cos(rot), math.sin(rot)
    u, v = dx * c + dy * s, -dx * s + dy * c
    return (u / rx) ** 2 + (v / ry) ** 2

def masks(shape, seed):
    meat, bone = set(), set()
    for y in range(16):
        for x in range(16):
            px, py = x + 0.5, y + 0.5
            w = (vnoise(x, y, 2.5, seed) - 0.5) * 0.35
            if shape == 'steak':
                if ell(px, py, 8, 8.6, 6.6, 4.9, -0.45) + w < 1: meat.add((x, y))
            elif shape == 'chop':
                if ell(px, py, 7.6, 8.4, 5.6, 5.2, 0.3) + w < 1 or ell(px, py, 5, 6.5, 3.2, 3.2) + w < 1: meat.add((x, y))
                if 11 <= x <= 14 and 3 <= y <= 6 and (x - 11) + (6 - y) >= 1 and (x, y) not in meat: bone.add((x, y))
            elif shape in ('leg', 'drumstick'):
                big = (5.2, 4.4) if shape == 'leg' else (4.6, 4.2)
                if ell(px, py, 6, 9.4, big[0], big[1], 0.7) + w < 1: meat.add((x, y))
                d = abs((px - 9.0) * 0.707 + (py - 7.0) * 0.707)       # eje del hueso: diagonal hacia arriba a la derecha
                along = (px - 9.0) * 0.707 - (py - 7.0) * 0.707
                if d < (1.0 if shape == 'drumstick' else 1.1) and 0 < along < 5.4 and (x, y) not in meat: bone.add((x, y))
                if ell(px, py, 13.2, 2.8, 1.7, 1.7) < 1: bone.add((x, y))
            else:  # chunk: pedazo irregular
                if min(ell(px, py, 7, 8, 4.6, 4.2), ell(px, py, 10, 9.4, 3.8, 3.4), ell(px, py, 6, 11, 3.4, 3.2)) + w * 1.6 < 1: meat.add((x, y))
    return meat, bone

def draw(mob, cooked):
    shape, theme = MEATS[mob]
    seed = sum(map(ord, mob))
    meat_c, fat_c = RAW[theme]
    if cooked:
        meat_c = mix(mix(meat_c, rgb(0x93501f), 0.8), rgb(0x2a1608), 0.06)
        fat_c = mix(fat_c, rgb(0xd09a5a), 0.55)
    t = Tex(16, 16)
    meat, bone = masks(shape, seed)
    solid = meat | bone
    for (x, y) in sorted(solid):
        edge = any((x + dx, y + dy) not in solid for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        if (x, y) in bone:
            c = sh(BONE, 1.08 - 0.02 * (x + y - 12) * 0.5)
            if edge: c = sh(c, 0.62)
            t.put(x, y, c); continue
        c = sh(meat_c, 1.2 - 0.027 * (x + y))                       # luz arriba a la izquierda
        n = vnoise(x, y, 1.8, seed + 3)
        c = sh(c, 0.9 + 0.2 * n)
        # veteado de grasa
        v = vnoise(x * 1.3 + y * 0.6, y, 2.2, seed + 9)
        if abs(v - 0.5) < 0.06 and not cooked: c = mix(c, fat_c, 0.8)
        if abs(v - 0.5) < 0.05 and cooked: c = sh(c, 0.78)
        # borde claro (grasa) en el lado iluminado
        if (x - 1, y - 1) not in solid or (x, y - 1) not in solid and (x - 1, y) not in solid: c = mix(c, fat_c, 0.6 if not cooked else 0.35)
        if cooked and shape in ('steak', 'chop', 'chunk') and (x + y) % 5 == 0 and hsh(x, y, seed) > 0.15: c = sh(c, 0.7)   # marcas de parrilla
        if cooked and hsh(x, y, seed + 4) > 0.93: c = sh(c, 1.25)                                                  # brillos
        if not cooked and theme == 'crystal' and hsh(x, y, seed + 5) > 0.93: c = rgb(0xff9bf5)
        if not cooked and theme == 'violet' and hsh(x, y, seed + 6) > 0.95: c = rgb(0xffb4ff)
        if edge: c = sh(c, 0.5)
        t.put(x, y, c)
    return t

def main():
    d = os.path.join(ROOT, 'item')
    os.makedirs(d, exist_ok=True)
    for mob in MEATS:
        draw(mob, False).save(os.path.join(d, f'{mob}_meat.png'))
        draw(mob, True).save(os.path.join(d, f'cooked_{mob}_meat.png'))

if __name__ == '__main__':
    main()
