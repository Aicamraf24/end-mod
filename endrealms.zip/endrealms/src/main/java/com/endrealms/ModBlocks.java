package com.endrealms;

import com.endrealms.block.BossAltarBlock;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class ModBlocks {
    public static final List<String> WOOD_NAMES = List.of("violet", "ember", "azure", "pale", "crystal");
    public static final List<WoodSet> WOODS = new ArrayList<>();
    /** Todo lo que va a la pestaña creativa (en orden). */
    public static final List<ItemLike> TAB_ITEMS = new ArrayList<>();
    public static Block VIOLET_ALTAR, CRYSTAL_ALTAR;

    public static <B extends Block> B reg(String id, Function<BlockBehaviour.Properties, B> factory, Block copyFrom) {
        return reg(id, factory, BlockBehaviour.Properties.ofFullCopy(copyFrom));
    }

    public static <B extends Block> B reg(String id, Function<BlockBehaviour.Properties, B> factory, BlockBehaviour.Properties props) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, EndRealms.id(id));
        B block = factory.apply(props.setId(key));
        Registry.register(BuiltInRegistries.BLOCK, key, block);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, EndRealms.id(id));
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        TAB_ITEMS.add(item);
        return block;
    }

    public static void init() {
        for (String n : WOOD_NAMES) WOODS.add(new WoodSet(n));
        VIOLET_ALTAR = reg("violet_altar",
                p -> new BossAltarBlock(() -> ModEntities.VIOLET_WARDEN, p),
                BlockBehaviour.Properties.ofFullCopy(Blocks.CRYING_OBSIDIAN).strength(50.0F, 1200.0F));
        CRYSTAL_ALTAR = reg("crystal_altar",
                p -> new BossAltarBlock(() -> ModEntities.CRYSTAL_QUEEN, p),
                BlockBehaviour.Properties.ofFullCopy(Blocks.AMETHYST_BLOCK).strength(50.0F, 1200.0F));
    }
}
