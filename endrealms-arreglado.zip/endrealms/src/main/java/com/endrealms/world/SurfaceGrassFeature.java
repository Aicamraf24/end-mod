package com.endrealms.world;

import com.endrealms.EndRealms;
import com.endrealms.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

import java.util.List;

/**
 * Cambia la superficie de piedra del End de cada bioma de End Realms por el bloque de pasto de ese bioma
 * (como los nylium del Nether: la base sigue siendo piedra del End, solo cambia la capa de arriba).
 */
public class SurfaceGrassFeature extends Feature<NoneFeatureConfiguration> {
    /** Mismo orden que ModBlocks.WOOD_NAMES / ModBlocks.GRASS_BLOCKS. */
    private static final List<ResourceKey<Biome>> BIOMES = List.of(
            key("violet_forest"), key("ember_thicket"), key("azure_marsh"), key("pale_grove"), key("crystal_gardens"));

    private static ResourceKey<Biome> key(String id) {
        return ResourceKey.create(Registries.BIOME, EndRealms.id(id));
    }

    public SurfaceGrassFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        boolean placed = false;
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;
                int y = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
                pos.set(x, y, z);
                if (!level.getBlockState(pos).is(Blocks.END_STONE)) continue;
                Holder<Biome> biome = level.getBiome(pos);
                for (int i = 0; i < BIOMES.size(); i++) {
                    if (biome.is(BIOMES.get(i))) {
                        Block grass = ModBlocks.GRASS_BLOCKS.get(i);
                        level.setBlock(pos, grass.defaultBlockState(), 2);
                        placed = true;
                        break;
                    }
                }
            }
        }
        return placed;
    }
}
