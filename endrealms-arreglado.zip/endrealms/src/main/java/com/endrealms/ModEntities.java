package com.endrealms;

import com.endrealms.entity.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModEntities {
    /** Estadisticas de cada mob. La hitbox (ancho x alto) sale de su modelo: ver MobDims (generado por tools/gen_models.py). */
    public record MobDef(String id, boolean hostile, double hp, double speed, double damage) {}

    public static final List<MobDef> DEFS = List.of(
            new MobDef("violet_grazer", false, 12, 0.22, 0),
            new MobDef("violet_stalker", true, 26, 0.30, 4),
            new MobDef("ember_hog", false, 20, 0.20, 0),
            new MobDef("ember_crawler", true, 18, 0.34, 3),
            new MobDef("azure_wader", false, 8, 0.25, 0),
            new MobDef("azure_lurker", true, 34, 0.26, 6),
            new MobDef("pale_deer", false, 24, 0.24, 0),
            new MobDef("pale_howler", true, 28, 0.31, 5),
            new MobDef("crystal_sheep", false, 14, 0.21, 0),
            new MobDef("crystal_biter", true, 22, 0.33, 4),
            // Variantes: otra forma de mob con los colores de este bioma
            new MobDef("violet_deer", false, 22, 0.25, 0),
            new MobDef("ember_sheep", false, 14, 0.21, 0),
            new MobDef("azure_grazer", false, 14, 0.22, 0),
            new MobDef("pale_hog", false, 20, 0.20, 0),
            new MobDef("crystal_wader", false, 8, 0.25, 0),
            new MobDef("violet_crawler", true, 20, 0.34, 3),
            new MobDef("ember_howler", true, 28, 0.31, 5),
            new MobDef("azure_biter", true, 22, 0.33, 4),
            new MobDef("pale_stalker", true, 26, 0.30, 4),
            new MobDef("crystal_lurker", true, 34, 0.26, 6)
    );

    public static final Map<String, EntityType<? extends Mob>> TYPES = new LinkedHashMap<>();
    public static EntityType<VioletWarden> VIOLET_WARDEN;
    public static EntityType<CrystalQueen> CRYSTAL_QUEEN;

    private static <T extends Entity> EntityType<T> reg(String id, EntityType.Builder<T> builder) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, EndRealms.id(id));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
    }

    /** Pacificos: sobre piedra del End, tierra o los bloques de pasto de End Realms. El End no tiene luz del cielo, asi que no se exige luz. */
    private static boolean peacefulRule(EntityType<?> t, ServerLevelAccessor l, EntitySpawnReason r, BlockPos p, RandomSource rnd) {
        var below = l.getBlockState(p.below());
        return below.is(Blocks.END_STONE) || below.is(BlockTags.DIRT);
    }

    /** Hostiles: la misma regla que los pacificos (suelo del bioma, sin exigir oscuridad). En el End no hay dia ni noche. */
    private static boolean hostileRule(EntityType<?> t, ServerLevelAccessor l, EntitySpawnReason r, BlockPos p, RandomSource rnd) {
        return peacefulRule(t, l, r, p, rnd);
    }

    public static void init() {
        for (MobDef d : DEFS) {
            float[] dim = MobDims.get(d.id());
            float w = dim[0], h = dim[1];
            if (d.hostile()) {
                EntityType<EndMonster> t = reg(d.id(), EntityType.Builder.of(EndMonster::new, MobCategory.MONSTER)
                        .sized(w, h).clientTrackingRange(8));
                FabricDefaultAttributeRegistry.register(t, EndMonster.attrs(d.hp(), d.speed(), d.damage()));
                SpawnPlacements.register(t, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ModEntities::hostileRule);
                TYPES.put(d.id(), t);
            } else {
                EntityType<EndCreature> t = reg(d.id(), EntityType.Builder.of(EndCreature::new, MobCategory.MONSTER)
                        .sized(w, h).clientTrackingRange(8));
                FabricDefaultAttributeRegistry.register(t, EndCreature.attrs(d.hp(), d.speed()));
                SpawnPlacements.register(t, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ModEntities::peacefulRule);
                TYPES.put(d.id(), t);
            }
        }
        VIOLET_WARDEN = reg("violet_warden", EntityType.Builder.of(VioletWarden::new, MobCategory.MONSTER)
                .sized(MobDims.get("violet_warden")[0], MobDims.get("violet_warden")[1]).clientTrackingRange(10).fireImmune());
        FabricDefaultAttributeRegistry.register(VIOLET_WARDEN, EndMiniboss.bossAttrs(240, 12, 0.26));
        CRYSTAL_QUEEN = reg("crystal_queen", EntityType.Builder.of(CrystalQueen::new, MobCategory.MONSTER)
                .sized(MobDims.get("crystal_queen")[0], MobDims.get("crystal_queen")[1]).clientTrackingRange(10).fireImmune());
        FabricDefaultAttributeRegistry.register(CRYSTAL_QUEEN, EndMiniboss.bossAttrs(200, 10, 0.32));
        TYPES.put("violet_warden", VIOLET_WARDEN);
        TYPES.put("crystal_queen", CRYSTAL_QUEEN);
    }
}
