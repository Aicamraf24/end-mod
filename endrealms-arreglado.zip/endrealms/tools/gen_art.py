"""Ayudas de pixel art para iconos y texturas de bloques: sombreado por bandas sobre formas elipsoidales."""
import math
from gen_textures import rgb, sh, mix, hsh, vnoise, Tex

LIGHT = (-0.45, -0.62, 0.64)    # luz desde arriba a la izquierda (x, y, z)
_n = math.sqrt(sum(v * v for v in LIGHT)); LIGHT = tuple(v / _n for v in LIGHT)

def blob(ellipses):
    """ellipses: lista de (cx, cy, rx, ry, rot). Devuelve {(x,y): brillo 0..1} para los pixeles cubiertos."""
    out = {}
    for y in range(16):
        for x in range(16):
            best = None
            for (cx, cy, rx, ry, rot) in ellipses:
                dx, dy = x + 0.5 - cx, y + 0.5 - cy
                c, s = math.cos(rot), math.sin(rot)
                u, v = (dx * c + dy * s) / rx, (-dx * s + dy * c) / ry
                d = u * u + v * v
                if d >= 1: continue
                z = math.sqrt(1 - d)
                # normal local -> mundo
                nx, ny = u / rx, v / ry
                wx, wy = nx * c - ny * s, nx * s + ny * c
                nl = math.sqrt(wx * wx + wy * wy + z * z * 0.35) or 1
                nvec = (wx / nl, wy / nl, z * 0.6 / nl)
                b = nvec[0] * LIGHT[0] + nvec[1] * LIGHT[1] + nvec[2] * LIGHT[2]
                if best is None or z > best[0]: best = (z, b)
            if best is not None: out[(x, y)] = max(0.0, min(1.0, best[1] * 0.75 + 0.35))
    return out

def band(b, ramp):
    """b 0..1 -> color de la rampa [oscuro, medio, claro, brillo] por bandas."""
    return ramp[0] if b < 0.38 else ramp[1] if b < 0.6 else ramp[2] if b < 0.84 else ramp[3]

def ramp_from(base, spread=0.28):
    return [sh(base, 1 - spread * 1.25), sh(base, 1 - spread * 0.35), sh(base, 1 + spread * 0.45), sh(base, 1 + spread * 1.1)]

def paint_blob(t, pixels, ramp, outline=None, detail=None):
    solid = set(pixels)
    for (x, y), b in sorted(pixels.items()):
        c = band(b, ramp)
        if detail:
            r = detail(x, y, b, c)
            if r is not None: c = r
        edge = any((x + dx, y + dy) not in solid for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        if edge: c = outline if outline is not None else sh(ramp[0], 0.55)
        t.put(x, y, c)
