package com.endrealms;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class EndRealms implements ModInitializer {
    public static final String MOD_ID = "endrealms";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModFeatures.init();
        ModBlocks.init();
        ModEntities.init();
        ModItems.init();
        ModBiomes.init();
        ModTab.init();
    }
}
