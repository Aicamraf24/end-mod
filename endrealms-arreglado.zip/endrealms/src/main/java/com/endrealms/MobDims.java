package com.endrealms;

/** GENERADO por tools/gen_models.py: hitbox (ancho, alto) de cada mob. */
public final class MobDims {
    private MobDims() {}

    public static float[] get(String id) {
        switch (id) {
            case "violet_grazer": return new float[] {1.02F, 1.47F};
            case "violet_deer": return new float[] {0.97F, 2.14F};
            case "ember_hog": return new float[] {0.93F, 1.27F};
            case "ember_sheep": return new float[] {1.06F, 1.25F};
            case "azure_wader": return new float[] {0.89F, 1.8F};
            case "azure_grazer": return new float[] {1.06F, 1.27F};
            case "pale_deer": return new float[] {1.08F, 2.6F};
            case "pale_hog": return new float[] {1.19F, 1.4F};
            case "crystal_sheep": return new float[] {0.82F, 1.6F};
            case "crystal_wader": return new float[] {0.73F, 1.26F};
            case "violet_stalker": return new float[] {0.62F, 2.08F};
            case "pale_stalker": return new float[] {0.66F, 2.2F};
            case "violet_crawler": return new float[] {1.53F, 0.81F};
            case "ember_crawler": return new float[] {1.29F, 1.88F};
            case "ember_howler": return new float[] {1.11F, 1.32F};
            case "pale_howler": return new float[] {1.22F, 1.45F};
            case "azure_lurker": return new float[] {0.94F, 1.21F};
            case "crystal_lurker": return new float[] {1.25F, 1.81F};
            case "azure_biter": return new float[] {1.62F, 0.69F};
            case "crystal_biter": return new float[] {1.31F, 1.01F};
            case "violet_warden": return new float[] {2.85F, 4.5F};
            case "crystal_queen": return new float[] {3F, 2.62F};
            default: return new float[] {0.9F, 0.9F};
        }
    }
}
