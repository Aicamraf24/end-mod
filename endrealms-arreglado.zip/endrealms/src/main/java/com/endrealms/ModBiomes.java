package com.endrealms;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.TheEndBiomes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;

public final class ModBiomes {
    private static ResourceKey<Biome> key(String id) {
        return ResourceKey.create(Registries.BIOME, EndRealms.id(id));
    }

    /** bioma, 2 mobs pacificos, 2 mobs hostiles */
    private static final String[][] SPAWNS = {
            {"violet_forest", "violet_grazer", "violet_deer", "violet_stalker", "violet_crawler"},
            {"ember_thicket", "ember_hog", "ember_sheep", "ember_crawler", "ember_howler"},
            {"azure_marsh", "azure_wader", "azure_grazer", "azure_lurker", "azure_biter"},
            {"pale_grove", "pale_deer", "pale_hog", "pale_howler", "pale_stalker"},
            {"crystal_gardens", "crystal_sheep", "crystal_wader", "crystal_biter", "crystal_lurker"}
    };

    public static void init() {
        // Los 5 biomas se reparten por las islas exteriores del End (las "tierras altas"), junto al bioma vanilla.
        for (String[] s : SPAWNS) {
            TheEndBiomes.addHighlandsBiome(key(s[0]), 1.0);
            // tambien en las zonas intermedias y yermas junto a cada tierra alta, para que ocupen mas terreno
            TheEndBiomes.addMidlandsBiome(key(s[0]), key(s[0]), 1.0);
            TheEndBiomes.addBarrensBiome(key(s[0]), key(s[0]), 1.0);
        }

        // Los mobs se anaden por codigo (no por JSON). Aparecen como los Endermen del End: reaparecen de forma continua y se
        // retiran solos al alejarte (categoria MONSTER). Dentro de cada bioma dominan sus 4 mobs, en grupos de 3 a 6, y los
        // Endermen quedan casi testimoniales (peso 2 frente a 36) para que no saturen el spawn.
        for (String[] s : SPAWNS) {
            var selector = BiomeSelectors.includeByKey(key(s[0]));
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, EntityType.ENDERMAN, 2, 1, 2);
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, ModEntities.TYPES.get(s[1]), 10, 3, 6);
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, ModEntities.TYPES.get(s[2]), 8, 3, 6);
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, ModEntities.TYPES.get(s[3]), 10, 3, 6);
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, ModEntities.TYPES.get(s[4]), 8, 3, 6);
        }
    }
}
