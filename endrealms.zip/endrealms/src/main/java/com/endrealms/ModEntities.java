package com.endrealms;

import com.endrealms.entity.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModEntities {
    /** scale = tamaño visual Y de hitbox (la hitbox se calcula a partir del modelo base por la escala). */
    public record MobDef(String id, boolean hostile, float scale, double hp, double speed, double damage) {}

    public static final List<MobDef> DEFS = List.of(
            new MobDef("violet_grazer", false, 1.0F, 12, 0.22, 0),
            new MobDef("violet_stalker", true, 1.1F, 26, 0.30, 4),
            new MobDef("ember_hog", false, 1.4F, 20, 0.20, 0),
            new MobDef("ember_crawler", true, 0.8F, 18, 0.34, 3),
            new MobDef("azure_wader", false, 0.7F, 8, 0.25, 0),
            new MobDef("azure_lurker", true, 1.5F, 34, 0.26, 6),
            new MobDef("pale_deer", false, 1.6F, 24, 0.24, 0),
            new MobDef("pale_howler", true, 1.2F, 28, 0.31, 5),
            new MobDef("crystal_sheep", false, 1.1F, 14, 0.21, 0),
            new MobDef("crystal_biter", true, 0.9F, 22, 0.33, 4)
    );

    public static final Map<String, EntityType<? extends Mob>> TYPES = new LinkedHashMap<>();
    public static EntityType<VioletWarden> VIOLET_WARDEN;
    public static EntityType<CrystalQueen> CRYSTAL_QUEEN;

    // Tamaños de los minibosses (ancho x alto de hitbox) y escala visual.
    public static final float WARDEN_SCALE = 2.2F;   // humanoide base 0.6 x 1.95
    public static final float QUEEN_SCALE = 3.2F;    // araña base 1.4 x 0.9

    private static <T extends Entity> EntityType<T> reg(String id, EntityType.Builder<T> builder) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, EndRealms.id(id));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
    }

    /** Pacificos: sobre tierra/hierba y con luz. */
    private static boolean peacefulRule(EntityType<?> t, ServerLevelAccessor l, EntitySpawnReason r, BlockPos p, RandomSource rnd) {
        return l.getBlockState(p.below()).is(BlockTags.DIRT) && l.getMaxLocalRawBrightness(p) > 8;
    }

    /** Hostiles: sobre cualquier suelo solido y con poca luz (noche o cuevas). */
    private static boolean hostileRule(EntityType<?> t, ServerLevelAccessor l, EntitySpawnReason r, BlockPos p, RandomSource rnd) {
        return !l.getBlockState(p.below()).isAir() && l.getMaxLocalRawBrightness(p) <= 7;
    }

    public static void init() {
        for (MobDef d : DEFS) {
            float h = 0.9F * d.scale();
            if (d.hostile()) {
                EntityType<EndMonster> t = reg(d.id(), EntityType.Builder.of(EndMonster::new, MobCategory.MONSTER)
                        .sized(1.4F * d.scale(), h).clientTrackingRange(8));
                FabricDefaultAttributeRegistry.register(t, EndMonster.attrs(d.hp(), d.speed(), d.damage()));
                SpawnPlacements.register(t, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ModEntities::hostileRule);
                TYPES.put(d.id(), t);
            } else {
                EntityType<EndCreature> t = reg(d.id(), EntityType.Builder.of(EndCreature::new, MobCategory.CREATURE)
                        .sized(0.9F * d.scale(), h).clientTrackingRange(8));
                FabricDefaultAttributeRegistry.register(t, EndCreature.attrs(d.hp(), d.speed()));
                SpawnPlacements.register(t, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ModEntities::peacefulRule);
                TYPES.put(d.id(), t);
            }
        }
        VIOLET_WARDEN = reg("violet_warden", EntityType.Builder.of(VioletWarden::new, MobCategory.MONSTER)
                .sized(0.6F * WARDEN_SCALE, 1.95F * WARDEN_SCALE).clientTrackingRange(10).fireImmune());
        FabricDefaultAttributeRegistry.register(VIOLET_WARDEN, EndMiniboss.bossAttrs(240, 12, 0.26));
        CRYSTAL_QUEEN = reg("crystal_queen", EntityType.Builder.of(CrystalQueen::new, MobCategory.MONSTER)
                .sized(1.4F * QUEEN_SCALE, 0.9F * QUEEN_SCALE).clientTrackingRange(10).fireImmune());
        FabricDefaultAttributeRegistry.register(CRYSTAL_QUEEN, EndMiniboss.bossAttrs(200, 10, 0.32));
        TYPES.put("violet_warden", VIOLET_WARDEN);
        TYPES.put("crystal_queen", CRYSTAL_QUEEN);
    }
}
