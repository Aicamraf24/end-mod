package com.endrealms.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Reina de cristal: araña colosal. Su veneno hace levitar y envenena. */
public class CrystalQueen extends EndMiniboss {
    public CrystalQueen(EntityType<? extends CrystalQueen> type, Level level) {
        super(type, level, BossEvent.BossBarColor.PINK);
    }

    @Override
    protected void ability(ServerLevel level, Player target) {
        target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 1));
        target.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 1));
    }
}
