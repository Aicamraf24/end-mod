package com.endrealms.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Guardián violeta: humanoide gigante. Onda de choque que empuja y ralentiza. */
public class VioletWarden extends EndMiniboss {
    public VioletWarden(EntityType<? extends VioletWarden> type, Level level) {
        super(type, level, BossEvent.BossBarColor.PURPLE);
    }

    @Override
    protected void ability(ServerLevel level, Player target) {
        Vec3 push = target.position().subtract(position()).normalize().scale(1.2).add(0, 0.5, 0);
        target.setDeltaMovement(target.getDeltaMovement().add(push));
        target.hurtMarked = true;
        target.hurtServer(level, damageSources().mobAttack(this), 6.0F);
        target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 1));
    }
}
