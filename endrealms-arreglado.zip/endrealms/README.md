# End Realms (Fabric, Minecraft Java 26.1.2)

Mod que añade 5 biomas al Overworld (reemplazan 1 de cada 4 zonas de planicie, rotando entre los 5; se cambia en `SHARE_DENOMINATOR` de `OverworldBiomeBuilderMixin`), cada uno con su madera completa, sapling, flor, un mob pacífico y uno hostil;
más 2 estructuras con un miniboss cada una. Todo está en la pestaña creativa **End Realms**.

## Compilar
1. JDK 25 y Gradle (o copia `gradlew`, `gradlew.bat` y `gradle/wrapper/` del Fabric Example Mod para 26.1).
2. `./gradlew build` -> el jar queda en `build/libs/`.
3. Prueba: `./gradlew runClient`.

## Contenido
| Bioma (zona del End) | Madera | Pacífico | Hostil |
|---|---|---|---|
| Bosque violeta (clima templado) | violet | Rumiante violeta | Acechador violeta |
| Arboleda de marfil (clima frío) | pale | Ciervo marfil | Aullador marfil |
| Matorral de brasa (clima seco) | ember | Jabalí de brasa | Reptante de brasa |
| Pantano azur (clima templado) | azure | Vadeador azur | Merodeador azur |
| Jardines de cristal (clima nevado) | crystal | Oveja de cristal | Mordedor de cristal |

Cada madera: tronco, tronco descortezado, madera, madera descortezada, tablones, escaleras, losa, valla, puerta de valla,
puerta, trampilla, botón, placa de presión, hojas, brote y flor. Recetas incluidas.

Estructuras (clic derecho al altar central invoca al miniboss):
- **Santuario violeta** -> Guardián violeta (humanoide, hitbox 1.32 x 4.29, 240 HP, onda de choque).
- **Colmena de cristal** -> Reina de cristal (araña, hitbox 4.48 x 2.88, 200 HP, levitación y veneno).
Ambos usan barra de jefe y sueltan diamantes, perlas y caparazones de shulker.

## Personalizar
- Tamaños y hitbox: `ModEntities.java` (`scale` por mob, `WARDEN_SCALE`, `QUEEN_SCALE`).
- Texturas: sustituye los PNG de `assets/endrealms/textures/` (las actuales son placeholders generados).
  Los mobs usan los modelos vanilla del cerdo, la araña y el zombi, así que sus PNG deben respetar esos UV.
- Todo el JSON/texturas/NBT se regenera con `python3 tools/gen_resources.py` (edita ahí nombres, colores y estructuras).

## Notas
- Los saplings crecen sobre tierra/hierba como cualquier sapling.
- No se incluyen carteles ni barcos.

## Entrar al mundo / compatibilidad
- Si el juego no te deja entrar o crear el mundo, abre `.minecraft/logs/latest.log` (o `crash-reports/`) y busca las lineas con `ERROR` o `Failed to load registries`: dicen que archivo falla.
- Las recetas de madera/madera descortezada tenian `endrealms:` dentro del nombre del archivo (invalido); ya se llaman `azure_wood.json`, etc.
- El reparto de biomas usa `hashCode()` del punto de clima (antes usaba su texto, que depende del idioma del sistema).
- Los 5 biomas estan en la etiqueta `#minecraft:is_overworld`, asi otros mods (cápsulas, acechador, Reptilia) los tratan como Overworld.

## Compatibilidad con Reptilia
- Ids distintos (`endrealms:` y `reptilia:`), configuracion de mixins distinta y sin tocar los mismos biomas:
  End Realms reemplaza zonas de PLANICIE y Reptilia reemplaza zonas de PANTANO, asi que conviven.
- Los formatos de biomas, arboles y filtros de colocacion siguen los mismos que usa Reptilia.
- Ambos mods anaden sus maderas a las etiquetas vanilla (`logs`, `planks`, `saplings`, ...): se fusionan solas.
