"""Texturas de End Realms: mobs (sobre las UV de los modelos de vanilla) y troncos.
Uso:  python3 tools/gen_textures.py
Cada mob usa el mismo mapa UV que el modelo base: cerdo (cuadrupedos), arana, zombi (humanoides).
Las zonas sin usar quedan transparentes (si no, la capa 'hat' del humanoide se veria como una caja)."""
import os, math
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, '..', 'src', 'main', 'resources', 'assets', 'endrealms', 'textures')

# ---------------------------------------------------------------- utilidades
def rgb(c): return ((c >> 16) & 255, (c >> 8) & 255, c & 255)
def sh(c, f): return tuple(max(0, min(255, int(v * f))) for v in c)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def hsh(x, y, s=0):
    n = (x * 374761393 + y * 668265263 + s * 2147483647) & 0xffffffff
    n = ((n ^ (n >> 13)) * 1274126177) & 0xffffffff
    return ((n ^ (n >> 16)) & 0xffff) / 65535.0

def vnoise(x, y, sc, s=0):
    fx, fy = x / sc, y / sc
    x0, y0 = math.floor(fx), math.floor(fy)
    tx, ty = fx - x0, fy - y0
    tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
    a, b = hsh(x0, y0, s), hsh(x0 + 1, y0, s)
    c, d = hsh(x0, y0 + 1, s), hsh(x0 + 1, y0 + 1, s)
    return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty

class Tex:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.im = Image.new('RGBA', (w, h), (0, 0, 0, 0))
        self.px = self.im.load()
    def put(self, x, y, c, a=255):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[x, y] = (*c[:3], a)
    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.im.save(path)

def faces(u, v, w, h, d):
    return {'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d), 'right': (u, v + d, d, h),
            'front': (u + d, v + d, w, h), 'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h)}

def box(t, u, v, w, h, d, fn):
    """fn(cara, lx, ly, ancho, alto) -> color RGB o None."""
    for name, (x, y, fw, fh) in faces(u, v, w, h, d).items():
        for ly in range(fh):
            for lx in range(fw):
                c = fn(name, lx, ly, fw, fh)
                if c is not None:
                    t.put(x + lx, y + ly, c)

def fur(x, y, base, seed, amt=0.12):
    return sh(base, 1 - amt + 2 * amt * hsh(x, y, seed))

# ---------------------------------------------------------------- CUADRUPEDOS (UV del cerdo, 64x32)
# patron(lx, ly, seed) -> color o None, se aplica al lomo, costados y parte alta de la cabeza
def quadruped(name, pal, pattern=None, head_extra=None, leg_split=2, seed=1):
    t = Tex(64, 32)
    base, dark, belly = pal['base'], pal['dark'], pal['belly']

    def body_color(face, lx, ly, fw, fh, x0, y0):
        gx, gy = lx + x0, ly + y0
        c = fur(gx, gy, base, seed)
        if pattern:
            p = pattern(face, lx, ly, fw, fh, seed)
            if p is not None: c = p
        return c

    # cabeza 8x8x8 en (0,0)
    def head(face, lx, ly, fw, fh):
        c = body_color(face, lx, ly, fw, fh, 0, 0)
        if face == 'front':
            if ly == 3 and lx in (1, 2, 5, 6):
                c = pal['eye_white'] if lx in (1, 6) else pal['eye']
            if ly == 2 and lx in (1, 2, 5, 6): c = sh(dark, 1.0)
            if ly >= 5: c = mix(c, pal['muzzle'], 0.55)
        if face in ('left', 'right') and ly >= 5: c = mix(c, pal['muzzle'], 0.4)
        if face == 'top' and head_extra: c = head_extra(face, lx, ly, c) or c
        if face in ('left', 'right', 'top') and head_extra:
            c = head_extra(face, lx, ly, c) or c
        return c
    box(t, 0, 0, 8, 8, 8, head)

    # hocico 4x3x1 en (16,16)
    def snout(face, lx, ly, fw, fh):
        c = fur(lx, ly, pal['nose'], seed + 3, 0.08)
        if face == 'front' and ly == 1 and lx in (1, 2): c = sh(pal['nose'], 0.35)
        if pal.get('tusk') and face == 'front' and ly == 2 and lx in (0, 3): c = pal['tusk']
        return c
    box(t, 16, 16, 4, 3, 1, snout)

    # cuerpo 10x16x8 en (28,8): 'back'(54,16) = lomo, 'front'(36,16) = vientre
    def body(face, lx, ly, fw, fh):
        if face == 'front':
            return mix(fur(lx, ly, belly, seed + 5, 0.07), belly, 0.4)
        if face == 'bottom':
            return fur(lx, ly, belly, seed + 6, 0.07)
        c = body_color(face, lx, ly, fw, fh, 28, 8)
        if face in ('left', 'right') and lx >= fw - 3:      # el borde bajo del costado se aclara hacia el vientre
            c = mix(c, belly, 0.25 * (lx - (fw - 4)))
        return c
    box(t, 28, 8, 10, 16, 8, body)

    # patas 4x6x4 en (0,16), 2 filas finales con otro color (pezunas / calcetines)
    def leg(face, lx, ly, fw, fh):
        if face in ('top', 'bottom'): return sh(pal['hoof'], 0.9)
        if ly >= fh - leg_split: return fur(lx, ly, pal['hoof'], seed + 8, 0.08)
        return mix(fur(lx, ly, base, seed + 7), dark, 0.25 + 0.2 * (ly / fh))
    box(t, 0, 16, 4, 6, 4, leg)

    t.save(os.path.join(ROOT, 'entity', name + '.png'))

def blobs(face, lx, ly, fw, fh, seed, sc=3.0, thr=0.56, color=None):
    return color if vnoise(lx + (7 if face == 'back' else 0), ly + (face == 'right') * 11, sc, seed) > thr else None

# --- temas de color por bioma (cada forma de mob se pinta con el tema de su bioma)
def _t(**k): return {n: rgb(v) for n, v in k.items()}
THEMES = {
    'violet':  _t(fur=0x9a6bd0, fur2=0x4a2a78, light=0xd9c0f2, spot=0xff9bf5, glow=0xff4cff, dark=0x1c0a30, hoof=0x2a1444,
                  skin=0x4a2470, skin_dark=0x1c0a30, cloth=0x24103c, claw=0xc8a0f0, alga=0x7a3aa8),
    'ember':   _t(fur=0x7a3416, fur2=0x2a0e06, light=0xd08a48, spot=0xffa030, glow=0xff7020, dark=0x120604, hoof=0x1e0a04,
                  skin=0x4a2018, skin_dark=0x1a0a06, cloth=0x2a1410, claw=0xffb040, alga=0x8a3010),
    'azure':   _t(fur=0x2f86a8, fur2=0x0e3550, light=0xbfeaf0, spot=0x9ae8ee, glow=0x50fff0, dark=0x0a2a3a, hoof=0x1a4a64,
                  skin=0x2a6d78, skin_dark=0x103840, cloth=0x1e4f4a, claw=0x9ae8e0, alga=0x2f8a4a),
    'pale':    _t(fur=0xc9a874, fur2=0x6a5030, light=0xf4ecd8, spot=0xfff8e8, glow=0xf6f6a0, dark=0x3a3830, hoof=0x3a2c1c,
                  skin=0xd4ccb4, skin_dark=0x6a6656, cloth=0x4a463c, claw=0xf8f4e4, alga=0x9aa070),
    'crystal': _t(fur=0x5aa0bc, fur2=0x2c4a60, light=0xd8f6ff, spot=0xff9bf5, glow=0xff6ee6, dark=0x13303f, hoof=0x24394c,
                  skin=0x3a7a96, skin_dark=0x13303f, cloth=0x24506a, claw=0xd8f6ff, alga=0xff9bf5),
}

# --- pacificos
def grazer(name, th):   # rumiante: manchas oscuras tipo vaca + destellos del End
    pal = dict(base=th['fur'], dark=sh(th['fur2'], 0.7), belly=th['light'], muzzle=mix(th['light'], (255, 255, 255), 0.3),
               nose=th['fur2'], eye=th['dark'], eye_white=th['light'], hoof=th['hoof'])
    def pat(face, lx, ly, fw, fh, seed):
        if face == 'top' and fw == 8: return None
        v = vnoise(lx + (9 if face == 'back' else 0), ly + (face == 'right') * 13, 3.2, seed)
        if v > 0.57: return fur(lx, ly, th['fur2'], seed, 0.1)
        if hsh(lx, ly, seed + 9) > 0.965: return th['spot']
        return None
    quadruped(name, pal, pat, seed=11)

def hog(name, th):      # jabali: cerdas, crin oscura en el lomo y colmillos
    pal = dict(base=mix(th['fur'], th['fur2'], 0.4), dark=th['fur2'], belly=th['light'], muzzle=mix(th['fur'], th['light'], 0.4), nose=sh(th['fur2'], 1.1),
               eye=th['dark'], eye_white=th['glow'], hoof=th['dark'], tusk=rgb(0xf4ecd0))
    def pat(face, lx, ly, fw, fh, seed):
        if face in ('back', 'top') and fw >= 8:
            if abs(lx - (fw - 1) / 2) < 1.6: return fur(lx, ly, th['fur2'], seed, 0.15)
        if hsh(lx // 1, ly // 2, seed + 4) > 0.55 and (lx + ly) % 3 == 0: return mix(th['fur'], th['fur2'], 0.5)
        if hsh(lx, ly, seed + 2) > 0.975: return th['spot']
        return None
    quadruped(name, pal, pat, seed=21)

def wader(name, th):    # vadeador: anfibio de lomo oscuro con motas claras y vientre palido
    pal = dict(base=th['fur'], dark=th['fur2'], belly=th['light'], muzzle=mix(th['light'], th['fur'], 0.35), nose=mix(th['fur'], th['fur2'], 0.5),
               eye=rgb(0x101010), eye_white=rgb(0xffe860), hoof=mix(th['fur2'], th['fur'], 0.4))
    def pat(face, lx, ly, fw, fh, seed):
        if face in ('back', 'top'):
            c = mix(th['fur'], th['fur2'], min(1, ly / max(1, fh)) * 0.6)
            if hsh(lx, ly, seed + 1) > 0.88: return th['spot']
            return fur(lx, ly, c, seed, 0.08)
        return None
    quadruped(name, pal, pat, leg_split=3, seed=31)

def deer(name, th):     # ciervo: vientre claro, manchas claras en el lomo, patas oscuras y base de astas
    pal = dict(base=th['fur'], dark=th['fur2'], belly=th['light'], muzzle=mix(th['light'], th['fur'], 0.4), nose=th['dark'],
               eye=th['dark'], eye_white=th['light'], hoof=sh(th['fur2'], 0.6))
    def pat(face, lx, ly, fw, fh, seed):
        if face in ('back', 'left', 'right') and fw >= 8:
            if hsh(lx, ly, seed + 5) > 0.9 and ly % 2 == 0: return th['spot']
        return None
    def extra(face, lx, ly, c):
        if face == 'top' and (lx in (0, 1, 6, 7)) and ly in (5, 6, 7): return sh(th['fur2'], 1.2)
        if face in ('left', 'right') and ly == 0 and lx in (3, 4): return sh(th['fur2'], 1.2)
        return None
    quadruped(name, pal, pat, extra, leg_split=3, seed=41)

def sheep(name, th):    # oveja: lana facetada con cristales de color, cara y patas oscuras
    t = Tex(64, 32)
    wool = mix(th['light'], th['fur'], 0.3)
    face_c, leg_c = sh(th['fur2'], 0.9), sh(th['fur2'], 0.75)
    deep = mix(th['fur'], wool, 0.35)
    def wool_px(x, y, seed):
        v = hsh(x // 2, y // 2, seed)
        c = sh(wool, 0.8 + 0.3 * v)
        if v > 0.9: c = th['spot']
        elif v < 0.1: c = deep
        if (x + y) % 2 == 0 and hsh(x, y, seed + 2) > 0.7: c = sh(c, 1.08)
        return c
    def head(face, lx, ly, fw, fh):
        c = fur(lx, ly, face_c, 51, 0.1)
        if face == 'top' and ly < 3: return wool_px(lx, ly, 52)
        if face == 'front':
            if ly == 3 and lx in (1, 2, 5, 6): c = rgb(0xf8f8f8) if lx in (1, 6) else rgb(0x080808)
            if ly < 2: return wool_px(lx, ly, 53)
        return c
    box(t, 0, 0, 8, 8, 8, head)
    box(t, 16, 16, 4, 3, 1, lambda f, lx, ly, fw, fh: sh(face_c, 0.8) if (f == 'front' and ly == 1 and lx in (1, 2)) else sh(face_c, 1.1))
    box(t, 28, 8, 10, 16, 8, lambda f, lx, ly, fw, fh: wool_px(lx + (f == 'back') * 20, ly + {'left': 33, 'right': 66}.get(f, 0), 55))
    box(t, 0, 16, 4, 6, 4, lambda f, lx, ly, fw, fh: wool_px(lx, ly, 56) if ly < 2 and f not in ('top', 'bottom') else fur(lx, ly, leg_c, 57, 0.1))
    t.save(os.path.join(ROOT, 'entity', name + '.png'))

def howler(name, th):   # aullador: lobo con silla oscura, vientre claro y ojos brillantes
    grey = rgb(0x8f8c80)
    base = mix(th['fur'], grey, 0.5)
    pal = dict(base=base, dark=mix(th['fur2'], grey, 0.3), belly=mix(th['light'], (240, 240, 230), 0.4), muzzle=mix(base, th['light'], 0.5),
               nose=th['dark'], eye=th['glow'], eye_white=mix(th['glow'], (255, 255, 255), 0.5), hoof=mix(th['fur2'], grey, 0.4))
    def pat(face, lx, ly, fw, fh, seed):
        if face == 'back' and 3 <= ly <= 12 and 2 <= lx <= fw - 3: return fur(lx, ly, mix(th['fur2'], grey, 0.35), seed, 0.18)
        if face == 'top' and fw == 8 and 2 <= lx <= 5: return fur(lx, ly, mix(th['fur2'], grey, 0.5), seed, 0.12)
        return None
    def extra(face, lx, ly, c):
        if face == 'top' and lx in (0, 1, 6, 7) and ly >= 5: return th['dark']
        return None
    quadruped(name, pal, pat, extra, leg_split=2, seed=61)

# ---------------------------------------------------------------- ARANAS (UV de la arana, 64x32)
def spider(name, pal, seed, abdomen_pat, head_pat=None, queen=False):
    t = Tex(64, 32)
    base, dark, glow, joint = pal['base'], pal['dark'], pal['glow'], pal['joint']
    box(t, 0, 0, 6, 6, 6, lambda f, lx, ly, fw, fh: fur(lx, ly, mix(base, dark, 0.35), seed + 1, 0.12))
    def head(f, lx, ly, fw, fh):
        c = fur(lx, ly, base, seed + 2, 0.12)
        if f == 'front':
            if ly == 3 and lx in (1, 2, 5, 6): c = glow
            if ly == 4 and lx in (2, 5): c = sh(glow, 0.8)
            if ly == 2 and lx in (3, 4): c = sh(glow, 0.7)
            if ly >= 6 and lx in (2, 3, 4, 5): c = sh(dark, 0.6)
            if ly == 7 and lx in (2, 5): c = pal.get('fang', rgb(0xf0f0e0))
        if head_pat: c = head_pat(f, lx, ly, c) or c
        return c
    box(t, 32, 4, 8, 8, 8, head)
    def abd(f, lx, ly, fw, fh):
        c = fur(lx, ly, base, seed + 3, 0.1)
        p = abdomen_pat(f, lx, ly, fw, fh, c, seed)
        return p if p is not None else c
    box(t, 0, 12, 10, 8, 12, abd)
    def leg(f, lx, ly, fw, fh):
        if f in ('front', 'back', 'top', 'bottom') and fw == 16:
            c = fur(lx, ly, dark if lx < 6 else mix(base, dark, 0.3), seed + 4, 0.1)
            if lx in (5, 6, 11, 12): c = joint
            if lx >= 14: c = sh(joint, 0.75)
            return c
        return sh(dark, 0.9)
    box(t, 18, 0, 16, 2, 2, leg)
    t.save(os.path.join(ROOT, 'entity', name + '.png'))

def crawler(name, th):  # reptante: caparazon oscuro con grietas luminosas
    pal = dict(base=mix(th['dark'], th['fur2'], 0.5), dark=sh(th['dark'], 0.8), glow=th['spot'], joint=th['glow'])
    def pat(f, lx, ly, fw, fh, c, seed):
        v = vnoise(lx + (f == 'top') * 5, ly + {'left': 20, 'right': 40}.get(f, 0), 2.6, seed)
        if abs(v - 0.5) < 0.045: return th['glow'] if hsh(lx, ly, seed) > 0.3 else th['spot']
        if v > 0.72: return sh(c, 0.6)
        return None
    spider(name, pal, 71, pat)

def biter(name, th):    # mordedor: caparazon con cristales facetados
    pal = dict(base=mix(th['fur'], th['fur2'], 0.45), dark=sh(th['fur2'], 0.6), glow=th['glow'], joint=th['light'], fang=mix(th['light'], (255, 255, 255), 0.5))
    pink, cyan = th['spot'], th['light']
    def pat(f, lx, ly, fw, fh, c, seed):
        v = hsh(lx // 2, ly // 2, seed + 9)
        if f == 'top':
            if v > 0.78: return pink if (lx + ly) % 2 == 0 else sh(pink, 0.8)
            if v < 0.18: return cyan if (lx + ly) % 2 == 0 else sh(cyan, 0.7)
        if (lx + ly) % 4 == 0 and v > 0.5: return sh(c, 1.25)
        return None
    spider(name, pal, 81, pat)

def queen():    # Reina de cristal: mas oscura y regia, con diamante rosa en el abdomen y corona de cristales
    pal = dict(base=rgb(0x1c4a66), dark=rgb(0x0a1c2a), glow=rgb(0xff5af0), joint=rgb(0xb8f6ff), fang=rgb(0xffe8fc))
    def pat(f, lx, ly, fw, fh, c, seed):
        if f == 'top':
            dx, dy = abs(lx - 4.5), abs(ly - 5.5)
            d = dx / 4.5 + dy / 5.5
            if d < 0.45: return rgb(0xffa8f8)
            if d < 0.75: return rgb(0xe050d6)
            if d < 0.95: return rgb(0x7a2a88)
        if (lx * 3 + ly * 5) % 7 == 0: return rgb(0x6fe0ff)
        return None
    def hp(f, lx, ly, c):
        if f == 'top' and ly < 3 and lx % 2 == 0: return rgb(0xb8f6ff)
        if f == 'front' and ly == 0 and lx % 2 == 1: return rgb(0xffa8f8)
        return None
    spider('crystal_queen', pal, 91, pat, hp, queen=True)

# ---------------------------------------------------------------- HUMANOIDES (UV del zombi, 64x64)
def humanoid(name, pal, seed, body_pat, face_fn, limb_pat=None):
    t = Tex(64, 64)
    skin, dark, cloth = pal['skin'], pal['dark'], pal['cloth']
    def head(f, lx, ly, fw, fh):
        c = fur(lx, ly, skin, seed, 0.1)
        if f == 'top': c = fur(lx, ly, dark, seed + 1, 0.15)
        if f == 'front': c = face_fn(lx, ly, c) or c
        if f in ('left', 'right', 'back') and ly < 2: c = fur(lx, ly, dark, seed + 2, 0.12)
        return c
    box(t, 0, 0, 8, 8, 8, head)
    def body(f, lx, ly, fw, fh):
        c = fur(lx, ly, cloth, seed + 3, 0.1)
        p = body_pat(f, lx, ly, fw, fh, c, seed)
        if f in ('front', 'back', 'left', 'right') and ly >= fh - 2 and hsh(lx, ly, seed + 8) > 0.45:
            return None if ly == fh - 1 and hsh(lx, ly, seed + 9) > 0.5 else (p or sh(c, 0.7))
        return p if p is not None else c
    box(t, 16, 16, 8, 12, 4, body)
    def limb(f, lx, ly, fw, fh):
        c = fur(lx, ly, skin if ly > 3 else cloth, seed + 4, 0.1)
        if limb_pat:
            p = limb_pat(f, lx, ly, fw, fh, c, seed)
            if p is not None: return p
        if ly >= fh - 2 and f not in ('top', 'bottom'): c = sh(pal.get('claw', skin), 1.1 if ly == fh - 1 else 0.95)
        return c
    box(t, 40, 16, 4, 12, 4, limb)
    box(t, 32, 48, 4, 12, 4, limb)
    def leg(f, lx, ly, fw, fh):
        c = fur(lx, ly, mix(cloth, dark, 0.35), seed + 5, 0.12)
        if limb_pat:
            p = limb_pat(f, lx, ly, fw, fh, c, seed + 1)
            if p is not None and ly > 6: return p
        if ly >= fh - 2: c = sh(c, 0.65)
        return c
    box(t, 0, 16, 4, 12, 4, leg)
    box(t, 16, 48, 4, 12, 4, leg)
    t.save(os.path.join(ROOT, 'entity', name + '.png'))

def stalker(name, th):  # acechador: piel apagada, ojos brillantes, sonrisa rasgada y harapos con grieta luminosa
    pal = dict(skin=th['skin'], dark=th['skin_dark'], cloth=th['cloth'], claw=th['claw'])
    def face(lx, ly, c):
        if ly == 3 and lx in (1, 2, 5, 6): return th['glow']
        if ly == 2 and lx in (1, 6): return sh(c, 0.5)
        if ly == 6 and 1 <= lx <= 6: return sh(th['skin_dark'], 0.5) if lx % 2 == 0 else mix(th['light'], (255, 255, 255), 0.6)
        if ly == 5 and lx in (0, 7): return sh(th['skin_dark'], 0.5)
        return None
    def body(f, lx, ly, fw, fh, c, seed):
        if f == 'front' and lx in (3, 4) and 1 <= ly <= 8 and ly % 3 != 0: return mix(th['glow'], th['fur'], 0.4)
        if (lx + ly) % 5 == 0 and hsh(lx, ly, seed) > 0.4: return sh(c, 0.7)
        return None
    humanoid(name, pal, 101, body, face)

def lurker(name, th):   # merodeador: piel de pez con escamas, algas/cristales y ojos brillantes
    pal = dict(skin=th['skin'], dark=th['skin_dark'], cloth=th['cloth'], claw=th['claw'])
    def face(lx, ly, c):
        if ly == 3 and lx in (1, 2, 5, 6): return th['glow'] if lx in (2, 5) else sh(th['skin_dark'], 0.5)
        if ly == 6 and 2 <= lx <= 5: return sh(th['skin_dark'], 0.5)
        return None
    def scales(f, lx, ly, fw, fh, c, seed):
        if (lx + (ly % 2) * 2) % 4 == 0: return sh(c, 1.28)
        if hsh(lx, ly, seed + 6) > 0.93: return th['alga']
        if f == 'front' and lx in (2, 5) and ly < 5: return sh(th['alga'], 0.75)
        return None
    humanoid(name, pal, 111, scales, face, limb_pat=scales)

def warden():   # Guardian violeta: armadura de piedra purpura con runas brillantes
    t = Tex(64, 64)
    stone, dark, rune = rgb(0x4a2a6a), rgb(0x1c0e2c), rgb(0xc464ff)
    def stone_px(x, y, seed, base=stone):
        c = sh(base, 0.82 + 0.3 * vnoise(x, y, 3.0, seed))
        if (x % 4 == 0 or y % 5 == 0) and hsh(x, y, seed) > 0.4: c = sh(c, 0.78)    # juntas de los bloques
        return c
    def head(f, lx, ly, fw, fh):
        c = stone_px(lx, ly, 121)
        if f == 'front':
            if ly in (3, 4) and 1 <= lx <= 6: return dark                    # visor
            if ly == 3 and lx in (2, 5): return rune
            if ly == 4 and lx in (2, 5): return sh(rune, 0.7)
            if ly >= 6 and lx in (3, 4): return sh(c, 0.6)
        if f == 'top' and lx in (3, 4): return rune
        return c
    box(t, 0, 0, 8, 8, 8, head)
    def body(f, lx, ly, fw, fh):
        c = stone_px(lx + (f == 'back') * 9, ly + {'left': 20, 'right': 30}.get(f, 0), 122)
        if f in ('front', 'back'):
            cx = abs(lx - (fw - 1) / 2)
            if cx < 0.6 and 1 <= ly <= 9: return rune if ly % 2 == 1 else sh(rune, 0.65)
            if 1.4 < cx < 2.6 and ly in (2, 6): return sh(rune, 0.8)
        if ly <= 1: return sh(c, 1.15)
        return c
    box(t, 16, 16, 8, 12, 4, body)
    def arm(f, lx, ly, fw, fh):
        c = stone_px(lx + 3, ly, 123 + (f == 'left'))
        if ly <= 2: return stone_px(lx, ly, 126, rgb(0x6a3a96))             # hombrera
        if f == 'front' and lx in (1, 2) and ly in (5, 8): return rune
        if ly >= fh - 2: return sh(c, 0.7)
        return c
    box(t, 40, 16, 4, 12, 4, arm)
    box(t, 32, 48, 4, 12, 4, arm)
    def leg(f, lx, ly, fw, fh):
        c = stone_px(lx, ly + 5, 127)
        if ly >= fh - 3: return stone_px(lx, ly, 128, dark)
        if f == 'front' and lx in (1, 2) and ly == 3: return sh(rune, 0.75)
        return c
    box(t, 0, 16, 4, 12, 4, leg)
    box(t, 16, 48, 4, 12, 4, leg)
    t.save(os.path.join(ROOT, 'entity', 'violet_warden.png'))

# ---------------------------------------------------------------- TRONCOS (16x16)
# estilo por madera: corteza, madera interior, rasgo especial
LOGS = {
    'violet':  dict(bark=0x4a2a6a, wood=0x8a58b8, hi=0x6a3f92, lo=0x2a1440, special='knots'),
    'ember':   dict(bark=0x2a1610, wood=0xc0572b, hi=0x4a2a1c, lo=0x140804, special='cracks'),
    'azure':   dict(bark=0x2a4a64, wood=0x4a8cbc, hi=0x3c6a88, lo=0x16283a, special='moss'),
    'pale':    dict(bark=0xe6e2d2, wood=0xdcd2b2, hi=0xf6f4ea, lo=0x6a6656, special='birch'),
    'crystal': dict(bark=0x4a88a4, wood=0xa6dcec, hi=0x7cc4de, lo=0x2a5670, special='facets'),
}

def log_side(wn, st, stripped=False):
    t = Tex(16, 16)
    b, w, hi, lo = rgb(st['bark']), rgb(st['wood']), rgb(st['hi']), rgb(st['lo'])
    s = sum(map(ord, wn))
    for y in range(16):
        for x in range(16):
            if stripped:
                grain = vnoise(x * 3, y, 5.0, s + 40)
                c = sh(w, 0.94 + 0.14 * grain)
                if x % 4 == 1 and hsh(x, y // 3, s) > 0.45: c = sh(c, 0.88)          # vetas verticales
                if hsh(x, y, s + 3) > 0.94: c = sh(c, 0.82)
            else:
                # surcos verticales de ancho irregular
                col = x + int(2.2 * vnoise(x * 0.5, y, 4.0, s))
                ridge = (col % 4)
                n = vnoise(x * 2, y, 3.0, s + 7)
                c = sh(b, 0.8 + 0.4 * n)
                if ridge == 0: c = mix(c, lo, 0.65)                                  # grieta
                elif ridge == 2: c = mix(c, hi, 0.35)                                # lomo claro
                if hsh(x, y, s + 5) > 0.93: c = sh(c, 1.18)
                sp = st['special']
                if sp == 'knots':
                    for kx, ky in ((4, 5), (11, 11)):
                        d = math.hypot(x - kx, (y - ky) * 0.8)
                        if d < 1.2: c = sh(lo, 0.7)
                        elif d < 2.3: c = mix(c, hi, 0.5)
                elif sp == 'cracks':
                    v = vnoise(x + 3, y * 0.6, 3.5, s + 11)
                    if abs(v - 0.5) < 0.05: c = rgb(0xff7a20) if hsh(x, y, s) > 0.4 else rgb(0xffb43a)
                elif sp == 'moss':
                    if y < 4 + 3 * vnoise(x, 0, 3.0, s + 2) and hsh(x, y, s + 1) > 0.25: c = fur(x, y, rgb(0x3f8a58), s, 0.18)
                    elif y > 12 and hsh(x, y, s + 2) > 0.7: c = fur(x, y, rgb(0x3f8a58), s, 0.18)
                elif sp == 'birch':
                    c = fur(x, y, b, s, 0.05)
                    if y in (3, 4, 8, 12) and 0 < x < 15 and hsh(x // 3, y, s) > 0.35: c = rgb(0x2a2824) if hsh(x, y, s) > 0.3 else rgb(0x4a4840)
                    if y in (4, 9, 13) and hsh(x // 2, y, s + 1) > 0.7: c = sh(c, 0.82)
                elif sp == 'facets':
                    cell = hsh(x // 3, y // 4, s)
                    c = sh(c, 0.85 + 0.35 * cell)
                    if (x % 3 == 0) and cell > 0.6: c = mix(c, rgb(0xd8f6ff), 0.55)
                    if hsh(x, y, s + 8) > 0.97: c = rgb(0xff9bf5)
            t.put(x, y, c)
    return t

def log_top(wn, st, stripped=False):
    t = Tex(16, 16)
    b, w, lo = rgb(st['bark']), rgb(st['wood']), rgb(st['lo'])
    s = sum(map(ord, wn))
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5)
            edge = max(abs(x - 7.5), abs(y - 7.5))
            n = vnoise(x, y, 2.5, s + 21)
            if edge > 6.6 and not stripped:
                c = fur(x, y, b, s, 0.12)                                           # aro de corteza
            else:
                ring = (d + 1.2 * (n - 0.5)) % 3.0
                c = sh(w, 0.92 + 0.16 * n)
                if ring < 0.8: c = mix(c, lo, 0.28)                                 # anillos de crecimiento
                if d < 1.4: c = mix(c, lo, 0.4)                                     # medula
                if edge > 6.6 and stripped: c = sh(c, 0.85)
            t.put(x, y, c)
    return t

def logs():
    T = os.path.join(ROOT, 'block')
    for wn, st in LOGS.items():
        log_side(wn, st).save(os.path.join(T, f'{wn}_log.png'))
        log_top(wn, st).save(os.path.join(T, f'{wn}_log_top.png'))
        log_side(wn, st, True).save(os.path.join(T, f'stripped_{wn}_log.png'))
        log_top(wn, st, True).save(os.path.join(T, f'stripped_{wn}_log_top.png'))

# nombre del mob -> (forma, tema de color del bioma)
MOBS = {
    'violet_grazer': (grazer, 'violet'), 'violet_deer': (deer, 'violet'),
    'ember_hog': (hog, 'ember'), 'ember_sheep': (sheep, 'ember'),
    'azure_wader': (wader, 'azure'), 'azure_grazer': (grazer, 'azure'),
    'pale_deer': (deer, 'pale'), 'pale_hog': (hog, 'pale'),
    'crystal_sheep': (sheep, 'crystal'), 'crystal_wader': (wader, 'crystal'),
    'violet_stalker': (stalker, 'violet'), 'pale_stalker': (stalker, 'pale'),
    'ember_crawler': (crawler, 'ember'), 'violet_crawler': (crawler, 'violet'),
    'azure_lurker': (lurker, 'azure'), 'crystal_lurker': (lurker, 'crystal'),
    'pale_howler': (howler, 'pale'), 'ember_howler': (howler, 'ember'),
    'crystal_biter': (biter, 'crystal'), 'azure_biter': (biter, 'azure'),
}

def main():
    for name, (shape, theme) in MOBS.items():
        shape(name, THEMES[theme])
    queen()
    warden()
    logs()
    print('texturas generadas')

if __name__ == '__main__':
    main()
