package com.endrealms;

import net.fabricmc.fabric.api.biome.v1.TheEndBiomes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

public final class ModBiomes {
    private static ResourceKey<Biome> key(String id) {
        return ResourceKey.create(Registries.BIOME, EndRealms.id(id));
    }

    public static void init() {
        // Zonas "altas" del End exterior
        TheEndBiomes.addHighlandsBiome(key("violet_forest"), 1.0);
        TheEndBiomes.addHighlandsBiome(key("pale_grove"), 1.0);
        // Zonas medias y bajas se asocian a un bioma "highlands" padre (el vanilla)
        TheEndBiomes.addMidlandsBiome(Biomes.END_HIGHLANDS, key("ember_thicket"), 1.0);
        TheEndBiomes.addMidlandsBiome(Biomes.END_HIGHLANDS, key("azure_marsh"), 1.0);
        TheEndBiomes.addBarrensBiome(Biomes.END_HIGHLANDS, key("crystal_gardens"), 1.0);
    }
}
