package com.endrealms.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import java.util.function.Supplier;

/** Altar en el centro de cada estructura: clic derecho para invocar al miniboss (una sola vez). */
public class BossAltarBlock extends Block {
    private final Supplier<? extends EntityType<? extends Mob>> boss;

    public BossAltarBlock(Supplier<? extends EntityType<? extends Mob>> boss, Properties props) {
        super(props);
        this.boss = boss;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level instanceof ServerLevel server) {
            server.removeBlock(pos, false);
            boss.get().spawn(server, pos, EntitySpawnReason.TRIGGERED);
        }
        return InteractionResult.SUCCESS;
    }
}
