"""Texturas pulidas de los bloques e items de madera (tablones, hojas, trampillas, puertas, brotes, flores) y de los altares."""
import os, math
from PIL import Image
from gen_textures import rgb, sh, mix, hsh, vnoise, Tex, ROOT
from gen_art import blob, band, ramp_from, paint_blob

PAL = {  # tablon, corteza, hojas, flor, destello
    'violet':  dict(plank=0x7a4aa8, bark=0x4a2a6a, leaf=0x9a5ad8, flower=0xff7bf0, spark=0xff9bf5),
    'ember':   dict(plank=0xc0572b, bark=0x3a1c10, leaf=0xe0782a, flower=0xffd23a, spark=0xffe070),
    'azure':   dict(plank=0x3f7fb0, bark=0x1e3b5a, leaf=0x34b8c8, flower=0x6ab8ff, spark=0xc8ffff),
    'pale':    dict(plank=0xd2c8a8, bark=0x8a8470, leaf=0xe4e0c8, flower=0xffffff, spark=0xffffff),
    'crystal': dict(plank=0x86c6dc, bark=0x4f8aa6, leaf=0xc860cc, flower=0xff9bf5, spark=0xffffff),
}
T = os.path.join(ROOT, 'block')
TI = os.path.join(ROOT, 'item')

def planks_px(t, x0, y0, w, h, pc, s, joint_seed=0):
    """tablones horizontales de 4 px dentro del rectangulo"""
    for board in range((h + 3) // 4):
        by = y0 + board * 4
        bc = sh(pc, 0.94 + 0.12 * hsh(board, joint_seed, s))
        joint = x0 + 2 + int(hsh(board, joint_seed + 1, s) * (w - 5))
        for dy in range(4):
            y = by + dy
            if y >= y0 + h: break
            for x in range(x0, x0 + w):
                g = vnoise(x * 0.45 + board * 7, y * 2.8, 2.0, s)
                c = sh(bc, 0.88 + 0.22 * g)
                if dy == 0: c = sh(c, 1.13)
                if dy == 3: c = sh(c, 0.7)
                if x == joint and dy < 3: c = sh(c, 0.78)
                if dy == 1 and x in (joint - 2, joint + 2) and hsh(x, board, s + 3) > 0.45: c = sh(c, 0.62)   # clavos
                t.put(x, y, c)

def planks(wn, p):
    t = Tex(16, 16); planks_px(t, 0, 0, 16, 16, rgb(p['plank']), sum(map(ord, wn)))
    t.save(os.path.join(T, f'{wn}_planks.png'))

def leaves(wn, p):
    t = Tex(16, 16); s = sum(map(ord, wn)) + 5
    base = rgb(p['leaf']); spark = rgb(p['spark'])
    ramp = [sh(base, 0.5), sh(base, 0.75), sh(base, 1.0), sh(base, 1.22)]
    for y in range(16):
        for x in range(16):
            n = vnoise(x, y, 2.7, s) * 0.65 + vnoise(x * 2, y * 2, 1.4, s + 1) * 0.35
            c = ramp[0] if n < 0.3 else ramp[1] if n < 0.47 else ramp[2] if n < 0.68 else ramp[3]
            if (x * 2 + y) % 7 == 0 and hsh(x, y, s + 2) > 0.45: c = sh(c, 0.8)           # nervios
            if hsh(x, y, s + 3) > 0.94: c = sh(ramp[0], 0.7)                               # huecos oscuros
            if hsh(x, y, s + 4) > 0.965: c = spark                                         # destellos
            t.put(x, y, c)
    t.save(os.path.join(T, f'{wn}_leaves.png'))

def trapdoor(wn, p):
    t = Tex(16, 16); pc = rgb(p['plank']); s = sum(map(ord, wn)) + 9
    planks_px(t, 0, 0, 16, 16, pc, s, 3)
    dark = sh(pc, 0.6)
    for y in range(16):
        for x in range(16):
            frame = x < 2 or x > 13 or y < 2 or y > 13 or 7 <= x <= 8 or 7 <= y <= 8
            if frame:
                c = sh(pc, 0.95 + 0.12 * vnoise(x, y, 2, s))
                if x in (0, 15) or y in (0, 15): c = sh(c, 0.62)
                elif x in (1,) or y in (1,): c = sh(c, 1.15)
                elif x in (7, ) and y > 1 and y < 14: c = sh(c, 1.12)
                elif y in (7,) and x > 1 and x < 14: c = sh(c, 1.12)
                t.put(x, y, c)
            else:
                c = sh(pc, 0.62 + 0.08 * vnoise(x, y, 2, s + 1))
                if x in (2, 9) or y in (2, 9): c = sh(c, 0.82)                             # sombra interior
                t.put(x, y, c)
    for (x, y) in ((1, 1), (14, 1), (1, 14), (14, 14)):
        t.put(x, y, rgb(0x3a3a40))                                                          # clavos
    t.save(os.path.join(T, f'{wn}_trapdoor.png'))

def door_halves(wn, p):
    pc = rgb(p['plank']); s = sum(map(ord, wn)) + 13
    out = {}
    for top in (True, False):
        t = Tex(16, 16); planks_px(t, 0, 0, 16, 16, pc, s + int(top), 5)
        for y in range(16):
            for x in range(16):
                if x < 2 or x > 13 or y == 0 or y == 15:
                    c = sh(pc, 0.92 + 0.1 * vnoise(x, y, 2, s))
                    if x in (0, 15) or (y == 15 and not top) or (y == 0 and top): c = sh(c, 0.6)
                    elif x == 1 or (y == 1 and top): c = sh(c, 1.15)
                    t.put(x, y, c)
        if top:
            for y in range(3, 11):
                for x in range(3, 13):
                    edge = x in (3, 12) or y in (3, 10)
                    c = rgb(0xcfeaff) if not edge else sh(pc, 0.55)
                    if not edge:
                        c = mix(rgb(0xa8d4f4), rgb(0xe6f6ff), 0.5 + 0.5 * math.sin((x + y) * 0.9))
                        if (x + y) in (9, 10): c = rgb(0xffffff)
                        if x == 7 or x == 8 or y == 6 or y == 7: c = sh(pc, 0.7)           # cruces
                    t.put(x, y, c)
            for x in range(3, 13): t.put(x, 12, sh(pc, 0.6)); t.put(x, 13, sh(pc, 1.1))
        else:
            for (y0, y1) in ((2, 6), (9, 13)):
                for y in range(y0, y1 + 1):
                    for x in range(3, 13):
                        c = sh(pc, 0.66 + 0.08 * vnoise(x, y, 2, s))
                        if y == y0 or x == 3: c = sh(c, 0.82)
                        if y == y1 or x == 12: c = sh(c, 1.25)
                        t.put(x, y, c)
            for (x, y) in ((12, 7), (13, 7), (12, 8), (13, 8)): t.put(x, y, rgb(0xe8c040) if (x + y) % 2 else rgb(0xffe070))
            t.put(13, 9, rgb(0x6a5410))
        out[top] = t
        t.save(os.path.join(T, f'{wn}_door_{"top" if top else "bottom"}.png'))
    # icono de la puerta: las dos mitades apiladas y reducidas, con contorno
    top_i = out[True].im.resize((8, 7), Image.NEAREST); bot_i = out[False].im.resize((8, 7), Image.NEAREST)
    icon = Tex(16, 16)
    icon.im.paste(top_i, (4, 1)); icon.im.paste(bot_i, (4, 8))
    px = icon.im.load()
    solid = {(x, y) for y in range(16) for x in range(16) if px[x, y][3] > 0}
    for (x, y) in solid:
        if any((x + dx, y + dy) not in solid for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
            icon.put(x, y, sh(pc, 0.4))
    icon.save(os.path.join(TI, f'{wn}_door.png'))

def sapling(wn, p):
    t = Tex(16, 16); s = sum(map(ord, wn)) + 17
    bark = rgb(p['bark']); leaf = rgb(p['leaf']); spark = rgb(p['spark'])
    for y in range(9, 16):                                       # tronco fino y ligeramente torcido
        x = 7 if y > 11 else 8
        t.put(x, y, sh(mix(bark, rgb(0x5a3a22), 0.35), 1.05)); t.put(x + 1, y, sh(mix(bark, rgb(0x5a3a22), 0.35), 0.7))
    t.put(6, 15, sh(bark, 0.8)); t.put(10, 15, sh(bark, 0.8))
    ramp = ramp_from(leaf, 0.3)
    pix = blob([(8.0, 3.8, 2.7, 2.6, 0.0), (8.0, 6.6, 2.6, 2.4, 0.0), (4.6, 6.4, 2.6, 2.2, 0.0), (11.8, 6.4, 2.6, 2.2, 0.0), (6.2, 9.0, 1.9, 1.6, 0.0), (10.4, 9.0, 1.9, 1.6, 0.0)])
    def det(x, y, b, c): return spark if hsh(x, y, s) > 0.93 and b > 0.5 else None
    paint_blob(t, pix, ramp, outline=sh(ramp[0], 0.55), detail=det)
    t.save(os.path.join(T, f'{wn}_sapling.png'))

def stem(t, x, y0, y1, bend=0):
    for y in range(y0, y1 + 1):
        xx = x + (bend if y > (y0 + y1) // 2 else 0)
        t.put(xx, y, rgb(0x3e8a46)); 
        if y % 3 == 0: t.put(xx + 1, y, rgb(0x2a6a34))
    t.put(x - 2, y1 - 3, rgb(0x4aa656)); t.put(x - 1, y1 - 2, rgb(0x3e8a46)); t.put(x - 3, y1 - 4, rgb(0x5ac26a))
    t.put(x + 2, y1 - 5, rgb(0x4aa656)); t.put(x + 1, y1 - 4, rgb(0x3e8a46))

def bloom(wn, p):
    t = Tex(16, 16); fc = rgb(p['flower']); ramp = ramp_from(fc, 0.3)
    s = sum(map(ord, wn)) + 21
    stem(t, 7, 8, 15, 0)
    if wn == 'violet':        # lirio de 6 petalos
        els = [(8 + 3.2 * math.cos(a), 5 + 3.2 * math.sin(a), 2.5, 1.2, a) for a in [i * math.pi / 3 + 0.3 for i in range(6)]]
        pix = blob(els + [(8, 5, 1.6, 1.6, 0)])
        paint_blob(t, pix, ramp, outline=sh(ramp[0], 0.55), detail=lambda x, y, b, c: rgb(0xfff2a0) if (x - 7.5) ** 2 + (y - 4.5) ** 2 < 2.2 else None)
    elif wn == 'ember':       # girasol
        els = [(8 + 3.4 * math.cos(a), 5 + 3.4 * math.sin(a), 2.2, 1.1, a) for a in [i * math.pi / 4 for i in range(8)]]
        pix = blob(els)
        paint_blob(t, pix, ramp, outline=sh(ramp[0], 0.5), detail=lambda x, y, b, c: (rgb(0x6a3410) if (x - 7.5) ** 2 + (y - 4.5) ** 2 < 4.2 else None))
    elif wn == 'azure':       # campanilla
        pix = blob([(8, 4.6, 3.6, 3.0, 0), (8, 7.4, 4.4, 1.4, 0)])
        paint_blob(t, pix, ramp, outline=sh(ramp[0], 0.5), detail=lambda x, y, b, c: rgb(0xe0f4ff) if (y == 7 and 5 < x < 10) else None)
    elif wn == 'pale':        # margarita
        els = [(8 + 3.3 * math.cos(a), 5 + 3.3 * math.sin(a), 2.3, 1.1, a) for a in [i * math.pi / 4 for i in range(8)]]
        pix = blob(els)
        ramp = [rgb(0xb0b0bc), rgb(0xd8d8e0), rgb(0xf4f4f8), rgb(0xffffff)]
        paint_blob(t, pix, ramp, outline=rgb(0x7a7a88), detail=lambda x, y, b, c: rgb(0xffcc2a) if (x - 7.5) ** 2 + (y - 4.5) ** 2 < 3.2 else None)
    else:                     # flor de cristal facetada
        pts = [(8, 0.6), (12.5, 4.8), (8, 9.4), (3.5, 4.8)]
        for y in range(16):
            for x in range(16):
                dx, dy = abs(x + 0.5 - 8), abs(y + 0.5 - 5)
                d = dx / 4.6 + dy / 4.4
                if d < 1:
                    c = ramp[3] if (x + 0.5 < 8 and y + 0.5 < 5) else ramp[2] if x + 0.5 < 8 else ramp[1] if y + 0.5 < 5 else ramp[0]
                    if d > 0.82: c = sh(ramp[0], 0.55)
                    if abs(x + 0.5 - 8) < 0.6 or abs(y + 0.5 - 5) < 0.6: c = mix(c, rgb(0xffffff), 0.35)
                    t.put(x, y, c)
    t.save(os.path.join(T, f'{wn}_bloom.png'))

def altar(name, base, glow, light):
    t = Tex(16, 16); s = sum(map(ord, name))
    b, g, l = rgb(base), rgb(glow), rgb(light)
    for y in range(16):
        for x in range(16):
            c = sh(b, 0.85 + 0.3 * vnoise(x, y, 2.4, s))
            if x % 8 == 0 or y % 8 == 0: c = sh(c, 0.6)                    # juntas de ladrillo grande
            elif x % 8 == 1 or y % 8 == 1: c = sh(c, 1.2)
            t.put(x, y, c)
    cx = cy = 7.5
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - cx, y - cy)
            if 4.4 <= d <= 5.6: t.put(x, y, g)                              # anillo de runas
            elif 5.6 < d <= 6.6 and hsh(x, y, s) > 0.4: t.put(x, y, mix(t.px[x, y][:3], g, 0.4))
            elif d < 1.8: t.put(x, y, l)
            elif (abs(x - cx) < 0.9 or abs(y - cy) < 0.9) and d < 4.4: t.put(x, y, mix(g, l, 0.3))
    for (x, y) in ((2, 2), (13, 2), (2, 13), (13, 13)): t.put(x, y, g)
    t.save(os.path.join(T, f'{name}.png'))

def main():
    os.makedirs(T, exist_ok=True); os.makedirs(TI, exist_ok=True)
    for wn, p in PAL.items():
        planks(wn, p); leaves(wn, p); trapdoor(wn, p); door_halves(wn, p); sapling(wn, p); bloom(wn, p)
    altar('violet_altar', 0x2a1048, 0xff4cff, 0xffe0ff)
    altar('crystal_altar', 0x2c5a78, 0xff6ee6, 0xffffff)

if __name__ == '__main__':
    main()
