"""Utilidades de pintura y texturas de troncos de End Realms. Los mobs estan en gen_models.py.
Uso:  python3 tools/gen_textures.py"""
import os, math
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, '..', 'src', 'main', 'resources', 'assets', 'endrealms', 'textures')

# ---------------------------------------------------------------- utilidades
def rgb(c): return ((c >> 16) & 255, (c >> 8) & 255, c & 255)
def sh(c, f): return tuple(max(0, min(255, int(v * f))) for v in c)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def hsh(x, y, s=0):
    n = (x * 374761393 + y * 668265263 + s * 2147483647) & 0xffffffff
    n = ((n ^ (n >> 13)) * 1274126177) & 0xffffffff
    return ((n ^ (n >> 16)) & 0xffff) / 65535.0

def vnoise(x, y, sc, s=0):
    fx, fy = x / sc, y / sc
    x0, y0 = math.floor(fx), math.floor(fy)
    tx, ty = fx - x0, fy - y0
    tx, ty = tx * tx * (3 - 2 * tx), ty * ty * (3 - 2 * ty)
    a, b = hsh(x0, y0, s), hsh(x0 + 1, y0, s)
    c, d = hsh(x0, y0 + 1, s), hsh(x0 + 1, y0 + 1, s)
    return (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty

class Tex:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.im = Image.new('RGBA', (w, h), (0, 0, 0, 0))
        self.px = self.im.load()
    def put(self, x, y, c, a=255):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[x, y] = (*c[:3], a)
    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.im.save(path)

def faces(u, v, w, h, d):
    return {'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d), 'right': (u, v + d, d, h),
            'front': (u + d, v + d, w, h), 'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h)}

def box(t, u, v, w, h, d, fn):
    """fn(cara, lx, ly, ancho, alto) -> color RGB o None."""
    for name, (x, y, fw, fh) in faces(u, v, w, h, d).items():
        for ly in range(fh):
            for lx in range(fw):
                c = fn(name, lx, ly, fw, fh)
                if c is not None:
                    t.put(x + lx, y + ly, c)

def fur(x, y, base, seed, amt=0.12):
    return sh(base, 1 - amt + 2 * amt * hsh(x, y, seed))

# ---------------------------------------------------------------- TRONCOS (16x16)
# estilo por madera: corteza, madera interior, rasgo especial
LOGS = {
    'violet':  dict(bark=0x4a2a6a, wood=0x8a58b8, hi=0x6a3f92, lo=0x2a1440, special='knots'),
    'ember':   dict(bark=0x2a1610, wood=0xc0572b, hi=0x4a2a1c, lo=0x140804, special='cracks'),
    'azure':   dict(bark=0x2a4a64, wood=0x4a8cbc, hi=0x3c6a88, lo=0x16283a, special='moss'),
    'pale':    dict(bark=0xe6e2d2, wood=0xdcd2b2, hi=0xf6f4ea, lo=0x6a6656, special='birch'),
    'crystal': dict(bark=0x4a88a4, wood=0xa6dcec, hi=0x7cc4de, lo=0x2a5670, special='facets'),
}

def log_side(wn, st, stripped=False):
    t = Tex(16, 16)
    b, w, hi, lo = rgb(st['bark']), rgb(st['wood']), rgb(st['hi']), rgb(st['lo'])
    s = sum(map(ord, wn))
    for y in range(16):
        for x in range(16):
            if stripped:
                grain = vnoise(x * 3, y, 5.0, s + 40)
                c = sh(w, 0.94 + 0.14 * grain)
                if x % 4 == 1 and hsh(x, y // 3, s) > 0.45: c = sh(c, 0.88)          # vetas verticales
                if hsh(x, y, s + 3) > 0.94: c = sh(c, 0.82)
            else:
                # surcos verticales de ancho irregular
                col = x + int(2.2 * vnoise(x * 0.5, y, 4.0, s))
                ridge = (col % 4)
                n = vnoise(x * 2, y, 3.0, s + 7)
                c = sh(b, 0.8 + 0.4 * n)
                if ridge == 0: c = mix(c, lo, 0.65)                                  # grieta
                elif ridge == 2: c = mix(c, hi, 0.35)                                # lomo claro
                if hsh(x, y, s + 5) > 0.93: c = sh(c, 1.18)
                sp = st['special']
                if sp == 'knots':
                    for kx, ky in ((4, 5), (11, 11)):
                        d = math.hypot(x - kx, (y - ky) * 0.8)
                        if d < 1.2: c = sh(lo, 0.7)
                        elif d < 2.3: c = mix(c, hi, 0.5)
                elif sp == 'cracks':
                    v = vnoise(x + 3, y * 0.6, 3.5, s + 11)
                    if abs(v - 0.5) < 0.05: c = rgb(0xff7a20) if hsh(x, y, s) > 0.4 else rgb(0xffb43a)
                elif sp == 'moss':
                    if y < 4 + 3 * vnoise(x, 0, 3.0, s + 2) and hsh(x, y, s + 1) > 0.25: c = fur(x, y, rgb(0x3f8a58), s, 0.18)
                    elif y > 12 and hsh(x, y, s + 2) > 0.7: c = fur(x, y, rgb(0x3f8a58), s, 0.18)
                elif sp == 'birch':
                    c = fur(x, y, b, s, 0.05)
                    if y in (3, 4, 8, 12) and 0 < x < 15 and hsh(x // 3, y, s) > 0.35: c = rgb(0x2a2824) if hsh(x, y, s) > 0.3 else rgb(0x4a4840)
                    if y in (4, 9, 13) and hsh(x // 2, y, s + 1) > 0.7: c = sh(c, 0.82)
                elif sp == 'facets':
                    cell = hsh(x // 3, y // 4, s)
                    c = sh(c, 0.85 + 0.35 * cell)
                    if (x % 3 == 0) and cell > 0.6: c = mix(c, rgb(0xd8f6ff), 0.55)
                    if hsh(x, y, s + 8) > 0.97: c = rgb(0xff9bf5)
            t.put(x, y, c)
    return t

def log_top(wn, st, stripped=False):
    t = Tex(16, 16)
    b, w, lo = rgb(st['bark']), rgb(st['wood']), rgb(st['lo'])
    s = sum(map(ord, wn))
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5)
            edge = max(abs(x - 7.5), abs(y - 7.5))
            n = vnoise(x, y, 2.5, s + 21)
            if edge > 6.6 and not stripped:
                c = fur(x, y, b, s, 0.12)                                           # aro de corteza
            else:
                ring = (d + 1.2 * (n - 0.5)) % 3.0
                c = sh(w, 0.92 + 0.16 * n)
                if ring < 0.8: c = mix(c, lo, 0.28)                                 # anillos de crecimiento
                if d < 1.4: c = mix(c, lo, 0.4)                                     # medula
                if edge > 6.6 and stripped: c = sh(c, 0.85)
            t.put(x, y, c)
    return t

def logs():
    T = os.path.join(ROOT, 'block')
    for wn, st in LOGS.items():
        log_side(wn, st).save(os.path.join(T, f'{wn}_log.png'))
        log_top(wn, st).save(os.path.join(T, f'{wn}_log_top.png'))
        log_side(wn, st, True).save(os.path.join(T, f'stripped_{wn}_log.png'))
        log_top(wn, st, True).save(os.path.join(T, f'stripped_{wn}_log_top.png'))

def main():
    import gen_models           # mobs: modelos, texturas y codigo Java generados desde un unico sitio
    gen_models.main()
    import gen_meat
    gen_meat.main()
    logs()
    print('texturas generadas')

if __name__ == '__main__':
    main()
