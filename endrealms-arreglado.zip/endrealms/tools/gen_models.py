"""Modelos, texturas y codigo Java de los mobs de End Realms, generados desde un unico sitio.

Cada mob es una lista de piezas (cajas) con su pivote, rotacion y animacion. De esa lista salen:
  * la textura (UV empaquetadas automaticamente y pintadas pieza a pieza)
  * src/client/java/com/endrealms/client/MobParts.java  (modelo, lo lee SpecModel)
  * src/main/java/com/endrealms/MobDims.java             (hitbox)
Convenciones del modelo (como en vanilla): el suelo esta en y=24, +y es hacia abajo, el frente es -z, 16 px = 1 bloque.
"""
import os, sys, math
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gen_textures import rgb, sh, mix, hsh, vnoise, Tex, faces, ROOT

HERE = os.path.dirname(os.path.abspath(__file__))
PROJ = os.path.normpath(os.path.join(HERE, '..'))
JAVA_CLIENT = os.path.join(PROJ, 'src', 'client', 'java', 'com', 'endrealms', 'client', 'MobParts.java')
JAVA_DIMS = os.path.join(PROJ, 'src', 'main', 'java', 'com', 'endrealms', 'MobDims.java')

# codigos de animacion (los interpreta SpecModel.java)
NONE, HEAD, LEG, ARM, TAIL, SLEG, JAW, FLAP = range(8)
PI = math.pi

# ================================================================= piezas
class Part:
    def __init__(s, name, size, off, pivot, parent=None, rot=(0, 0, 0), kind='body', anim=NONE, phase=0.0):
        s.name, s.parent, s.kind, s.anim, s.phase = name, parent, kind, anim, phase
        s.w, s.h, s.d = size
        s.off, s.pivot, s.rot = off, pivot, rot
        s.u = s.v = 0

def grp(name, pivot, parent=None, rot=(0, 0, 0), anim=NONE, phase=0.0):
    return Part(name, (0, 0, 0), (0, 0, 0), pivot, parent, rot, 'group', anim, phase)

def rotm(rx, ry, rz):
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx

def world(parts):
    W = {}
    for p in parts:
        piv = np.array(p.pivot, float)
        if p.parent:
            Rp, tp = W[p.parent]
            W[p.name] = (Rp @ rotm(*p.rot), tp + Rp @ piv)
        else:
            W[p.name] = (rotm(*p.rot), piv)
    return W

def corners(p, W):
    R, t = W[p.name]
    out = []
    for x in (0, p.w):
        for y in (0, p.h):
            for z in (0, p.d):
                out.append(R @ (np.array(p.off, float) + [x, y, z]) + t)
    return np.array(out)

def bounds(parts):
    W = world(parts)
    pts = np.vstack([corners(p, W) for p in parts if p.kind != 'group'])
    return pts.min(0), pts.max(0)

# ================================================================= empaquetado UV
def footprint(p):
    return 2 * (p.w + p.d), p.h + p.d

def pack(parts):
    boxes = [p for p in parts if p.kind != 'group']
    best = None
    for W in (32, 48, 64, 96, 128, 192, 256):
        order = sorted(boxes, key=lambda p: -footprint(p)[1])
        x = y = rowh = 0
        ok = True
        for p in order:
            fw, fh = footprint(p)
            if fw > W: ok = False; break
            if x + fw > W: x, y, rowh = 0, y + rowh, 0
            p.u, p.v = x, y
            x += fw; rowh = max(rowh, fh)
        if not ok: continue
        H = y + rowh
        area = W * H
        if best is None or area < best[0]:
            best = (area, W, H, [(p, p.u, p.v) for p in order])
    _, W, H, placed = best
    for p, u, v in placed: p.u, p.v = u, v
    return W, int(math.ceil(H / 8.0) * 8)

# ================================================================= pintura
FACE_SHADE = {'top': 1.16, 'front': 1.0, 'back': 0.93, 'left': 0.9, 'right': 0.9, 'bottom': 0.66}

def pat_first(*fs):
    def f(*a):
        for g in fs:
            r = g(*a)
            if r is not None: return r
        return None
    return f

def pat_patches(col, thr=0.58, sc=3.2, seed=0, skip=('bottom',)):
    return lambda face, lx, ly, fw, fh, p, gx, gy: None if face in skip else (col if vnoise(gx, gy, sc, seed) > thr else None)

def pat_dots(col, prob=0.05, seed=0, skip=('bottom',)):
    return lambda face, lx, ly, fw, fh, p, gx, gy: None if face in skip else (col if hsh(gx, gy, seed) > 1 - prob else None)

def pat_stripes(col, period=4, width=1, vertical=True, seed=0):
    def f(face, lx, ly, fw, fh, p, gx, gy):
        if face in ('bottom', 'top'): return None
        c = lx if vertical else ly
        return col if (c % period) < width and hsh(gx // 2, gy // 2, seed) > 0.12 else None
    return f

def pat_spine(col, faces_=('top', 'back'), width=1):
    """linea central oscura (lomo)"""
    def f(face, lx, ly, fw, fh, p, gx, gy):
        if face in faces_ and abs(lx - (fw - 1) / 2) < width / 2 + 0.01: return col
        return None
    return f

def pat_rows(col, rows, faces_=('front', 'back', 'left', 'right')):
    return lambda face, lx, ly, fw, fh, p, gx, gy: col if (face in faces_ and ly in rows) else None

def pat_facets(light, dark, seed=0, cell=3):
    """facetas de cristal: celdas con luz/sombra"""
    def f(face, lx, ly, fw, fh, p, gx, gy):
        v = hsh(gx // cell, gy // cell, seed)
        diag = (lx + ly) % cell
        if v > 0.7 and diag == 0: return light
        if v < 0.2 and diag == 0: return dark
        return None
    return f

def pat_scales(col, seed=0):
    def f(face, lx, ly, fw, fh, p, gx, gy):
        if face == 'bottom': return None
        if (lx + (ly % 2) * 2) % 4 == 0: return col
        return None
    return f

def pat_fur_tufts(col, seed=0):
    def f(face, lx, ly, fw, fh, p, gx, gy):
        if face == 'bottom': return None
        if hsh(gx, gy // 2, seed) > 0.78 and ly % 2 == 1: return col
        return None
    return f

def features(face, lx, ly, fw, fh, p, mat):
    k = p.kind
    if k == 'head' and face == 'front' and mat.get('eye'):
        ey = max(0, min(fh - 1, int(fh * mat.get('eye_y', 0.38))))
        ew = 2 if fw >= 8 else 1
        ex = max(0, int(round(fw * mat.get('eye_x', 0.18))))
        mirror = fw - 1 - lx
        hit = ly == ey and ((ex <= lx < ex + ew) or (ex <= mirror < ex + ew))
        if hit:
            inner = (lx - ex if ex <= lx < ex + ew else mirror - ex)
            if ew == 2 and mat.get('eye_white') is not None and inner == 0: return mat['eye_white']
            return mat['eye']
        if mat.get('brow') is not None and ly == ey - 1 and ((ex - 1 <= lx < ex + ew + 1) or (ex - 1 <= mirror < ex + ew + 1)): return mat['brow']
        if mat.get('mouth') is not None and ly == fh - 2 and 1 <= lx <= fw - 2: return mat['mouth']
        if mat.get('glow_halo') is not None and abs(ly - ey) <= 1 and ((ex - 1 <= lx <= ex + ew) or (ex - 1 <= mirror <= ex + ew)) and not hit:
            return mix(mat['base'], mat['glow_halo'], 0.35)
    if k == 'snout' and face == 'front' and mat.get('nostril') is not None:
        if ly == fh // 2 and (lx == max(0, fw // 4) or lx == fw - 1 - max(0, fw // 4)): return mat['nostril']
    if k == 'ear' and face in ('front', 'back') and mat.get('inner') is not None:
        if 1 <= lx < fw - 1 and 1 <= ly < fh - 1: return mat['inner']
    if k in ('horn', 'antler') and face in ('front', 'back', 'left', 'right') and mat.get('ring') is not None:
        if ly % 3 == 2: return mat['ring']
    if k in ('tooth', 'claw', 'tusk') and mat.get('tip') is not None and face not in ('top', 'bottom') and ly >= fh - 1:
        return mat['tip']
    return None

def paint_part(t, p, mat, seed):
    for face, (x0, y0, fw, fh) in faces(p.u, p.v, p.w, p.h, p.d).items():
        for ly in range(fh):
            for lx in range(fw):
                gx, gy = x0 + lx, y0 + ly
                c = mat['base']
                side = face in ('front', 'back', 'left', 'right')
                if mat.get('belly') is not None:
                    if side:
                        tt = (ly + 0.5) / fh
                        f0 = mat.get('belly_from', 0.55)
                        k = max(0.0, (tt - f0) / (1 - f0))
                        c = mix(c, mat['belly'], min(1.0, k * 1.4) * mat.get('belly_amt', 1.0))
                    elif face == 'bottom':
                        c = mix(c, mat['belly'], mat.get('belly_amt', 1.0))
                if mat.get('grad') is not None and side:
                    tt = (ly + 0.5) / fh
                    c = mix(c, mat['grad'], max(0.0, (tt - mat.get('grad_from', 0.5)) * 2 * mat.get('grad_amt', 1.0)))
                if mat.get('lower') is not None and side and ly >= fh - mat.get('lower_rows', 2):
                    c = mat['lower']
                pat = mat.get('pattern')
                if pat:
                    r = pat(face, lx, ly, fw, fh, p, gx, gy)
                    if r is not None: c = r
                n = vnoise(gx, gy, 1.9, seed) * 0.55 + hsh(gx, gy, seed + 1) * 0.45
                c = sh(c, 1 + (n - 0.5) * mat.get('noise', 0.18))
                f = FACE_SHADE[face]
                edge = (lx == 0 or lx == fw - 1) + (ly == fh - 1) * 1
                if ly == 0 and side: f *= 1.05
                f *= 1 - 0.08 * edge
                c = sh(c, f)
                ov = features(face, lx, ly, fw, fh, p, mat)
                if ov is not None: c = ov
                t.put(gx, gy, c)

def paint_mob(parts, style, W, H, seed):
    t = Tex(W, H)
    default = style.get('body', {'base': rgb(0x808080)})
    for p in parts:
        if p.kind == 'group': continue
        mat = style.get(p.kind, default)
        mat = dict(mat)
        mat.setdefault('base', default['base'])
        paint_part(t, p, mat, seed + sum(map(ord, p.name)))
    return t

# ================================================================= vista previa (lateral / frontal)
def preview(parts, tex, view='side', S=6):
    W = world(parts)
    lo, hi = bounds(parts)
    if view == 'side':
        ax, ay, ox, oy = 2, 1, lo[2], lo[1]     # pantalla x = z, y = y
        sx = int((hi[2] - lo[2]) * S) + 20
    else:
        ax, ay, ox, oy = 0, 1, lo[0], lo[1]
        sx = int((hi[0] - lo[0]) * S) + 20
    sy = int((hi[1] - lo[1]) * S) + 20
    img = Image.new('RGBA', (sx, sy), (70, 70, 80, 255))
    px = img.load()
    tp = tex.px
    items = []
    for p in parts:
        if p.kind == 'group': continue
        R, tt = W[p.name]
        c = (R @ (np.array(p.off, float) + [p.w / 2, p.h / 2, p.d / 2]) + tt)
        items.append((c[0] if view == 'side' else -c[2], p, R, tt))
    items.sort(key=lambda a: a[0])
    reg = {}
    for _, p, R, tt in items:
        fr = faces(p.u, p.v, p.w, p.h, p.d)
        if view == 'side':
            face = 'right'; (x0, y0, fw, fh) = fr[face]
            # puntos locales de la cara +x : x = off.x + w ; (z,y) recorren la cara
            N = 5
            for j in range(fh * N):
                for i in range(fw * N):
                    ty = j / N; tz = i / N
                    # el frente (-z) esta a la izquierda de la pantalla: columna alta de 'right' = frente
                    col = min(fw - 1, int((fw) - 1 - tz)) if fw > 0 else 0
                    loc = np.array([p.off[0] + p.w, p.off[1] + ty, p.off[2] + tz])
                    w = R @ loc + tt
                    X = int((w[ax] - ox) * S) + 10; Y = int((w[ay] - oy) * S) + 10
                    if 0 <= X < sx and 0 <= Y < sy:
                        c = tp[x0 + col, y0 + min(fh - 1, int(ty))]
                        if c[3] > 0: px[X, Y] = c
        else:
            face = 'front'; (x0, y0, fw, fh) = fr[face]
            N = 5
            for j in range(fh * N):
                for i in range(fw * N):
                    ty = j / N; tx = i / N
                    loc = np.array([p.off[0] + tx, p.off[1] + ty, p.off[2]])
                    w = R @ loc + tt
                    X = int((w[ax] - ox) * S) + 10; Y = int((w[ay] - oy) * S) + 10
                    if 0 <= X < sx and 0 <= Y < sy:
                        c = tp[x0 + min(fw - 1, int(tx)), y0 + min(fh - 1, int(ty))]
                        if c[3] > 0: px[X, Y] = c
    return img

# ================================================================= Java
def f(v):
    s = ('%.3f' % v).rstrip('0').rstrip('.')
    return s if s not in ('-0', '') else '0'

def emit_java(mobs):
    lines = ['package com.endrealms.client;', '', '/** GENERADO por tools/gen_models.py: no editar a mano. */',
             'final class MobParts {', '    private MobParts() {}', '',
             '    /** primera linea: ancho,alto de textura,escala; despues una pieza por linea:',
             '     *  nombre|padre|u|v|ox|oy|oz|w|h|d|px|py|pz|rx|ry|rz|anim|fase */',
             '    static String[] get(String id) {', '        switch (id) {']
    for mid, m in mobs.items():
        parts = m['parts']
        rows = [f"{m['tw']},{m['th']},{f(m['scale'])}"]
        for p in parts:
            rows.append('|'.join([p.name, p.parent or '-', str(p.u), str(p.v), f(p.off[0]), f(p.off[1]), f(p.off[2]), str(p.w), str(p.h), str(p.d),
                                  f(p.pivot[0]), f(p.pivot[1]), f(p.pivot[2]), f(p.rot[0]), f(p.rot[1]), f(p.rot[2]), str(p.anim), f(p.phase)]))
        lines.append(f'            case "{mid}": return new String[] {{')
        for r in rows: lines.append(f'                "{r}",')
        lines.append('            };')
    lines += ['            default: return null;', '        }', '    }', '}', '']
    os.makedirs(os.path.dirname(JAVA_CLIENT), exist_ok=True)
    open(JAVA_CLIENT, 'w').write('\n'.join(lines))

    d = ['package com.endrealms;', '', '/** GENERADO por tools/gen_models.py: hitbox (ancho, alto) de cada mob. */',
         'public final class MobDims {', '    private MobDims() {}', '',
         '    public static float[] get(String id) {', '        switch (id) {']
    for mid, m in mobs.items():
        d.append(f'            case "{mid}": return new float[] {{{f(m["w"])}F, {f(m["h"])}F}};')
    d += ['            default: return new float[] {0.9F, 0.9F};', '        }', '    }', '}', '']
    open(JAVA_DIMS, 'w').write('\n'.join(d))


def main():
    import gen_mobs
    return gen_mobs.main()
