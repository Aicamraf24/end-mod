package com.endrealms.mixin;

import com.endrealms.EndRealms;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.OverworldBiomeBuilder;
import net.minecraft.world.level.biome.Climate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Reparte parte de las zonas de planicie del Overworld entre los 5 biomas nuevos.
 * De cada {@link #SHARE_DENOMINATOR} zonas de planicie, 1 se convierte en uno de nuestros biomas
 * (rotando entre los 5). Con 4, nuestros biomas ocupan un cuarto de lo que ocuparia la planicie.
 */
@Mixin(OverworldBiomeBuilder.class)
public class OverworldBiomeBuilderMixin {
    @Unique
    private static final int SHARE_DENOMINATOR = 4;

    @Unique
    private static final List<ResourceKey<Biome>> NEW_BIOMES = List.of(
            ResourceKey.create(Registries.BIOME, EndRealms.id("violet_forest")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("ember_thicket")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("azure_marsh")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("pale_grove")),
            ResourceKey.create(Registries.BIOME, EndRealms.id("crystal_gardens")));

    @Unique
    private int endrealms$plainsSeen = 0;
    @Unique
    private int endrealms$nextBiome = 0;

    @Inject(method = "pickMiddleBiome", at = @At("RETURN"), cancellable = true)
    private void endrealms$sharePlains(int temperature, int humidity, Climate.Parameter weirdness,
                                       CallbackInfoReturnable<ResourceKey<Biome>> cir) {
        if (Biomes.PLAINS.equals(cir.getReturnValue())) {
            if (endrealms$plainsSeen++ % SHARE_DENOMINATOR == 0) {
                cir.setReturnValue(NEW_BIOMES.get(endrealms$nextBiome++ % NEW_BIOMES.size()));
            }
        }
    }
}
