# End Realms (Fabric, Minecraft Java 26.1.2)

Mod que añade 5 biomas a las islas exteriores del **End** (las "tierras altas", junto al bioma vanilla; se registran en `ModBiomes.java`),
cada uno con su madera completa, sapling, flor, un mob pacífico y uno hostil; más 2 estructuras con un miniboss cada una.
Todo está en la pestaña creativa **End Realms**.

## Compilar
1. JDK 25 y Gradle (o copia `gradlew`, `gradlew.bat` y `gradle/wrapper/` del Fabric Example Mod para 26.1).
2. `./gradlew build` -> el jar queda en `build/libs/`.
3. Prueba: `./gradlew runClient`.

## Contenido
| Bioma (zona del End) | Madera | Pacífico | Hostil |
|---|---|---|---|
| Bosque violeta (clima templado) | violet | Rumiante violeta | Acechador violeta |
| Arboleda de marfil (clima frío) | pale | Ciervo marfil | Aullador marfil |
| Matorral de brasa (clima seco) | ember | Jabalí de brasa | Reptante de brasa |
| Pantano azur (clima templado) | azure | Vadeador azur | Merodeador azur |
| Jardines de cristal (clima nevado) | crystal | Oveja de cristal | Mordedor de cristal |

Cada madera: tronco, tronco descortezado, madera, madera descortezada, tablones, escaleras, losa, valla, puerta de valla,
puerta, trampilla, botón, placa de presión, hojas, brote y flor. Recetas incluidas.

Estructuras: el altar central invoca al miniboss con **clic derecho mirando al altar y con una Estrella del Nether en la mano** (se consume; en creativo no).
- **Santuario violeta** -> Guardián violeta (humanoide, hitbox 1.32 x 4.29, 240 HP, onda de choque).
- **Colmena de cristal** -> Reina de cristal (araña, hitbox 4.48 x 2.88, 200 HP, levitación y veneno).
Ambos usan barra de jefe y sueltan diamantes, perlas y caparazones de shulker.

## Personalizar
- Tamaños y hitbox: `ModEntities.java` (`scale` por mob, `WARDEN_SCALE`, `QUEEN_SCALE`).
- Modelo base de cada mob (`Body`: cuadrúpedo = cerdo, araña, humanoide = zombi): `ModEntities.java`. Define también la hitbox.
- Texturas de mobs y troncos: `python3 tools/gen_textures.py` (necesita Pillow). Pintadas sobre los UV de esos modelos vanilla.
- Todo el JSON/NBT/lang se regenera con `python3 tools/gen_resources.py` (edita ahí nombres, colores y estructuras).

## Notas
- La piedra del End cuenta como tierra para plantar saplings y flores (etiqueta `#minecraft:dirt`).
- El End no tiene luz del cielo: los saplings solo crecen con luz de bloque (antorchas) cerca.
- No se incluyen carteles ni barcos.

## Entrar al mundo / compatibilidad
- Si el juego no te deja entrar o crear el mundo, abre `.minecraft/logs/latest.log` (o `crash-reports/`) y busca las lineas con `ERROR` o `Failed to load registries`: dicen que archivo falla.
- Ya no hay mixins: los biomas se colocan con la API de Fabric (`TheEndBiomes`). Los 5 biomas estan en `#minecraft:is_end`.
- Las flores usan `minecraft:simple_block` (el tipo `random_patch` ya no existe en 26.1).

## Compatibilidad con Reptilia, acechador y cápsulas
- Ids distintos (`endrealms:` frente a `reptilia:`, `acechador:`, `capsulas:`).
- End Realms vive en el End y Reptilia en el Overworld (pantano): no tocan los mismos biomas.
- Ambos mods anaden sus maderas a las etiquetas vanilla (`logs`, `planks`, `saplings`, ...): se fusionan solas.
