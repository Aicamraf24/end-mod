package com.endrealms;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.food.Foods;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

import java.util.List;
import java.util.Map;

public final class ModItems {
    /** Carne de cada mob: cruda y cocinada. Los iconos, nombres y recetas de cocina los genera tools/gen_resources.py. */
    private record Meat(String mob, FoodProperties raw, FoodProperties cooked) {}

    private static final List<Meat> MEATS = List.of(
            new Meat("violet_grazer", Foods.BEEF, Foods.COOKED_BEEF),
            new Meat("violet_deer", Foods.MUTTON, Foods.COOKED_MUTTON),
            new Meat("ember_hog", Foods.PORKCHOP, Foods.COOKED_PORKCHOP),
            new Meat("ember_sheep", Foods.MUTTON, Foods.COOKED_MUTTON),
            new Meat("azure_wader", Foods.CHICKEN, Foods.COOKED_CHICKEN),
            new Meat("azure_grazer", Foods.BEEF, Foods.COOKED_BEEF),
            new Meat("pale_deer", Foods.MUTTON, Foods.COOKED_MUTTON),
            new Meat("pale_hog", Foods.PORKCHOP, Foods.COOKED_PORKCHOP),
            new Meat("crystal_sheep", Foods.MUTTON, Foods.COOKED_MUTTON),
            new Meat("crystal_wader", Foods.CHICKEN, Foods.COOKED_CHICKEN),
            // criaturas hostiles: su carne cruda es como la carne podrida (puede dar hambre) salvo las de forma animal
            new Meat("violet_stalker", Foods.ROTTEN_FLESH, Foods.COOKED_MUTTON),
            new Meat("violet_crawler", Foods.ROTTEN_FLESH, Foods.COOKED_MUTTON),
            new Meat("ember_crawler", Foods.ROTTEN_FLESH, Foods.COOKED_PORKCHOP),
            new Meat("ember_howler", Foods.BEEF, Foods.COOKED_BEEF),
            new Meat("azure_lurker", Foods.ROTTEN_FLESH, Foods.COOKED_CHICKEN),
            new Meat("azure_biter", Foods.BEEF, Foods.COOKED_BEEF),
            new Meat("pale_howler", Foods.BEEF, Foods.COOKED_BEEF),
            new Meat("pale_stalker", Foods.ROTTEN_FLESH, Foods.COOKED_MUTTON),
            new Meat("crystal_biter", Foods.ROTTEN_FLESH, Foods.COOKED_PORKCHOP),
            new Meat("crystal_lurker", Foods.ROTTEN_FLESH, Foods.COOKED_BEEF)
    );

    private static void food(String id, FoodProperties food) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, EndRealms.id(id));
        Item item = new Item(new Item.Properties().setId(key).food(food));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        ModBlocks.TAB_ITEMS.add(item);
    }

    public static void init() {
        for (Map.Entry<String, EntityType<? extends net.minecraft.world.entity.Mob>> e : ModEntities.TYPES.entrySet()) {
            ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, EndRealms.id(e.getKey() + "_spawn_egg"));
            SpawnEggItem egg = new SpawnEggItem(new Item.Properties().setId(key).spawnEgg(e.getValue()));
            Registry.register(BuiltInRegistries.ITEM, key, egg);
            ModBlocks.TAB_ITEMS.add(egg);
        }
        for (Meat m : MEATS) {
            food(m.mob() + "_meat", m.raw());
            food("cooked_" + m.mob() + "_meat", m.cooked());
        }
    }
}
