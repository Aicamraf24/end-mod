package com.endrealms;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.OverworldBiomes;
import net.fabricmc.fabric.api.biome.v1.OverworldClimate;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;

public final class ModBiomes {
    /** Peso de cada bioma: un cuarto (0.25) del de un bioma normal como la planicie. */
    private static final double WEIGHT = 0.25;

    private static ResourceKey<Biome> key(String id) {
        return ResourceKey.create(Registries.BIOME, EndRealms.id(id));
    }

    /** bioma, mob pacifico, mob hostil */
    private static final String[][] SPAWNS = {
            {"violet_forest", "violet_grazer", "violet_stalker"},
            {"ember_thicket", "ember_hog", "ember_crawler"},
            {"azure_marsh", "azure_wader", "azure_lurker"},
            {"pale_grove", "pale_deer", "pale_howler"},
            {"crystal_gardens", "crystal_sheep", "crystal_biter"}
    };

    public static void init() {
        OverworldBiomes.addContinentalBiome(key("violet_forest"), OverworldClimate.TEMPERATE, WEIGHT);
        OverworldBiomes.addContinentalBiome(key("azure_marsh"), OverworldClimate.TEMPERATE, WEIGHT);
        OverworldBiomes.addContinentalBiome(key("ember_thicket"), OverworldClimate.DRY, WEIGHT);
        OverworldBiomes.addContinentalBiome(key("pale_grove"), OverworldClimate.COOL, WEIGHT);
        OverworldBiomes.addContinentalBiome(key("crystal_gardens"), OverworldClimate.SNOWY, WEIGHT);

        // Los mobs se anaden por codigo (no por JSON) para no depender del formato del bioma.
        @SuppressWarnings("unchecked")
        ResourceKey<Biome>[] all = new ResourceKey[SPAWNS.length];
        for (int i = 0; i < SPAWNS.length; i++) all[i] = key(SPAWNS[i][0]);
        var allBiomes = BiomeSelectors.includeByKey(all);

        // Mobs vanilla del Overworld
        BiomeModifications.addSpawn(allBiomes, MobCategory.CREATURE, EntityType.SHEEP, 12, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.CREATURE, EntityType.PIG, 10, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.CREATURE, EntityType.CHICKEN, 10, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.CREATURE, EntityType.COW, 8, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.MONSTER, EntityType.SPIDER, 100, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.MONSTER, EntityType.ZOMBIE, 95, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.MONSTER, EntityType.SKELETON, 100, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.MONSTER, EntityType.CREEPER, 100, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.MONSTER, EntityType.SLIME, 100, 4, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.MONSTER, EntityType.ENDERMAN, 10, 1, 4);
        BiomeModifications.addSpawn(allBiomes, MobCategory.MONSTER, EntityType.WITCH, 5, 1, 1);

        // Mobs propios de cada bioma
        for (String[] s : SPAWNS) {
            var selector = BiomeSelectors.includeByKey(key(s[0]));
            BiomeModifications.addSpawn(selector, MobCategory.CREATURE, ModEntities.TYPES.get(s[1]), 20, 2, 4);
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, ModEntities.TYPES.get(s[2]), 20, 2, 4);
        }
    }
}
