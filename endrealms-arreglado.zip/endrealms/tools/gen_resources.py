import os, json, struct, zlib, gzip, random, math
NS = 'endrealms'
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'main', 'resources'))
A = f'{ROOT}/assets/{NS}'
D = f'{ROOT}/data/{NS}'
DM = f'{ROOT}/data/minecraft'

def W(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)

# ---------- PNG ----------
def png(path, w, h, fn):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw += bytes(fn(x, y))
    def chunk(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    data = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) \
        + chunk(b'IDAT', zlib.compress(bytes(raw), 9)) + chunk(b'IEND', b'')
    open(path, 'wb').write(data)

def rgb(c): return ((c >> 16) & 255, (c >> 8) & 255, c & 255)
def shade(c, f): return tuple(max(0, min(255, int(v * f))) for v in c)
def A255(c, a=255): return (*c, a)

# ---------- DATA DEFINITIONS ----------
WOODS = {  # name: (es, en, planks, bark, leaves, flower)
    'violet':  ('violeta', 'Violet', 0x7a4aa8, 0x4a2a6a, 0xa66be0, 0xff7bf0),
    'ember':   ('brasa',   'Ember',  0xc0572b, 0x5a2410, 0xe8892a, 0xffd23a),
    'azure':   ('azur',    'Azure',  0x3f7fb0, 0x1e3b5a, 0x4fd0d6, 0x6ab8ff),
    'pale':    ('marfil',  'Ivory',  0xd8d0b8, 0x8a8470, 0xe9e6d2, 0xffffff),
    'crystal': ('cristal', 'Crystal',0x9ad7e8, 0x4f8aa6, 0xd36bd6, 0xff9bf5),
}
BIOMES = {  # id: (wood, es, en, water, peaceful, hostile, zone)
    'violet_forest':   ('violet',  'Bosque violeta',        'Violet Forest',   0x8a4fd0, 'violet_grazer', 'violet_stalker'),
    'ember_thicket':   ('ember',   'Matorral de brasa',     'Ember Thicket',   0xd05a20, 'ember_hog',     'ember_crawler'),
    'azure_marsh':     ('azure',   'Pantano azur',          'Azure Marsh',     0x2f8fd0, 'azure_wader',   'azure_lurker'),
    'pale_grove':      ('pale',    'Arboleda de marfil',    'Ivory Grove',     0xcfc8b0, 'pale_deer',     'pale_howler'),
    'crystal_gardens': ('crystal', 'Jardines de cristal',   'Crystal Gardens', 0x70d0e8, 'crystal_sheep', 'crystal_biter'),
}
MOBS_ES = {'violet_grazer':'Rumiante violeta','violet_stalker':'Acechador violeta','ember_hog':'Jabalí de brasa',
 'ember_crawler':'Reptante de brasa','azure_wader':'Vadeador azur','azure_lurker':'Merodeador azur','pale_deer':'Ciervo marfil',
 'pale_howler':'Aullador marfil','crystal_sheep':'Oveja de cristal','crystal_biter':'Mordedor de cristal',
 'violet_warden':'Guardián violeta','crystal_queen':'Reina de cristal'}
MOBS_EN = {'violet_grazer':'Violet Grazer','violet_stalker':'Violet Stalker','ember_hog':'Ember Hog','ember_crawler':'Ember Crawler',
 'azure_wader':'Azure Wader','azure_lurker':'Azure Lurker','pale_deer':'Ivory Deer','pale_howler':'Ivory Howler',
 'crystal_sheep':'Crystal Sheep','crystal_biter':'Crystal Biter','violet_warden':'Violet Warden','crystal_queen':'Crystal Queen'}
MOBS_ES.update({'violet_deer':'Ciervo violeta','ember_sheep':'Oveja de brasa','azure_grazer':'Rumiante azur','pale_hog':'Jabalí marfil',
 'crystal_wader':'Vadeador de cristal','violet_crawler':'Reptante violeta','ember_howler':'Aullador de brasa','azure_biter':'Mordedor azur',
 'pale_stalker':'Acechador marfil','crystal_lurker':'Merodeador de cristal'})
MOBS_EN.update({'violet_deer':'Violet Deer','ember_sheep':'Ember Sheep','azure_grazer':'Azure Grazer','pale_hog':'Ivory Hog',
 'crystal_wader':'Crystal Wader','violet_crawler':'Violet Crawler','ember_howler':'Ember Howler','azure_biter':'Azure Biter',
 'pale_stalker':'Ivory Stalker','crystal_lurker':'Crystal Lurker'})
HOSTILE = {'violet_stalker','ember_crawler','azure_lurker','pale_howler','crystal_biter','violet_crawler','ember_howler','azure_biter','pale_stalker','crystal_lurker'}
PEACEFUL = {'violet_grazer','ember_hog','azure_wader','pale_deer','crystal_sheep','violet_deer','ember_sheep','azure_grazer','pale_hog','crystal_wader'}
BOSSES = ['violet_warden', 'crystal_queen']
MOBCOL = {'violet_grazer':(0x9a6bd0,0x4a2a78),'violet_stalker':(0x4a2470,0xff4cff),'ember_hog':(0x7a3416,0xd08a48),
 'ember_crawler':(0x2a120c,0xff7020),'azure_wader':(0x2f86a8,0xbfeaf0),'azure_lurker':(0x2a6d78,0x50fff0),
 'pale_deer':(0xc9a874,0xf4ecd8),'pale_howler':(0x8f8c80,0x3c3a32),'crystal_sheep':(0xbfeaf4,0xff9bf5),
 'crystal_biter':(0x2f6b84,0xff6ee6),'violet_warden':(0x4a2a6a,0xc464ff),'crystal_queen':(0x1c4a66,0xff5af0),
 'violet_deer':(0x9a6bd0,0xff9bf5),'ember_sheep':(0xe8a060,0xffa030),'azure_grazer':(0x2f86a8,0x0e3550),'pale_hog':(0xd4c8a8,0x6a5a40),
 'crystal_wader':(0x5aa0bc,0xff9bf5),'violet_crawler':(0x24103c,0xff4cff),'ember_howler':(0x7a4a30,0xffa030),'azure_biter':(0x1e5a74,0x50fff0),
 'pale_stalker':(0xd4ccb4,0x4a463c),'crystal_lurker':(0x3a7a96,0xff6ee6)}

# ---------- TEXTURES ----------
def noise_tex(path, base, var, seed, w=16, h=16, pattern=None):
    r = random.Random(seed)
    cells = {}
    def fn(x, y):
        k = (x, y)
        if k not in cells: cells[k] = r.uniform(1 - var, 1 + var)
        c = shade(base, cells[k])
        if pattern: c = pattern(x, y, c)
        return A255(c)
    png(path, w, h, fn)

for wn, (es, en, pl, bark, lf, fl) in WOODS.items():
    T = f'{A}/textures/block'
    s = abs(hash(wn)) % 1000
    pc, bc, lc, fc = rgb(pl), rgb(bark), rgb(lf), rgb(fl)
    noise_tex(f'{T}/{wn}_planks.png', pc, 0.07, 1+s, pattern=lambda x, y, c: shade(c, 0.78) if y % 4 == 3 else c)
    noise_tex(f'{T}/{wn}_leaves.png', lc, 0.18, 6+s)
    noise_tex(f'{T}/{wn}_trapdoor.png', pc, 0.07, 7+s, pattern=lambda x, y, c: shade(c, 0.6) if x in (0, 15) or y in (0, 15) or x == 7 or y == 7 else c)
    def door(top):
        def f(x, y, c):
            if x in (0, 15) or y in (0, 15): return shade(c, 0.6)
            if top and 3 <= x <= 12 and 3 <= y <= 9: return (200, 230, 255)
            if (not top) and x == 12 and y == 8: return (230, 200, 60)
            return c
        return f
    noise_tex(f'{T}/{wn}_door_top.png', pc, 0.06, 8+s, pattern=door(True))
    noise_tex(f'{T}/{wn}_door_bottom.png', pc, 0.06, 9+s, pattern=door(False))
    # sapling
    def sap(x, y):
        if x in (7, 8) and 8 <= y <= 15: return A255(bc)
        d = math.hypot(x - 7.5, y - 5.5)
        if d < 5 and (x + y) % 3 != 0: return A255(shade(lc, 0.9 + (x % 3) * 0.1))
        return (0, 0, 0, 0)
    png(f'{T}/{wn}_sapling.png', 16, 16, sap)
    def bl(x, y):
        if x in (7, 8) and 7 <= y <= 15: return A255((50, 140, 60))
        if y in (11, 12) and x in (5, 6, 9, 10): return A255((50, 140, 60))
        d = math.hypot(x - 7.5, y - 4.5)
        if d < 3.2: return A255(fc if d > 1.2 else (255, 240, 120))
        return (0, 0, 0, 0)
    png(f'{T}/{wn}_bloom.png', 16, 16, bl)
    # door item
    def di(x, y):
        if 4 <= x <= 11 and 1 <= y <= 14:
            if x in (4, 11) or y in (1, 14) or y == 7: return A255(shade(pc, 0.6))
            if y in (3, 4) and 6 <= x <= 9: return A255((200, 230, 255))
            if x == 9 and y == 9: return A255((230, 200, 60))
            return A255(pc)
        return (0, 0, 0, 0)
    png(f'{A}/textures/item/{wn}_door.png', 16, 16, di)

for altar, col in (('violet_altar', 0x5a1e9a), ('crystal_altar', 0x5ac0d8)):
    noise_tex(f'{A}/textures/block/{altar}.png', rgb(col), 0.2, 99 + len(altar),
              pattern=lambda x, y, c: (255, 240, 160) if (x, y) in ((7,7),(8,7),(7,8),(8,8)) else c)

# Texturas de mobs y troncos: ver tools/gen_textures.py
import importlib.util
_sp = importlib.util.spec_from_file_location('gen_textures', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'gen_textures.py'))
_gt = importlib.util.module_from_spec(_sp); _sp.loader.exec_module(_gt); _gt.main()

# ---------- MODELS / BLOCKSTATES ----------
def block_model(name, parent, tex): W(f'{A}/models/block/{name}.json', {'parent': parent, 'textures': tex})
def item_def(name, model, extra=None):
    W(f'{A}/items/{name}.json', {'model': {'type': 'minecraft:model', 'model': model}})
def bs(name, obj): W(f'{A}/blockstates/{name}.json', obj)
def m(n): return f'{NS}:block/{n}'
FACING_Y = {'east': 0, 'south': 90, 'west': 180, 'north': 270}

def var(model, x=0, y=0, uv=False):
    d = {'model': model}
    if x: d['x'] = x
    if y: d['y'] = y
    if uv or x or y: d['uvlock'] = True
    return d

lang_es, lang_en = {}, {}
tags = {}
def tag(kind, name, *vals):
    tags.setdefault((kind, name), []).extend(vals)

NAMES_ES = {'log':'Tronco de {}','stripped_log':'Tronco descortezado de {}','wood':'Madera de {}','stripped_wood':'Madera descortezada de {}',
 'planks':'Tablones de {}','stairs':'Escaleras de {}','slab':'Losa de {}','fence':'Valla de {}','fence_gate':'Puerta de valla de {}',
 'door':'Puerta de {}','trapdoor':'Trampilla de {}','button':'Botón de {}','pressure_plate':'Placa de presión de {}',
 'leaves':'Hojas de {}','sapling':'Brote de {}','bloom':'Flor de {}'}
NAMES_EN = {'log':'{} Log','stripped_log':'Stripped {} Log','wood':'{} Wood','stripped_wood':'Stripped {} Wood','planks':'{} Planks',
 'stairs':'{} Stairs','slab':'{} Slab','fence':'{} Fence','fence_gate':'{} Fence Gate','door':'{} Door','trapdoor':'{} Trapdoor',
 'button':'{} Button','pressure_plate':'{} Pressure Plate','leaves':'{} Leaves','sapling':'{} Sapling','bloom':'{} Bloom'}

def bid(wn, kind):
    if kind in ('stripped_log', 'stripped_wood'): return f'stripped_{wn}_{kind.split("_")[1]}'
    return f'{wn}_{kind}'

def loot_self(bn, cond=None):
    entry = {'type': 'minecraft:item', 'name': f'{NS}:{bn}'}
    pool = {'rolls': 1, 'entries': [entry], 'conditions': [{'condition': 'minecraft:survives_explosion'}]}
    if cond: pool['conditions'].append(cond)
    W(f'{D}/loot_table/blocks/{bn}.json', {'type': 'minecraft:block', 'random_sequence': f'{NS}:blocks/{bn}', 'pools': [pool]})

for wn, (es, en, pl, bark, lf, fl) in WOODS.items():
    P = f'{wn}_planks'
    for kind in NAMES_ES:
        b = bid(wn, kind)
        lang_es[f'block.{NS}.{b}'] = NAMES_ES[kind].format(es)
        lang_en[f'block.{NS}.{b}'] = NAMES_EN[kind].format(en)
    # logs
    for b, side, end in ((f'{wn}_log', f'{wn}_log', f'{wn}_log_top'), (f'stripped_{wn}_log', f'stripped_{wn}_log', f'stripped_{wn}_log_top'),
                         (f'{wn}_wood', f'{wn}_log', f'{wn}_log'), (f'stripped_{wn}_wood', f'stripped_{wn}_log', f'stripped_{wn}_log')):
        block_model(b, 'minecraft:block/cube_column', {'end': m(end), 'side': m(side)})
        bs(b, {'variants': {'axis=y': {'model': m(b)}, 'axis=z': {'model': m(b), 'x': 90}, 'axis=x': {'model': m(b), 'x': 90, 'y': 90}}})
        item_def(b, m(b)); loot_self(b)
    # planks
    block_model(P, 'minecraft:block/cube_all', {'all': m(P)})
    bs(P, {'variants': {'': {'model': m(P)}}}); item_def(P, m(P)); loot_self(P)
    # stairs
    st = f'{wn}_stairs'
    tex = {'bottom': m(P), 'top': m(P), 'side': m(P)}
    block_model(st, 'minecraft:block/stairs', tex)
    block_model(st + '_inner', 'minecraft:block/inner_stairs', tex)
    block_model(st + '_outer', 'minecraft:block/outer_stairs', tex)
    variants = {}
    for half in ('bottom', 'top'):
        for shape in ('straight', 'inner_left', 'inner_right', 'outer_left', 'outer_right'):
            for f, yb in FACING_Y.items():
                if half == 'bottom':
                    y = (yb + (270 if shape.endswith('left') and shape != 'straight' else 0)) % 360
                    x = 0
                else:
                    x = 180
                    y = (yb + (90 if shape.endswith('right') else 0)) % 360
                mdl = st if shape == 'straight' else st + ('_inner' if shape.startswith('inner') else '_outer')
                variants[f'facing={f},half={half},shape={shape}'] = var(m(mdl), x, y, True)
    bs(st, {'variants': variants}); item_def(st, m(st)); loot_self(st)
    # slab
    sl = f'{wn}_slab'
    block_model(sl, 'minecraft:block/slab', tex); block_model(sl + '_top', 'minecraft:block/slab_top', tex)
    bs(sl, {'variants': {'type=bottom': {'model': m(sl)}, 'type=top': {'model': m(sl + '_top')}, 'type=double': {'model': m(P)}}})
    item_def(sl, m(sl))
    W(f'{D}/loot_table/blocks/{sl}.json', {'type': 'minecraft:block', 'random_sequence': f'{NS}:blocks/{sl}', 'pools': [{'rolls': 1,
        'entries': [{'type': 'minecraft:item', 'name': f'{NS}:{sl}', 'functions': [{'function': 'minecraft:set_count', 'count': 2,
        'conditions': [{'condition': 'minecraft:block_state_property', 'block': f'{NS}:{sl}', 'properties': {'type': 'double'}}]},
        {'function': 'minecraft:explosion_decay'}]}]}]})
    # fence
    fe = f'{wn}_fence'
    block_model(fe + '_post', 'minecraft:block/fence_post', {'texture': m(P)})
    block_model(fe + '_side', 'minecraft:block/fence_side', {'texture': m(P)})
    block_model(fe + '_inventory', 'minecraft:block/fence_inventory', {'texture': m(P)})
    bs(fe, {'multipart': [{'apply': {'model': m(fe + '_post')}}] + [
        {'when': {d: 'true'}, 'apply': {'model': m(fe + '_side'), 'y': y, 'uvlock': True} if y else {'model': m(fe + '_side'), 'uvlock': True}}
        for d, y in (('north', 0), ('east', 90), ('south', 180), ('west', 270))]})
    item_def(fe, m(fe + '_inventory')); loot_self(fe)
    # gate
    g = f'{wn}_fence_gate'
    for suf, par in (('', 'template_fence_gate'), ('_open', 'template_fence_gate_open'), ('_wall', 'template_fence_gate_wall'), ('_wall_open', 'template_fence_gate_wall_open')):
        block_model(g + suf, f'minecraft:block/{par}', {'texture': m(P)})
    gv = {}
    for f, y in (('south', 0), ('west', 90), ('north', 180), ('east', 270)):
        for wall in ('false', 'true'):
            for op in ('false', 'true'):
                suf = ('_wall' if wall == 'true' else '') + ('_open' if op == 'true' else '')
                gv[f'facing={f},in_wall={wall},open={op}'] = var(m(g + suf), 0, y, True)
    bs(g, {'variants': gv}); item_def(g, m(g)); loot_self(g)
    # door
    d_ = f'{wn}_door'
    for half in ('bottom', 'top'):
        for hinge in ('left', 'right'):
            for op in ('', '_open'):
                block_model(f'{d_}_{half}_{hinge}{op}', f'minecraft:block/door_{half}_{hinge}{op}', {'top': m(d_ + '_top'), 'bottom': m(d_ + '_bottom')})
    dv = {}
    for f, yb in FACING_Y.items():
        for half, hn in (('lower', 'bottom'), ('upper', 'top')):
            for hinge in ('left', 'right'):
                for op in ('false', 'true'):
                    y = yb
                    if op == 'true': y = (yb + (90 if hinge == 'left' else 270)) % 360
                    mdl = f'{d_}_{hn}_{hinge}' + ('_open' if op == 'true' else '')
                    dv[f'facing={f},half={half},hinge={hinge},open={op}'] = var(m(mdl), 0, y)
    bs(d_, {'variants': dv})
    W(f'{A}/items/{d_}.json', {'model': {'type': 'minecraft:model', 'model': f'{NS}:item/{d_}'}})
    W(f'{A}/models/item/{d_}.json', {'parent': 'minecraft:item/generated', 'textures': {'layer0': f'{NS}:item/{d_}'}})
    loot_self(d_, {'condition': 'minecraft:block_state_property', 'block': f'{NS}:{d_}', 'properties': {'half': 'lower'}})
    # trapdoor
    t = f'{wn}_trapdoor'
    for suf in ('bottom', 'top', 'open'):
        block_model(f'{t}_{suf}', f'minecraft:block/template_orientable_trapdoor_{suf}', {'texture': m(t)})
    tv = {}
    for f in FACING_Y:
        tv[f'facing={f},half=bottom,open=false'] = {'model': m(t + '_bottom')}
        tv[f'facing={f},half=top,open=false'] = {'model': m(t + '_top')}
    for f, yb, yt in (('north', 0, 180), ('south', 180, 0), ('east', 90, 270), ('west', 270, 90)):
        tv[f'facing={f},half=bottom,open=true'] = var(m(t + '_open'), 0, yb)
        tv[f'facing={f},half=top,open=true'] = var(m(t + '_open'), 180, yt)
    bs(t, {'variants': tv}); item_def(t, m(t + '_bottom')); loot_self(t)
    # button
    bu = f'{wn}_button'
    block_model(bu, 'minecraft:block/button', {'texture': m(P)})
    block_model(bu + '_pressed', 'minecraft:block/button_pressed', {'texture': m(P)})
    block_model(bu + '_inventory', 'minecraft:block/button_inventory', {'texture': m(P)})
    bv = {}
    for face, x in (('floor', 0), ('wall', 90), ('ceiling', 180)):
        for f in FACING_Y:
            if face == 'ceiling': y = {'east': 270, 'north': 180, 'south': 0, 'west': 90}[f]
            else: y = {'east': 90, 'north': 0, 'south': 180, 'west': 270}[f]
            for pw in ('false', 'true'):
                bv[f'face={face},facing={f},powered={pw}'] = var(m(bu + ('_pressed' if pw == 'true' else '')), x, y)
    bs(bu, {'variants': bv}); item_def(bu, m(bu + '_inventory')); loot_self(bu)
    # plate
    pp = f'{wn}_pressure_plate'
    block_model(pp, 'minecraft:block/pressure_plate_up', {'texture': m(P)})
    block_model(pp + '_down', 'minecraft:block/pressure_plate_down', {'texture': m(P)})
    bs(pp, {'variants': {'powered=false': {'model': m(pp)}, 'powered=true': {'model': m(pp + '_down')}}})
    item_def(pp, m(pp)); loot_self(pp)
    # leaves
    lv = f'{wn}_leaves'
    block_model(lv, 'minecraft:block/leaves', {'all': m(lv)})
    bs(lv, {'variants': {'': {'model': m(lv)}}}); item_def(lv, m(lv))
    W(f'{D}/loot_table/blocks/{lv}.json', {'type': 'minecraft:block', 'random_sequence': f'{NS}:blocks/{lv}', 'pools': [
        {'rolls': 1, 'conditions': [{'condition': 'minecraft:match_tool', 'predicate': {'items': 'minecraft:shears'}}],
         'entries': [{'type': 'minecraft:item', 'name': f'{NS}:{lv}'}]},
        {'rolls': 1, 'conditions': [{'condition': 'minecraft:inverted', 'term': {'condition': 'minecraft:match_tool', 'predicate': {'items': 'minecraft:shears'}}},
                                    {'condition': 'minecraft:random_chance', 'chance': 0.06}],
         'entries': [{'type': 'minecraft:item', 'name': f'{NS}:{wn}_sapling'}]},
        {'rolls': 1, 'conditions': [{'condition': 'minecraft:inverted', 'term': {'condition': 'minecraft:match_tool', 'predicate': {'items': 'minecraft:shears'}}},
                                    {'condition': 'minecraft:random_chance', 'chance': 0.15}],
         'entries': [{'type': 'minecraft:item', 'name': 'minecraft:stick'}]}]})
    # sapling + bloom
    for kind in ('sapling', 'bloom'):
        b = f'{wn}_{kind}'
        block_model(b, 'minecraft:block/cross', {'cross': m(b)})
        bs(b, {'variants': {'stage=0,': {'model': m(b)}} if False else ({'stage=0': {'model': m(b)}, 'stage=1': {'model': m(b)}} if kind == 'sapling' else {'': {'model': m(b)}})})
        W(f'{A}/items/{b}.json', {'model': {'type': 'minecraft:model', 'model': f'{NS}:item/{b}'}})
        W(f'{A}/models/item/{b}.json', {'parent': 'minecraft:item/generated', 'textures': {'layer0': m(b)}})
        loot_self(b)
    # tags
    L = f'{NS}:{wn}_log'; SL = f'{NS}:stripped_{wn}_log'; Wd = f'{NS}:{wn}_wood'; SW = f'{NS}:stripped_{wn}_wood'
    for kind in ('block', 'item'):
        tag(kind, f'{NS}:{wn}_logs', L, SL, Wd, SW)
        tag(kind, 'minecraft:logs', f'#{NS}:{wn}_logs')
        tag(kind, 'minecraft:logs_that_burn', f'#{NS}:{wn}_logs')
        tag(kind, 'minecraft:planks', f'{NS}:{wn}_planks')
        tag(kind, 'minecraft:wooden_stairs', f'{NS}:{wn}_stairs')
        tag(kind, 'minecraft:wooden_slabs', f'{NS}:{wn}_slab')
        tag(kind, 'minecraft:wooden_fences', f'{NS}:{wn}_fence')
        tag(kind, 'minecraft:fence_gates', f'{NS}:{wn}_fence_gate')
        tag(kind, 'minecraft:wooden_doors', f'{NS}:{wn}_door')
        tag(kind, 'minecraft:wooden_trapdoors', f'{NS}:{wn}_trapdoor')
        tag(kind, 'minecraft:wooden_buttons', f'{NS}:{wn}_button')
        tag(kind, 'minecraft:wooden_pressure_plates', f'{NS}:{wn}_pressure_plate')
        tag(kind, 'minecraft:leaves', f'{NS}:{wn}_leaves')
        tag(kind, 'minecraft:saplings', f'{NS}:{wn}_sapling')
        tag(kind, 'minecraft:small_flowers', f'{NS}:{wn}_bloom')
    tag('block', 'minecraft:mineable/axe', L, SL, Wd, SW, f'{NS}:{wn}_planks', f'{NS}:{wn}_stairs', f'{NS}:{wn}_slab', f'{NS}:{wn}_fence',
        f'{NS}:{wn}_fence_gate', f'{NS}:{wn}_door', f'{NS}:{wn}_trapdoor', f'{NS}:{wn}_button', f'{NS}:{wn}_pressure_plate')
    tag('block', 'minecraft:mineable/hoe', f'{NS}:{wn}_leaves')
    tag('block', 'minecraft:replaceable_by_trees', f'{NS}:{wn}_leaves')
    # recipes
    def R(name, obj): W(f'{D}/recipe/{name.split(":")[-1]}.json', obj)  # sin 'namespace:' en el nombre del archivo
    def shaped(name, pattern, key, out, count, group=None):
        o = {'type': 'minecraft:crafting_shaped', 'category': 'building', 'pattern': pattern, 'key': key, 'result': {'id': f'{NS}:{out}', 'count': count}}
        if group: o['group'] = group
        R(name, o)
    PL = f'{NS}:{P}'
    R(P, {'type': 'minecraft:crafting_shapeless', 'category': 'building', 'group': 'planks', 'ingredients': [f'#{NS}:{wn}_logs'], 'result': {'id': PL, 'count': 4}})
    shaped(Wd, ['LL', 'LL'], {'L': L}, f'{wn}_wood', 3)
    shaped(SW, ['LL', 'LL'], {'L': SL}, f'stripped_{wn}_wood', 3)
    shaped(f'{wn}_stairs', ['P  ', 'PP ', 'PPP'], {'P': PL}, f'{wn}_stairs', 4)
    shaped(f'{wn}_slab', ['PPP'], {'P': PL}, f'{wn}_slab', 6)
    shaped(f'{wn}_fence', ['PSP', 'PSP'], {'P': PL, 'S': 'minecraft:stick'}, f'{wn}_fence', 3)
    shaped(f'{wn}_fence_gate', ['SPS', 'SPS'], {'P': PL, 'S': 'minecraft:stick'}, f'{wn}_fence_gate', 1)
    shaped(f'{wn}_door', ['PP', 'PP', 'PP'], {'P': PL}, f'{wn}_door', 3)
    shaped(f'{wn}_trapdoor', ['PPP', 'PPP'], {'P': PL}, f'{wn}_trapdoor', 2)
    shaped(f'{wn}_pressure_plate', ['PP'], {'P': PL}, f'{wn}_pressure_plate', 1)
    R(f'{wn}_button', {'type': 'minecraft:crafting_shapeless', 'category': 'redstone', 'ingredients': [PL], 'result': {'id': f'{NS}:{wn}_button', 'count': 1}})

# altars
for a, ab, aes, aen in (('violet_altar', 'violet', 'Altar del Guardián violeta', 'Violet Warden Altar'), ('crystal_altar', 'crystal', 'Altar de la Reina de cristal', 'Crystal Queen Altar')):
    block_model(a, 'minecraft:block/cube_all', {'all': m(a)}); bs(a, {'variants': {'': {'model': m(a)}}}); item_def(a, m(a))
    lang_es[f'block.{NS}.{a}'] = aes; lang_en[f'block.{NS}.{a}'] = aen
    tag('block', 'minecraft:mineable/pickaxe', f'{NS}:{a}')

# dirt tag so saplings/flowers can be planted on end stone

tags[('worldgen/biome', 'minecraft:is_end')] = [f'{NS}:{b}' for b in BIOMES]
tags[('block', 'minecraft:dirt')] = ['minecraft:end_stone']   # saplings y flores se plantan sobre piedra del End
for (kind, name), vals in tags.items():
    ns_, p = name.split(':')
    W(f'{ROOT}/data/{ns_}/tags/{kind}/{p}.json', {'replace': False, 'values': vals})

# spawn eggs + lang
EGGC = {k: (v[0], v[1]) for k, v in MOBCOL.items()}
for mid in list(MOBS_ES):
    c1, c2 = EGGC[mid]
    W(f'{A}/items/{mid}_spawn_egg.json', {'model': {'type': 'minecraft:model', 'model': 'minecraft:item/template_spawn_egg',
        'tints': [{'type': 'minecraft:constant', 'value': c1}, {'type': 'minecraft:constant', 'value': c2}]}})
    lang_es[f'entity.{NS}.{mid}'] = MOBS_ES[mid]; lang_en[f'entity.{NS}.{mid}'] = MOBS_EN[mid]
    lang_es[f'item.{NS}.{mid}_spawn_egg'] = f'Huevo generador de {MOBS_ES[mid]}'
    lang_en[f'item.{NS}.{mid}_spawn_egg'] = f'{MOBS_EN[mid]} Spawn Egg'
    # loot
    if mid in BOSSES:
        pools = [{'rolls': 1, 'entries': [{'type': 'minecraft:item', 'name': 'minecraft:diamond', 'functions': [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': 3, 'max': 6}}]}]},
                 {'rolls': 1, 'entries': [{'type': 'minecraft:item', 'name': 'minecraft:ender_pearl', 'functions': [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': 4, 'max': 8}}]}]},
                 {'rolls': 1, 'entries': [{'type': 'minecraft:item', 'name': 'minecraft:shulker_shell', 'functions': [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': 1, 'max': 3}}]}]}]
    elif mid in HOSTILE:
        pools = [{'rolls': 1, 'entries': [{'type': 'minecraft:item', 'name': 'minecraft:ender_pearl', 'functions': [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': 0, 'max': 1}}]}]}]
    else:
        pools = [{'rolls': 1, 'entries': [{'type': 'minecraft:item', 'name': 'minecraft:chorus_fruit', 'functions': [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': 1, 'max': 2}}]}]}]
    W(f'{D}/loot_table/entities/{mid}.json', {'type': 'minecraft:entity', 'pools': pools})

lang_es[f'itemGroup.{NS}.main'] = 'End Realms'; lang_en[f'itemGroup.{NS}.main'] = 'End Realms'
for bid_, (wn, es, en, wc, pe, ho) in BIOMES.items():
    lang_es[f'biome.{NS}.{bid_}'] = es; lang_en[f'biome.{NS}.{bid_}'] = en
W(f'{A}/lang/es_es.json', lang_es); W(f'{A}/lang/en_us.json', lang_en)

# ---------- WORLDGEN ----------
def state(name, props=None):
    d = {'Name': name}
    if props: d['Properties'] = props
    return d
TREE = {
 'violet':  ({'type': 'minecraft:straight_trunk_placer', 'base_height': 5, 'height_rand_a': 2, 'height_rand_b': 1},
             {'type': 'minecraft:blob_foliage_placer', 'radius': 2, 'offset': 0, 'height': 3}, (1, 0, 1)),
 'ember':   ({'type': 'minecraft:forking_trunk_placer', 'base_height': 5, 'height_rand_a': 2, 'height_rand_b': 2},
             {'type': 'minecraft:acacia_foliage_placer', 'radius': 2, 'offset': 0}, (1, 0, 2)),
 'azure':   ({'type': 'minecraft:straight_trunk_placer', 'base_height': 7, 'height_rand_a': 3, 'height_rand_b': 1},
             {'type': 'minecraft:spruce_foliage_placer', 'radius': 2, 'offset': 0, 'trunk_height': 2}, (2, 0, 2)),
 'pale':    ({'type': 'minecraft:fancy_trunk_placer', 'base_height': 3, 'height_rand_a': 11, 'height_rand_b': 0},
             {'type': 'minecraft:fancy_foliage_placer', 'radius': 2, 'offset': 4, 'height': 4}, (0, 0, 0)),
 'crystal': ({'type': 'minecraft:bending_trunk_placer', 'base_height': 4, 'height_rand_a': 2, 'height_rand_b': 1, 'min_height_for_leaves': 2,
              'bend_length': 2},
             {'type': 'minecraft:random_spread_foliage_placer', 'radius': 2, 'offset': 0, 'foliage_height': 2, 'leaf_placement_attempts': 50}, (1, 0, 1)),
}
def patch_cfg(block, tries, spread):
    # En 26.1 ya no existe "minecraft:random_patch": cada flor es un simple_block y la dispersion la hace el placed_feature.
    return {'type': 'minecraft:simple_block', 'config': {'to_place': {'type': 'minecraft:simple_state_provider', 'state': state(block)}}}

for wn in WOODS:
    trunk, foliage, (lim, lo, up) = TREE[wn]
    W(f'{D}/worldgen/configured_feature/{wn}_tree.json', {'type': 'minecraft:tree', 'config': {
        'trunk_provider': {'type': 'minecraft:simple_state_provider', 'state': state(f'{NS}:{wn}_log', {'axis': 'y'})},
        'foliage_provider': {'type': 'minecraft:simple_state_provider', 'state': state(f'{NS}:{wn}_leaves')},
        'trunk_placer': trunk,
        'foliage_placer': foliage,
        'minimum_size': {'type': 'minecraft:two_layers_feature_size', 'limit': lim, 'lower_size': lo, 'upper_size': up},
        'dirt_provider': {'type': 'minecraft:simple_state_provider', 'state': state('minecraft:dirt')},
        'decorators': [],
        'ignore_vines': True}})
    W(f'{D}/worldgen/configured_feature/{wn}_bloom_patch.json', patch_cfg(f'{NS}:{wn}_bloom', 28, 6))
    # Mismo orden de campos y filtros que usa Reptilia para sus arboles (formato ya probado en 26.1.2)
    W(f'{D}/worldgen/placed_feature/{wn}_tree.json', {'feature': f'{NS}:{wn}_tree', 'placement': [
        {'type': 'minecraft:count', 'count': 3},
        {'type': 'minecraft:in_square'},
        {'type': 'minecraft:surface_water_depth_filter', 'max_water_depth': 2},
        {'type': 'minecraft:heightmap', 'heightmap': 'OCEAN_FLOOR'},
        {'type': 'minecraft:block_predicate_filter', 'predicate': {'type': 'minecraft:would_survive', 'state': state(f'{NS}:{wn}_sapling')}},
        {'type': 'minecraft:biome'}]})
    W(f'{D}/worldgen/placed_feature/{wn}_bloom_patch.json', {'feature': f'{NS}:{wn}_bloom_patch', 'placement': [
        {'type': 'minecraft:count', 'count': 10},
        {'type': 'minecraft:in_square'}, {'type': 'minecraft:heightmap', 'heightmap': 'MOTION_BLOCKING'},
        {'type': 'minecraft:block_predicate_filter', 'predicate': {'type': 'minecraft:would_survive', 'state': state(f'{NS}:{wn}_bloom')}},
        {'type': 'minecraft:biome'}]})

V = 'minecraft:'
# (temperatura, humedad, precipitacion, color agua, color hierba, color follaje)
CLIM = {'violet_forest': (0.5, 0.5, False, 0x8a4fd0, 0x8fc060, 0x9a5ad0),
        'ember_thicket': (0.5, 0.5, False, 0xd05a20, 0xc0a040, 0xd8782a),
        'azure_marsh': (0.5, 0.5, False, 0x2f8fd0, 0x4fb090, 0x3fb8c0),
        'pale_grove': (0.5, 0.5, False, 0xcfc8b0, 0xa8c890, 0xdcd8c0),
        'crystal_gardens': (0.5, 0.5, False, 0x70d0e8, 0x80d0c0, 0xc860cc)}
def argb(c): return (0xFF000000 | c) - (1 << 32)
for bid_, (wn, es, en, wc, pe, ho) in BIOMES.items():
    # Biomas del End: islas de piedra del End con arboles y flores del bioma (sin minerales, hierba ni cuevas).
    feats = [[] for _ in range(11)]
    feats[9] = [f'{NS}:{wn}_tree', f'{NS}:{wn}_bloom_patch']
    t, d, pr, w_, g_, f_ = CLIM[bid_]
    # Mismo formato de biomas que Reptilia (colores como entero ARGB, spawners vacios; los mobs van por codigo)
    W(f'{D}/worldgen/biome/{bid_}.json', {
        'temperature': t, 'downfall': d, 'has_precipitation': pr,
        'effects': {'water_color': argb(w_), 'foliage_color': argb(f_), 'grass_color': argb(g_)},
        'spawners': {'monster': [], 'creature': [], 'ambient': [], 'axolotls': [], 'underground_water_creature': [],
                     'water_creature': [], 'water_ambient': [], 'misc': []},
        'spawn_costs': {},
        'carvers': [],
        'features': feats})

# structure biome tags
W(f'{D}/tags/worldgen/biome/has_violet_sanctum.json', {'replace': False, 'values': [f'{NS}:violet_forest', f'{NS}:pale_grove', f'{NS}:ember_thicket']})
W(f'{D}/tags/worldgen/biome/has_crystal_hive.json', {'replace': False, 'values': [f'{NS}:crystal_gardens', f'{NS}:azure_marsh']})

# ---------- STRUCTURES ----------
def nbt_str(s): b = s.encode(); return struct.pack('>H', len(b)) + b
def nbt_payload(t, v):
    if t == 3: return struct.pack('>i', v)
    if t == 8: return nbt_str(v)
    if t == 9:
        et, items = v
        return struct.pack('>Bi', et, len(items)) + b''.join(nbt_payload(et, i) for i in items)
    if t == 10:
        out = b''
        for k, (tt, vv) in v.items(): out += struct.pack('>B', tt) + nbt_str(k) + nbt_payload(tt, vv)
        return out + b'\x00'
def write_nbt(path, root):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = b'\x0a' + nbt_str('') + nbt_payload(10, root)
    with gzip.open(path, 'wb') as f: f.write(data)

class Template:
    def __init__(self, sx, sy, sz):
        self.s = (sx, sy, sz); self.b = {}
        for x in range(sx):
            for y in range(sy):
                for z in range(sz): self.b[(x, y, z)] = ('minecraft:air', None)
    def set(self, x, y, z, name, props=None):
        if (x, y, z) in self.b: self.b[(x, y, z)] = (name, props)
    def save(self, name):
        palette, idx, blocks = [], {}, []
        for pos, (n, pr) in sorted(self.b.items()):
            key = (n, tuple(sorted(pr.items())) if pr else None)
            if key not in idx:
                idx[key] = len(palette)
                e = {'Name': (8, n)}
                if pr: e['Properties'] = (10, {k: (8, v) for k, v in pr.items()})
                palette.append(e)
            blocks.append({'pos': (9, (3, list(pos))), 'state': (3, idx[key])})
        root = {'size': (9, (3, list(self.s))), 'palette': (9, (10, palette)), 'blocks': (9, (10, blocks)),
                'entities': (9, (10, [])), 'DataVersion': (3, 4325)}
        write_nbt(f'{D}/structure/{name}.nbt', root)

# Violet Sanctum 13x10x13
t = Template(13, 10, 13)
for x in range(13):
    for z in range(13):
        t.set(x, 0, z, 'minecraft:end_stone_bricks')
        if 3 <= x <= 9 and 3 <= z <= 9: t.set(x, 0, z, 'minecraft:purpur_block')
        if 5 <= x <= 7 and 5 <= z <= 7: t.set(x, 0, z, 'minecraft:obsidian')
        if (x in (0, 12) or z in (0, 12)) and not (x == 6 or z == 6):
            t.set(x, 1, z, 'minecraft:end_stone_brick_slab', {'type': 'bottom', 'waterlogged': 'false'})
for cx, cz, hh in ((0, 0, 7), (12, 0, 7), (0, 12, 7), (12, 12, 7), (3, 3, 4), (9, 3, 4), (3, 9, 4), (9, 9, 4)):
    for y in range(1, hh):
        t.set(cx, y, cz, 'minecraft:purpur_pillar', {'axis': 'y'})
    t.set(cx, hh, cz, 'minecraft:crying_obsidian' if hh == 7 else 'minecraft:end_rod', None if hh == 7 else {'facing': 'up'})
t.set(6, 1, 6, f'{NS}:violet_altar')
t.save('violet_sanctum')

# Crystal Hive 15x9x15
rnd = random.Random(777)
t = Template(15, 9, 15)
for x in range(15):
    for z in range(15):
        dx, dz = x - 7, z - 7
        d = math.hypot(dx, dz)
        if d <= 7.2:
            t.set(x, 0, z, 'minecraft:amethyst_block' if rnd.random() < 0.25 else 'minecraft:calcite')
            if 6.0 <= d <= 7.2 and not (abs(dx) <= 1 or abs(dz) <= 1):
                for y in range(1, 4): t.set(x, y, z, 'minecraft:amethyst_block' if rnd.random() < 0.8 else 'minecraft:calcite')
                t.set(x, 4, z, 'minecraft:purple_stained_glass')
            elif d < 6.0:
                for y in range(1, 4):
                    if rnd.random() < 0.08: t.set(x, y, z, 'minecraft:cobweb')
for dx in range(-1, 2):
    for dz in range(-1, 2): t.set(7 + dx, 0, 7 + dz, 'minecraft:amethyst_block')
t.set(7, 1, 7, f'{NS}:crystal_altar')
t.save('crystal_hive')

for sname, tagname, spacing, sep, salt in (('violet_sanctum', 'has_violet_sanctum', 20, 8, 1337421), ('crystal_hive', 'has_crystal_hive', 24, 10, 7734111)):
    W(f'{D}/worldgen/structure/{sname}.json', {'type': 'minecraft:jigsaw', 'biomes': f'#{NS}:{tagname}', 'step': 'surface_structures',
        'start_pool': f'{NS}:{sname}/start', 'size': 1, 'start_height': {'absolute': -1}, 'project_start_to_heightmap': 'WORLD_SURFACE_WG',
        'max_distance_from_center': 80, 'use_expansion_hack': False, 'spawn_overrides': {}, 'terrain_adaptation': 'beard_thin'})
    W(f'{D}/worldgen/template_pool/{sname}/start.json', {'fallback': 'minecraft:empty', 'elements': [{'weight': 1, 'element': {
        'element_type': 'minecraft:single_pool_element', 'location': f'{NS}:{sname}', 'processors': 'minecraft:empty', 'projection': 'rigid'}}]})
    W(f'{D}/worldgen/structure_set/{sname}.json', {'structures': [{'structure': f'{NS}:{sname}', 'weight': 1}],
        'placement': {'type': 'minecraft:random_spread', 'spacing': spacing, 'separation': sep, 'salt': salt}})
print('generated')
