package com.endrealms.client;

import com.endrealms.EndRealms;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.monster.spider.SpiderModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

/** Cuerpo de araña con textura y escala propias (mobs hostiles y la Reina de cristal). */
public class ScaledSpiderRenderer extends MobRenderer<Mob, LivingEntityRenderState, SpiderModel> {
    private final Identifier texture;
    private final float scale;

    public ScaledSpiderRenderer(EntityRendererProvider.Context ctx, String name, float scale) {
        super(ctx, new SpiderModel(ctx.bakeLayer(ModelLayers.SPIDER)), 0.8F * scale);
        this.texture = EndRealms.id("textures/entity/" + name + ".png");
        this.scale = scale;
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return texture;
    }

    @Override
    protected void scale(LivingEntityRenderState state, PoseStack poseStack) {
        poseStack.scale(scale, scale, scale);
    }
}
