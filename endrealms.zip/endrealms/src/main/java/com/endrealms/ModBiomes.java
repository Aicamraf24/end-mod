package com.endrealms;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.TheEndBiomes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

public final class ModBiomes {
    private static ResourceKey<Biome> key(String id) {
        return ResourceKey.create(Registries.BIOME, EndRealms.id(id));
    }

    /** bioma, mob pacifico, mob hostil */
    private static final String[][] SPAWNS = {
            {"violet_forest", "violet_grazer", "violet_stalker"},
            {"ember_thicket", "ember_hog", "ember_crawler"},
            {"azure_marsh", "azure_wader", "azure_lurker"},
            {"pale_grove", "pale_deer", "pale_howler"},
            {"crystal_gardens", "crystal_sheep", "crystal_biter"}
    };

    public static void init() {
        // Zonas "altas" del End exterior
        TheEndBiomes.addHighlandsBiome(key("violet_forest"), 1.0);
        TheEndBiomes.addHighlandsBiome(key("pale_grove"), 1.0);
        // Zonas medias y bajas se asocian a un bioma "highlands" padre (el vanilla)
        TheEndBiomes.addMidlandsBiome(Biomes.END_HIGHLANDS, key("ember_thicket"), 1.0);
        TheEndBiomes.addMidlandsBiome(Biomes.END_HIGHLANDS, key("azure_marsh"), 1.0);
        TheEndBiomes.addBarrensBiome(Biomes.END_HIGHLANDS, key("crystal_gardens"), 1.0);

        // Los mobs se anaden por codigo (no por JSON) para no depender del formato del bioma.
        for (String[] s : SPAWNS) {
            var selector = BiomeSelectors.includeByKey(key(s[0]));
            EntityType<?> peaceful = ModEntities.TYPES.get(s[1]);
            EntityType<?> hostile = ModEntities.TYPES.get(s[2]);
            BiomeModifications.addSpawn(selector, MobCategory.CREATURE, peaceful, 20, 2, 4);
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, hostile, 20, 2, 4);
            BiomeModifications.addSpawn(selector, MobCategory.MONSTER, EntityType.ENDERMAN, 10, 1, 3);
        }
    }
}
