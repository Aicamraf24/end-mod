package com.endrealms.client;

import com.endrealms.ModBlocks;
import com.endrealms.ModEntities;
import com.endrealms.WoodSet;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;

public class EndRealmsClient implements ClientModInitializer {
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void reg(EntityType<?> type, net.minecraft.client.renderer.entity.EntityRendererProvider provider) {
        EntityRenderers.register((EntityType) type, provider);
    }

    @Override
    public void onInitializeClient() {
        for (WoodSet w : ModBlocks.WOODS) {
            BlockRenderLayerMap.putBlocks(ChunkSectionLayer.CUTOUT, w.leaves, w.sapling, w.bloom, w.door, w.trapdoor);
        }
        for (ModEntities.MobDef d : ModEntities.DEFS) {
            EntityType<?> t = ModEntities.TYPES.get(d.id());
            if (d.hostile()) reg(t, ctx -> new ScaledSpiderRenderer(ctx, d.id(), d.scale()));
            else reg(t, ctx -> new ScaledQuadrupedRenderer(ctx, d.id(), d.scale()));
        }
        reg(ModEntities.VIOLET_WARDEN, ctx -> new ScaledHumanoidRenderer(ctx, "violet_warden", ModEntities.WARDEN_SCALE));
        reg(ModEntities.CRYSTAL_QUEEN, ctx -> new ScaledSpiderRenderer(ctx, "crystal_queen", ModEntities.QUEEN_SCALE));
    }
}
