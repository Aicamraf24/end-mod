"""Iconos 16x16 de la carne de cada mob (cruda y cocinada). Cada mob tiene su forma y la paleta de su bioma."""
import os, math
from gen_textures import rgb, sh, mix, hsh, vnoise, Tex, ROOT
from gen_art import blob, band, ramp_from, paint_blob

# mob -> (forma, bioma)
MEATS = {
    'violet_grazer': ('steak', 'violet'), 'violet_deer': ('leg', 'violet'), 'violet_stalker': ('chunk', 'violet'), 'violet_crawler': ('chunk', 'violet'),
    'ember_hog': ('chop', 'ember'), 'ember_sheep': ('leg', 'ember'), 'ember_crawler': ('chunk', 'ember'), 'ember_howler': ('steak', 'ember'),
    'azure_wader': ('drumstick', 'azure'), 'azure_grazer': ('steak', 'azure'), 'azure_lurker': ('chop', 'azure'), 'azure_biter': ('chunk', 'azure'),
    'pale_deer': ('leg', 'pale'), 'pale_hog': ('chop', 'pale'), 'pale_howler': ('steak', 'pale'), 'pale_stalker': ('chop', 'pale'),
    'crystal_sheep': ('leg', 'crystal'), 'crystal_wader': ('drumstick', 'crystal'), 'crystal_biter': ('chunk', 'crystal'), 'crystal_lurker': ('chunk', 'crystal'),
}
# rampas [oscuro, medio, claro, brillo] + grasa + destello
RAW = {
    'violet':  ([rgb(0x5c2058), rgb(0x8c3a80), rgb(0xb85fa8), rgb(0xe494d4)], rgb(0xf8dcf8), rgb(0xffb4ff)),
    'ember':   ([rgb(0x6a1408), rgb(0xa82414), rgb(0xd44a26), rgb(0xff8a58)], rgb(0xffd8b4), rgb(0xffc060)),
    'azure':   ([rgb(0x14506a), rgb(0x2a809c), rgb(0x52b2c6), rgb(0x92e2ec)], rgb(0xdcf8f4), rgb(0xc8ffff)),
    'pale':    ([rgb(0xa45c5a), rgb(0xd0847e), rgb(0xecaaa2), rgb(0xffd8cc)], rgb(0xfff8f0), rgb(0xffffff)),
    'crystal': ([rgb(0x3c80a4), rgb(0x66b2d4), rgb(0x98d8ee), rgb(0xd6f6ff)], rgb(0xffe8ff), rgb(0xff9bf5)),
}
COOKED = {
    'violet':  [rgb(0x3a1c1c), rgb(0x66341e), rgb(0x90522c), rgb(0xc2824a)],
    'ember':   [rgb(0x381408), rgb(0x723010), rgb(0xa2501a), rgb(0xd88830)],
    'azure':   [rgb(0x2c261c), rgb(0x584426), rgb(0x84643a), rgb(0xb88c4c)],
    'pale':    [rgb(0x502e1a), rgb(0x84552c), rgb(0xb4803f), rgb(0xe2b06c)],
    'crystal': [rgb(0x3c2c28), rgb(0x6c4a34), rgb(0x9a744c), rgb(0xcca472)],
}
BONE = [rgb(0xb8ae94), rgb(0xd8d0b8), rgb(0xf2ecdc), rgb(0xffffff)]

SHAPES = {   # elipses (cx, cy, rx, ry, rot) de la carne y direccion del veteado
    'steak':     ([(8.0, 8.4, 6.7, 4.9, -0.5)], -0.5),
    'chop':      ([(7.8, 8.8, 5.6, 5.0, 0.3), (5.2, 6.4, 3.2, 3.0, 0.0)], 0.3),
    'leg':       ([(6.4, 9.4, 5.1, 4.2, 0.75), (4.4, 11.0, 2.4, 2.2, 0.0)], 0.75),
    'drumstick': ([(6.3, 9.6, 4.6, 4.2, 0.7)], 0.7),
    'chunk':     ([(6.8, 8.4, 4.6, 4.2, 0.0), (10.2, 9.6, 3.6, 3.3, 0.5), (6.0, 11.4, 3.5, 3.0, 0.0), (9.4, 6.2, 2.8, 2.6, 0.0)], 0.0),
}

def bone_pixels(shape):
    b = {}
    if shape == 'chop':
        for (x, y) in ((10, 6), (11, 5), (12, 4), (11, 4), (12, 3), (13, 3), (13, 4), (12, 5)):
            b[(x, y)] = 0
    elif shape in ('leg', 'drumstick'):
        w = 1.15 if shape == 'leg' else 0.95
        for y in range(16):
            for x in range(16):
                px, py = x + 0.5, y + 0.5
                d = abs((px - 9.0) * 0.707 + (py - 7.0) * 0.707)
                along = (px - 9.0) * 0.707 - (py - 7.0) * 0.707
                if d < w and 0 < along < 5.4: b[(x, y)] = 0
        for (cx, cy, r) in ((12.6, 3.4, 1.55), (14.0, 2.0, 1.45)):
            for y in range(16):
                for x in range(16):
                    if (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 < r * r: b[(x, y)] = 0
    return b

def draw(mob, cooked):
    shape, theme = MEATS[mob]
    seed = sum(map(ord, mob))
    ell, ang = SHAPES[shape]
    raw_ramp, fat, spark = RAW[theme]
    ramp = COOKED[theme] if cooked else raw_ramp
    pix = blob(ell)
    # forma irregular suave (no una elipse perfecta)
    pix = {k: v for k, v in pix.items() if vnoise(k[0], k[1], 2.4, seed) > 0.12 or v > 0.55}
    ca, sa = math.cos(ang), math.sin(ang)

    def detail(x, y, b, c):
        u = (x + 0.5) * ca + (y + 0.5) * sa
        v = -(x + 0.5) * sa + (y + 0.5) * ca
        streak = (u * 0.85 + vnoise(x, y, 3.0, seed + 2) * 2.2) % 3.4
        if not cooked:
            if streak < 0.55 and b > 0.3: return mix(c, fat, 0.85 if b > 0.6 else 0.55)    # veteado de grasa
            if b > 0.9 and hsh(x, y, seed) > 0.3: return ramp[3]
            if theme in ('crystal', 'violet') and hsh(x, y, seed + 5) > 0.95: return spark
        else:
            if (round(v) % 5) in (0,) and shape in ('steak', 'chop', 'chunk') and b > 0.25: return sh(ramp[0], 0.95)   # marcas de parrilla
            if streak < 0.5 and b > 0.5: return mix(c, ramp[3], 0.6)                                                   # jugo caramelizado
            if b > 0.92: return ramp[3]
        return None
    t = Tex(16, 16)
    bones = bone_pixels(shape)
    paint_blob(t, pix, ramp, outline=sh(ramp[0], 0.5), detail=detail)
    if bones:
        solid = set(bones) | set(pix)
        for (x, y) in sorted(bones):
            if (x, y) in pix: continue
            edge = any((x + dx, y + dy) not in solid for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
            sh_i = 3 if (x + y) <= 14 else 2 if (x + y) <= 16 else 1
            t.put(x, y, rgb(0x6a604c) if edge else BONE[sh_i])
    return t

def main():
    d = os.path.join(ROOT, 'item')
    os.makedirs(d, exist_ok=True)
    for mob in MEATS:
        draw(mob, False).save(os.path.join(d, f'{mob}_meat.png'))
        draw(mob, True).save(os.path.join(d, f'cooked_{mob}_meat.png'))

if __name__ == '__main__':
    main()
