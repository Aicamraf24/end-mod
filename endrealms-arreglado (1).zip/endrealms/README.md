# End Realms (Fabric, Minecraft Java 26.1.2)

Mod que añade 5 biomas a las islas exteriores del **End** (las "tierras altas", junto al bioma vanilla; se registran en `ModBiomes.java`),
cada uno con su madera completa, sapling, flor, 2 mobs pacíficos y 2 hostiles (20 mobs en total); más 2 estructuras con un miniboss cada una.
Todo está en la pestaña creativa **End Realms**.

## Carne, drops y pasto
- Cada mob suelta su propia carne (`<mob>_meat`) y tiene su versión cocinada (`cooked_<mob>_meat`), que se hace en horno, ahumador u hoguera. Además suelta objetos de su bioma (amatista, polvo de blaze, prismarina, hueso, cristales de prismarina) y los propios de su especie (cuero, plumas, cuerda...). Los bosses sueltan además una Estrella del Nether con un 25 %.
- El suelo de los biomas se cubre de pasto (`SurfaceGrassFeature.java`) y cada bioma lo tiñe de un color distinto (`grass_color` en el JSON del bioma, generado en `tools/gen_resources.py`, tabla `CLIM`).
- Los animales solo aparecen al generarse terreno nuevo (`creature_spawn_probability` del bioma, ahora 0.6); en chunks ya explorados no salen. Los hostiles aparecen con normalidad por la noche/oscuridad.

## Compilar
1. JDK 25 y Gradle (o copia `gradlew`, `gradlew.bat` y `gradle/wrapper/` del Fabric Example Mod para 26.1).
2. `./gradlew build` -> el jar queda en `build/libs/`.
3. Prueba: `./gradlew runClient`.

## Contenido
| Bioma | Madera | Pacíficos | Hostiles |
|---|---|---|---|
| Bosque violeta | violet | Rumiante violeta, Ciervo violeta | Acechador violeta, Reptante violeta |
| Arboleda de marfil | pale | Ciervo marfil, Jabalí marfil | Aullador marfil, Acechador marfil |
| Matorral de brasa | ember | Jabalí de brasa, Oveja de brasa | Reptante de brasa, Aullador de brasa |
| Pantano azur | azure | Vadeador azur, Rumiante azur | Merodeador azur, Mordedor azur |
| Jardines de cristal | crystal | Oveja de cristal, Vadeador de cristal | Mordedor de cristal, Merodeador de cristal |

Cada mob "variante" tiene la forma de un mob de otro bioma pintada con los colores del suyo.

Cada madera: tronco, tronco descortezado, madera, madera descortezada, tablones, escaleras, losa, valla, puerta de valla,
puerta, trampilla, botón, placa de presión, hojas, brote y flor. Recetas incluidas.

Estructuras: clic derecho al altar central invoca al miniboss.
- **Santuario violeta** -> Guardián violeta (humanoide, hitbox 1.32 x 4.29, 240 HP, onda de choque).
- **Colmena de cristal** -> Reina de cristal (araña, hitbox 4.48 x 2.88, 200 HP, levitación y veneno).
Ambos usan barra de jefe y sueltan diamantes, perlas y caparazones de shulker.

## Personalizar
- Tamaños y hitbox: `ModEntities.java` (`scale` por mob, `WARDEN_SCALE`, `QUEEN_SCALE`).
- Cada mob tiene modelo propio (piezas/cajas con animación), textura propia y hitbox propia. Se definen en `tools/gen_mobs.py`
  (formas y estilos de pintura) y `tools/gen_models.py` (motor); `python3 tools/gen_textures.py` (necesita Pillow y numpy) regenera:
  texturas de mobs y troncos, `src/client/.../MobParts.java` (modelos) y `src/main/.../MobDims.java` (hitbox). No edites esos dos .java a mano.
- Estadísticas de vida/velocidad/daño: `ModEntities.java`. El modelo lo dibuja `SpecModel.java`/`SpecRenderer.java`.
- Todo el JSON/NBT/lang se regenera con `python3 tools/gen_resources.py` (edita ahí nombres, colores y estructuras).

## Notas
- La piedra del End cuenta como tierra para plantar saplings y flores (etiqueta `#minecraft:dirt`).
- El End no tiene luz del cielo: los saplings solo crecen con luz de bloque (antorchas) cerca.
- No se incluyen carteles ni barcos.

## Entrar al mundo / compatibilidad
- Si el juego no te deja entrar o crear el mundo, abre `.minecraft/logs/latest.log` (o `crash-reports/`) y busca las lineas con `ERROR` o `Failed to load registries`: dicen que archivo falla.
- Ya no hay mixins: los biomas se colocan con la API de Fabric (`TheEndBiomes`). Los 5 biomas estan en `#minecraft:is_end`.
- Las flores usan `minecraft:simple_block` (el tipo `random_patch` ya no existe en 26.1).

## Compatibilidad con Reptilia, acechador y cápsulas
- Ids distintos (`endrealms:` frente a `reptilia:`, `acechador:`, `capsulas:`).
- End Realms vive en el End y Reptilia en el Overworld (pantano): no tocan los mismos biomas.
- Ambos mods anaden sus maderas a las etiquetas vanilla (`logs`, `planks`, `saplings`, ...): se fusionan solas.
