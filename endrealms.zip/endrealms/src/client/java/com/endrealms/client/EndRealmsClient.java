package com.endrealms.client;

import com.endrealms.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.entity.EntityType;

public class EndRealmsClient implements ClientModInitializer {
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void reg(EntityType<?> type, net.minecraft.client.renderer.entity.EntityRendererProvider provider) {
        EntityRenderers.register((EntityType) type, provider);
    }

    @Override
    public void onInitializeClient() {
        // La capa de render (cutout) de bloques con transparencia la decide el juego segun la textura en 26.1.
        for (ModEntities.MobDef d : ModEntities.DEFS) {
            EntityType<?> t = ModEntities.TYPES.get(d.id());
            if (d.hostile()) reg(t, ctx -> new ScaledSpiderRenderer(ctx, d.id(), d.scale()));
            else reg(t, ctx -> new ScaledQuadrupedRenderer(ctx, d.id(), d.scale()));
        }
        reg(ModEntities.VIOLET_WARDEN, ctx -> new ScaledHumanoidRenderer(ctx, "violet_warden", ModEntities.WARDEN_SCALE));
        reg(ModEntities.CRYSTAL_QUEEN, ctx -> new ScaledSpiderRenderer(ctx, "crystal_queen", ModEntities.QUEEN_SCALE));
    }
}
