package com.endrealms.client;

import com.endrealms.EndRealms;
import com.endrealms.MobDims;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Mob;

/** Renderer de todos los mobs de End Realms: cada uno tiene su propio modelo (SpecModel) y su textura. */
public class SpecRenderer extends MobRenderer<Mob, LivingEntityRenderState, SpecModel> {
    private final Identifier texture;
    private final float scale;

    public SpecRenderer(EntityRendererProvider.Context ctx, String name) {
        super(ctx, SpecModel.create(name), 0.45F * MobDims.get(name)[0]);
        this.texture = EndRealms.id("textures/entity/" + name + ".png");
        this.scale = SpecModel.scaleOf(name);
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return texture;
    }

    @Override
    protected void scale(LivingEntityRenderState state, PoseStack poseStack) {
        poseStack.scale(scale, scale, scale);
    }
}
