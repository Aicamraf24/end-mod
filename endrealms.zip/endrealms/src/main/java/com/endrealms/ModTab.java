package com.endrealms;

import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public final class ModTab {
    public static void init() {
        CreativeModeTab tab = FabricCreativeModeTab.builder()
                .title(Component.translatable("itemGroup.endrealms.main"))
                .icon(() -> new ItemStack(ModBlocks.WOODS.get(0).sapling))
                .displayItems((params, out) -> {
                    for (ItemLike item : ModBlocks.TAB_ITEMS) out.accept(item);
                })
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, EndRealms.id("main"), tab);
    }
}
